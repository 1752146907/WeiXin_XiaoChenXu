const notification = require('../../util/notification.js');
const constant = require("../../util/constant.js");
const http = require("../../util/http.js");
const util = require("../../util/util.js");
const storage = require("../../util/storage.js");
const chat = require("../../util/chat.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageHost: constant.imageHost,
    dialogId: '',
    archivesId: '',
    dialogContent: '',
    textContent: '',
    pageSize: 10,
    inputIsFocus: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      dialogId: options.dialogid
    });
    this.handleLoad(options.dialogid);
  },
  handleLoad: function (dialogId) {
    http.request({
      url: '/jiyi/dialog/mobile/v1/open/dialog',
      data: {
        dialogId: dialogId,
        pageIndex: 1,
        pageSize: this.data.pageSize,
      },
      success: function (data) {
        for (var i = 0; i < data.data.dialogItemList.length; i++) {
          data.data.dialogItemList[i].systemCreateTime = util.timeToDateStr(data.data.dialogItemList[i].systemCreateTime);
          //判断时间数据是否重复
          if (i + 1 < data.data.dialogItemList.length) {
            if (data.data.dialogItemList[i].systemCreateTime == data.data.dialogItemList[i].systemCreateTime) {
              var j = ++i;
              data.data.dialogItemList[j].systemCreateTime = ""
            }
          }
        }
        data.data.dialogItemList = data.data.dialogItemList.reverse(); //数组倒叙
        this.setData({
          dialogContent: data.data
        })
        setTimeout(() => {
          wx.pageScrollTo({
            scrollTop: 99999,
            duration: 0
          })
        }, 100)
      }.bind(this)
    });
  },
  handleInput: function (e) {
    this.setData({
      textContent: e.detail.value
    });
  },
  handleBlur: function () {
    this.setData({
      inputIsFocus: false
    });
  },
  handleFocus: function () {
    this.setData({
      inputIsFocus: true
    });
  },
  handlePreviewImage: function (e) {
    wx.previewImage({
      urls: [e.currentTarget.dataset.url] // 当前显示图片的http链接
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    chat.checkMessageRead(this.data.dialogId);
    this.handleWebSocketMessage();
  },
  handleWebSocketMessage: function () {
    wx.onSocketMessage((res) => {
      console.log(res);
      var msg = JSON.parse(res.data);
      var systemCreateTime = msg.systemCreateTime;
      msg.systemCreateTime = systemCreateTime.slice(0, -3);
      var dialogContent = this.data.dialogContent;
      dialogContent.dialogItemList.push(msg);
      this.setData({
        dialogContent: dialogContent
      });

      chat.checkMessageRead(this.data.dialogId);

      setTimeout(() => {
        wx.pageScrollTo({
          scrollTop: 99999,
          duration: 0
        })
      }, 300);
    })
  },
  handleSendTextMessage: function () {
    var dialogId = this.data.dialogId;
    var content = this.data.textContent;
    this.setData({
      textContent: ''
    });
    chat.sendTextMessage(dialogId, content);
  },
  handleChooseImage: function () {
    chat.sendImage(this.data.dialogId, 'chatCanvasId');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      pageSize: this.data.pageSize + 10
    })
    this.handleLoad(this.data.dialogId);
    // this.handleWebSocket();
    setTimeout(() => {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0
      })
    }, 300)
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})