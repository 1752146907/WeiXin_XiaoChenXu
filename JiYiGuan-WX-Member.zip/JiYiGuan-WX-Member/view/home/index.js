const constant = require("../../util/constant.js");
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");
const notification = require("../../util/notification.js");
const chat = require("../../util/chat.js");

Page({
  data: {
    imgUrls: [
      '/image/banner.jpg',
      '/image/banner.jpg'
    ],
    windowWidth: getApp().globalData.windowWidth,
    storage: storage,
    doctorList: [],
    imageHost: constant.imageHost,
    doctorMemberId: ''
  },
  onUnload: function () {
  },
  handleToDetail: function (e) {
    wx.navigateTo({
      url: '/view/detail/detail?doctorId=' + e.currentTarget.dataset.doctorid
    })
  },
  handleQuiz: function () {
    if (storage.getToken() == '') {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/consult/chat'
          })
        }
      })
    }
  },
  openConfirm: function (e) {
    this.setData({
      doctorMemberId: e.currentTarget.dataset.memberid
    })
    var slef = this;
    wechat.auth({
      checkLogin: true,
      success: function () {
        wx.showModal({
          title: '确认付费',
          content: '完成付费即可单独咨询医生，请点击确认按钮完成付费',
          confirmText: "确认",
          cancelText: "取消",
          success: function (res) {
            if (res.confirm) {
              http.request({
                isToast: true,
                url: '/jiyi/dialog/mobile/v1/save',
                data: {
                  doctorMemberId: slef.data.doctorMemberId,
                },
                success: function (data) {
                  if (data.data.hasOngongingDialog){
                    wx.showToast({
                      title: '您有正在咨询的订单',
                      icon: 'none',
                      duration: 2000
                    })
                    return;
                  }
                  if (data.result) {
                    slef.handlePay(data.data.dialogId, data.data.dialogFee);
                  }
                }.bind(this)
              });
            } else {
              wx.showToast({
                title: '用户取消付款',
                icon: 'none',
                duration: 1000
              });
            }
          }
        });
      }
    })
  },
  handlePay: function (outTradeNo, totalFee) {
    wechat.auth({
      success: function (data) {
        http.request({
          isToast: true,
          url: '/wechat/wechat/pay/mobile/v1/unified/order',
          data: {
            outTradeNo: outTradeNo,
            openId: storage.getOpenId(),
            tradeType: 'JSAPI',
            body: '微信支付',
            totalFee: totalFee * 100,
            notifyUrl: ''
          },
          success: function (data) {
            wx.requestPayment({
              nonceStr: data.data.nonceStr,
              package: data.data.packageStr,
              signType: data.data.signType,
              paySign: data.data.paySign,
              appId: data.data.appId,
              timeStamp: data.data.timeStamp,
              success: function (response) {

              },
              complete: function (response) {
                setTimeout(function () {
                  wx.reLaunch({
                    url: '/view/consult/index?saleOrderId=' + outTradeNo,
                  });
                }, 300)
              }.bind(this)
            })
          }.bind(this),
          file: function () {

          }
        });
      }.bind(this),
      fail: function () {

      }
    });
  },
  handleLoad: function (){
    http.request({
      url: '/jiyi/doctor/mobile/v1/list',
      data: {},
      success: function (data) {
        var doctorList = data.data;
        this.setData({
          doctorList: doctorList
        });
      }.bind(this)
    });
  },
  onLoad: function () {
    chat.tipSumOfUnreadMessage();    
  },
  onReady: function () {

  },
  onShow: function () {
    this.handleLoad();
    notification.on("archives", this, function (data) {
      console.log(data)
      if (data) {
        wx.navigateTo({
          url: '/view/consult/index?archives=' + data
        })
      }
    });
  },
  onHide: function () {

  },
  onPullDownRefresh: function () {
    this.handleLoad();
    wx.stopPullDownRefresh()
  },
  onReachBottom: function () {
    console.log('000000000')
  },
  onShareAppMessage: function () {

  }
});
