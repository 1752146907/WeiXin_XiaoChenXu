const constant = require("../../util/constant.js");
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");

Page({
  data: {
      imageHost: constant.imageHost,
      userName: '',
      userAvatar: '',
      storage: storage
    },
    onUnload: function () {

    },
    onLoad: function () {
      // this.handleUserInfo();
    },
    onReady: function () {

    },
    onShow: function () {
      this.handleUserInfo();
    },
    onHide: function () {

    },
    onPullDownRefresh: function () {
      this.handleUserInfo();
      wx.stopPullDownRefresh()
    },
    onReachBottom: function () {

    },
    onShareAppMessage: function () {

    },
    handleUserInfo: function () {
      if (storage.getToken() != '') {
        this.setData({
          userName: storage.getMember().memberNickName,
          userAvatar: storage.getMember().memberAvatarPath,
        });
      }
    },
    handleMyAddress: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/my/archives/index?isSelect=' + false
          })
        }
      })
    },
    handleLogin: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          this.setData({
            userName: storage.getMember().memberNickName,
            userAvatar: storage.getMember().memberAvatarPath,
          });
        }.bind(this)
      })
    }
});
