const china = require("../../../util/china.js");
const constant = require("../../../util/constant.js");
const notification = require('../../../util/notification.js');
const http = require('../../../util/http.js');
const util = require('../../../util/util.js');


Page({

  /**
   * 页面的初始数据
   */
  data: {
    sex: 2,
    arriage: false,
    isAllergy: false,
    doDrink: false,
    doSmoke: false,
    doEatRegularly: false,
    doRelieveNormally: false,
    memberName: '',
    memberHeight: '',
    memberWeight: '',
    memberAge: '',
    memberRelation: ''
  },
  
  bindPickerChangeDoRelieveNormally: function(e) {
    this.setData({
      doRelieveNormally: e.detail.value,
    });
  },
  bindPickerChangeDoEatRegularly: function (e) {
    this.setData({
      doEatRegularly: e.detail.value,
    });
  },
  bindPickerChangeDoSmoke: function (e) {
    this.setData({
      doSmoke: e.detail.value,
    });
  },
  bindPickerChangeSex: function (e) {
    console.log(e)
    this.setData({
      sex: e.detail.value
    });
  },
  bindPickerChangeDoDrink: function (e) {
    this.setData({
      doDrink: e.detail.value
    });
  },
  bindPickerChangeArriage: function (e) {
    this.setData({
      arriage: e.detail.value
    });
  },
  bindPickerChangeIsAllergy: function (e) {
    this.setData({
      isAllergy: e.detail.value,
    })
  },
  handleSubmit: function (e) {
    if (e.detail.value.memberRelation == '') {
      wx.showToast({
        title: '请输入与患者关系',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (e.detail.value.memberName == ''){
      wx.showToast({
        title: '请输入姓名',
        icon: 'none',
        duration: 2000
      })
      return
    }
    http.request({
      isToast: true,
      url: '/jiyi/health/archive/mobile/v1/save',
      data: {
        healthArchiveDoDrink: this.data.doDrink,  //是否喝酒
        healthArchiveDoEatRegularly: this.data.doEatRegularly,  //是否饮食规律
        healthArchiveDoRelieveNormally: this.data.doRelieveNormally,  //是否大小便正常
        healthArchiveDoSmoke: this.data.doSmoke,  //是否抽烟
        healthArchiveGender: this.data.sex,  //性别
        healthArchiveHasHistoryOfAllergy: this.data.isAllergy,  //是否有过敏史
        healthArchiveHeight: e.detail.value.memberHeight,  //身高
        healthArchiveName: e.detail.value.memberName,  //姓名
        healthArchiveRelation: e.detail.value.memberRelation,  //关系
        healthArchiveWeight: e.detail.value.memberWeight,  //体重
      },
      success: function (resp) {
        util.showSuccessToast({
          title: '保存成功',
          success: function () {
            wx.navigateBack({});
          }
        });
      }.bind(this)
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      sex: 2,
      arriage: false,
      isAllergy: false,
      doDrink: false,
      doSmoke: false,
      doEatRegularly: false,
      doRelieveNormally: false,
      memberName: '',
      memberHeight: '',
      memberWeight: '',
      memberAge: '',
      memberRelation: ''
    })
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})