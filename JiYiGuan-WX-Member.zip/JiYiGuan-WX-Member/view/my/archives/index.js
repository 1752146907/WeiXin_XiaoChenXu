const china = require("../../../util/china.js");
const constant = require("../../../util/constant.js");
const notification = require('../../../util/notification.js');
const http = require('../../../util/http.js');
const util = require('../../../util/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    archivesList:[],
    dialogId: '',
    isSelect: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      dialogId: options.dialogId,
      isSelect: options.isSelect == 'true'
    });
  },
  handleClick: function (e) {
    if (this.data.isSelect) {
      // notification.emit("archives", e.currentTarget.id);
      // setTimeout(function () {
          http.request({
            url: '/jiyi/dialog/mobile/v1/connect/health/archive',
            data: {
              dialogId: this.data.dialogId,
              healthArchiveId: e.currentTarget.id
            },
            success: function (data) {
              wx.navigateBack();
            }
          })
      // }, 300);
    } else {
      wx.navigateTo({
        url: '/view/my/archives/editArchives?id=' + e.currentTarget.dataset.id + '&dialogId=' + this.data.dialogId
      });
    }

   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.handlCartList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  handlCartList: function () {
    var slef = this;
    http.request({
      url: '/jiyi/health/archive/mobile/v1/list',
      data: {},
      success: function (data) {
        var cartList = [];
        slef.setData({
          archivesList: data.data
        });
        if (slef.data.isSelect) {
          wx.showToast({
            title: '请选择您的档案',
            icon: 'none',
            duration: 2000
          })
        }
      }
    });
  },

  handlAddArchives: function () {
    wx.navigateTo({
      url: '/view/my/archives/addArchives'
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.handlCartList();
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})