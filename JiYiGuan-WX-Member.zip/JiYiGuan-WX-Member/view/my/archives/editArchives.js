const china = require("../../../util/china.js");
const constant = require("../../../util/constant.js");
const notification = require('../../../util/notification.js');
const http = require('../../../util/http.js');
const util = require('../../../util/util.js');


Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: "",
    pacientId: "",
    sex: false,
    arriage: false,
    isAllergy: false,
    doDrink: false,
    doSmoke: false,
    doEatRegularly: false,
    doRelieveNormally: false,
    memberName: '',
    memberHeight: '',
    memberWeight: '',
    memberAge: '',
    memberRelation: ''
  },
  bindPickerChangeDoRelieveNormally: function(e) {
    this.setData({
      doRelieveNormally: e.detail.value,
    });
  },
  bindPickerChangeDoEatRegularly: function (e) {
    this.setData({
      doEatRegularly: e.detail.value,
    });
  },
  bindPickerChangeDoSmoke: function (e) {
    this.setData({
      doSmoke: e.detail.value,
    });
  },
  bindPickerChangeSex: function (e) {
    this.setData({
      sex: e.detail.value
    });
  },
  bindPickerChangeDoDrink: function (e) {
    this.setData({
      doDrink: e.detail.value
    });
  },
  bindPickerChangeArriage: function (e) {
    this.setData({
      arriage: e.detail.value
    });
  },
  bindPickerChangeIsAllergy: function (e) {
    this.setData({
      isAllergy: e.detail.value,
    })
  },
  bindPickerChangeDel: function () {
    wx.showModal({
      title: '确认删除',
      content: '此操作不可逆，确认删除该档案吗？',
      confirmText: "确认",
      cancelText: "取消",
      success: function (res) {
        if (res.confirm) {
          http.request({
            isToast: true,
            url: '/jiyi/health/archive/mobile/v1/delete',
            data: {
              healthArchiveId: this.data.id
            },
            success: function (resp) {
              util.showSuccessToast({
                title: '删除成功',
                success: function () {
                  wx.navigateBack({});
                }
              });
            }.bind(this)
          });
        }
      }.bind(this)
    });
  },
  handleSubmit: function (e) {
    if (e.detail.value.memberRelation == '') {
      wx.showToast({
        title: '请输入与患者关系',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (e.detail.value.memberName == ''){
      wx.showToast({
        title: '请输入姓名',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (e.detail.value.memberHeight == '') {
      wx.showToast({
        title: '请输入身高',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (e.detail.value.memberWeight == '') {
      wx.showToast({
        title: '请输入体重',
        icon: 'none',
        duration: 2000
      })
      return
    }
    http.request({
      isToast: true,
      url: '/jiyi/health/archive/mobile/v1/update',
      data: {
        healthArchiveId: this.data.id,   //档案id
        patientId: this.data.pacientId,  //咨询者id
        healthArchiveDoDrink: this.data.doDrink,  //是否喝酒
        healthArchiveDoEatRegularly: this.data.doEatRegularly,  //是否饮食规律
        healthArchiveDoRelieveNormally: this.data.doRelieveNormally,  //是否大小便正常
        healthArchiveDoSmoke: this.data.doSmoke,  //是否抽烟
        healthArchiveGender: this.data.sex,  //性别
        healthArchiveHasHistoryOfAllergy: this.data.isAllergy,  //是否有过敏史
        healthArchiveHeight: e.detail.value.memberHeight,  //身高
        healthArchiveName: e.detail.value.memberName,  //姓名
        healthArchiveRelation: e.detail.value.memberRelation,  //关系
        healthArchiveWeight: e.detail.value.memberWeight,  //体重
      },
      success: function (resp) {
        util.showSuccessToast({
          title: '保存成功',
          success: function () {
            wx.navigateBack({});
          }
        });
      }.bind(this)
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id: options.id
    });
    this.onLoadInfo();
  },
  onLoadInfo: function () {
    http.request({
      isToast: true,
      url: '/jiyi/health/archive/mobile/v1/find',
      data: {
        healthArchiveId: this.data.id,
      },
      success: function (data) {
        this.setData({
          pacientId: data.data.patientId,
          memberName: data.data.healthArchiveName,
          memberHeight: data.data.healthArchiveHeight,
          memberWeight: data.data.healthArchiveWeight,
          sex: data.data.healthArchiveGender,
          memberRelation: data.data.healthArchiveRelation,
          doSmoke: data.data.healthArchiveDoSmoke,
          doDrink: data.data.healthArchiveDoDrink,
          doEatRegularly: data.data.healthArchiveDoEatRegularly,
          doRelieveNormally: data.data.healthArchiveDoRelieveNormally,
          isAllergy: data.data.healthArchiveHasHistoryOfAllergy,
        })
      }.bind(this)
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.onLoadInfo();
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})