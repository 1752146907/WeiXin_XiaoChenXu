const constant = require("./util/constant.js");
const chat = require("./util/chat.js");

App({
  onLaunch: function () {
    wx.getSystemInfo({
      success: function (res) {
        this.globalData.windowWidth = res.windowWidth;
        this.globalData.windowHeight = res.windowHeight;
      }.bind(this)
    });
    chat.initWebSocket();
    chat.onWebSocketMessageNotInConsult();
  },
  globalData: {
    userInfo: {},
    windowWidth: 0,
    windowHeight: 0,
    open_id: '',
    wsIsOpen: false
  }
})