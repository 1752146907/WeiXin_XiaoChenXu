const constant = {
  appId: '1012272162714206210',
  wechatAppId: 'wxccad1afcac054867',
  wshost: 'ws://tapi.vpluslab.com',
  host: 'http://tapi.vpluslab.com',
  imageHost: 'http://tapi.vpluslab.com',
  // wshost: 'ws://192.168.1.9:20801',
  // host: 'http://192.168.1.9:8088',
  // imageHost: 'http://192.168.1.9:8088',
  platform: 'WechatMini',
  version: '1.0.0',
  color: '#e994a9',
  duration: 2000,
  timestamp: Date.parse(new Date())
}

module.exports = constant;