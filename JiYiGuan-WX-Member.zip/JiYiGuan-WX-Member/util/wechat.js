const constant = require("./constant.js");
const http = require("./http.js");
const storage = require("./storage.js");
const notification = require("./notification.js");

function auth(config) {
  var token = storage.getToken();
  if (token == '') {
    if (storage.getIsLanuch()) {
      if (config.checkLogin) {
        wx.navigateTo({
          url: '/view/login/wx-login'
        });
        notification.on("login-callback", this, function (data) {
          if (data.success && config.success) {
            config.success(data);
          } else {
            if (config.fail) {
              config.fail();
            }
          }
        });
      }
    } else {
      storage.setIsLanuch();
      wx.navigateTo({
        url: '/view/login/wx-login'
      });
      notification.on("login-callback", this, function (data) {
        if (data.success && config.success) {
          config.success();
        } else {
          if (config.fail) {
            config.fail();
          }
        }
      });
    }
  } else {
    config.success();
  }
}

function login(userinfo, config) {
  if (userinfo.detail.errMsg == 'getUserInfo:ok') {
    wx.login({
      success: function (res) {
        var code = res.code;
        if (code) {
          http.request({
            url: '/wechat/wechat/mini/mobile/v1/auth',
            data: {
              wechatMiniAppId: constant.wechatAppId,
              jsCode: code,
              encryptedData: userinfo.detail.encryptedData,
              iv: userinfo.detail.iv,
            },
            success: function (data) {
              console.log(data)
              if (data.data.openId) {
                var params = {
                  memberRole: false,
                  appId: constant.appId,
                  wechatOpenId: data.data.openId,
                  token: data.data.token,
                  wechatUnionId: data.data.unionId ? data.data.unionId : '',
                  memberArea: data.data.city ? data.data.city : '',
                  wechatCountry: data.data.country ? data.data.country : '',
                  wechatProvince: data.data.province ? data.data.province : '',
                  wechatLanguage: data.data.language ? data.data.language : '',
                  memberAvatarId: "",
                  memberAvatarPath: data.data.avatarUrl ? data.data.avatarUrl : '',
                  memberGender: data.data.gender ? data.data.gender : '',
                  memberNickName: data.data.nickName ? data.data.nickName : '',
                }
                wechatAuthLogin(config, params);
              }
            }.bind(this),
            fail: function () {
              config.fail();
            }
          });
        }
      }.bind(this)
    });
  } else if (userinfo.detail.errMsg == 'getUserInfo:fail auth deny') {
    config.fail();
  }
}

function wechatAuthLogin(config, params) {
  http.request({
    url: '/jiyi/member/mobile/v1/login',
    data: params,
    success: function (data) {
      console.log(data)
      if (data.data.token === undefined || data.data.token === null || data.data.token.trim() === '') {
        config.fail();
        return;
      }
      storage.setToken(data.data.token);
      storage.setOpenId(params.wechatOpenId);
      var member = {
        memberId: data.data.memberId,
        memberAvatarPath: data.data.memberAvatarPath,
        memberNickName: data.data.memberNickName
      }
      storage.setMember(member);
      becomeSubordinate();
      config.success();
    },
    fail: function (scene) {
      config.fail();
    }
  });
}

function becomeSubordinate() {
  var scene = storage.getScene();
  if (scene && scene != '') {
    http.request({
      url: '/xingxiao/member/mobile/v1/become/subordinate',
      data: {
        scene: scene
      },
      success: function (data) {
        if (data.result && data.code == 2) {
          if (data.code == 2) {
            wx.showToast({
              title: data.data.message,
              icon: 'none',
              duration: 2000
            });
          }
          storage.setScene('');
        }
      }.bind(this)
    });
  }
}

module.exports = {
  auth: auth,
  login: login,
  becomeSubordinate: becomeSubordinate
};