const china = require("../../util/china.js");
const constant = require("../../util/constant.js");
const notification = require('../../util/notification.js');
const http = require('../../util/http.js');
const util = require('../../util/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    cartList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.handlCartList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  handlCartList: function () {
    var _this = this;
    http.request({
      isToast: true,
      url: '/xingxiao/memberBankcard/mobile/v1/list',
      data: {},
      success: function (data) {
        var cartList = [];
        _this.setData({
          cartList: data.data
        });
      }
    });
  },

  handlAddCard: () => {
    wx.navigateTo({
      url: '/view/bankCard/addCard'
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})