const constant = require("../../util/constant.js");
const notification = require('../../util/notification.js');
const http = require('../../util/http.js');
const util = require('../../util/util.js');

Page({

  /**
   * 页面的初始数据 
   */
  data: {
    color: constant.color,
    bankName: '',
    userName: '',
    cartNumber: '',
    deliveryIsDefault: false,
    array: ['工商银行', '农业银行', '中国银行', '建设银行', '招商银行', '邮储银行', '交通银行', '浦发银行', '民生银行', '兴业银行', '平安银行', '中信银行', '华夏银行', '广发银行', '光大银行', '北京银行', '宁波银行'],
    selectCartIndex: -1,
    objectArray: [
      {
        id: 1002,
        name: '工商银行'
      },
      {
        id: 1005,
        name: '农业银行'
      },
      {
        id: 1026,
        name: '中国银行'
      },
      {
        id: 1003,
        name: '建设银行'
      },
      {
        id: 1001,
        name: '招商银行'
      },
      {
        id: 1066,
        name: '邮储银行'
      },
      {
        id: 1020,
        name: '交通银行'
      },
      {
        id: 1004,
        name: '浦发银行'
      },
      {
        id: 1006,
        name: '民生银行'
      },
      {
        id: 1009,
        name: '兴业银行'
      },
      {
        id: 1010,
        name: '平安银行'
      },
      {
        id: 1021,
        name: '中信银行'
      },
      {
        id: 1025,
        name: '华夏银行'
      },
      {
        id: 1027,
        name: '广发银行'
      },
      {
        id: 1022,
        name: '光大银行'
      },
      {
        id: 1032,
        name: '北京银行'
      },
      {
        id: 1056,
        name: '宁波银行'
      }
    ],
    bankCode: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },
  bindPickerChange: function (e) {
    var bankCodeIndex = e.detail.value;
    var bankCode = this.data.objectArray[bankCodeIndex].id;
    var bankName = this.data.array[e.detail.value]
    this.setData({
      selectCartIndex: e.detail.value,
      bankCode: bankCode,
      bankName: bankName
    })
  },
  handleSubmit: function (event){
    if (this.data.bankName == '') {
      wx.showToast({
        title: '请选择银行',
        icon: 'none',
        duration: 2000
      });

      return;
    }
    if (event.detail.value.userName == '') {
      wx.showToast({
        title: '请输入持卡人名字',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    if (event.detail.value.cartNumber == '') {
      wx.showToast({
        title: '请输入卡号',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    if (event.detail.value.cartNumber.length < 16 || event.detail.value.cartNumber.length > 19) {
      wx.showToast({
        title: '银行卡号长度必须在16到19之间',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    var num = /^\d*$/;//全数字
    if (!num.exec(event.detail.value.cartNumber)) {
      wx.showToast({
        title: '银行卡号必须全为数字',
        icon: 'none',
        duration: 2000
      });
      return false;

    }
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (strBin.indexOf(event.detail.value.cartNumber.substring(0, 2)) == -1) {
      wx.showToast({
        title: '银行卡号开头6位不符合规范',
        icon: 'none',
        duration: 2000
      });
      return false;
    }

    http.request({
      isToast: true,
      url: '/xingxiao/memberBankcard/mobile/v1/save',
      data: {
        memberBankcardOrganization: this.data.bankName,
        memberBankcardCode: this.data.bankCode,
        memberBankcardNumber: event.detail.value.cartNumber,
        memberBankcardName: event.detail.value.userName,
        memberBankcardIsDefault: event.detail.value.deliveryIsDefault
      }, 
      success: function (data) {
        wx.showToast({
          title: '添加成功',
          icon: 'none',
          duration: 2000
        });
        setTimeout(function () { 
          wx.navigateBack({
            delta: 1,
          })
         }, 2000);
      }.bind(this)
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})