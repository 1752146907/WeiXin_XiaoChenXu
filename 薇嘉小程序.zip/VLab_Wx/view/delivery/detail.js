const china = require("../../util/china.js");
const constant = require("../../util/constant.js");
const notification = require('../../util/notification.js');
const http = require('../../util/http.js');
const util = require('../../util/util.js');

Page({
  data: {
    color: constant.color,
    isEdit: false,
    isDialog: false,
    deliveryId: '',
    deliveryName: '',
    deliveryPhone: '',
    provinceList: [],
    deliveryProvince: "",
    cityList: [],
    deliveryCity: "",
    areaList: [],
    deliveryArea: "",
    provinceCityArea: [0, 0, 0],
    deliveryStreet: '',
    deliveryIsDefault: false
  },
  onUnload: function () {
  },
  onLoad: function (option) {
    var isEdit = false;
    var deliveryId = '';
    var provinceList = [];
    var cityList = [];
    var areaList = [];

    if (typeof (option.deliveryId) != 'undefined') {
      isEdit = true;

      deliveryId = option.deliveryId;
      this.handleFind(deliveryId);
      this.setData({
        deliveryId: deliveryId
      })
    }

    for (var i = 0; i < china.children.length; i++) {
      provinceList.push(china.children[i].name);
    }

    for (var i = 0; i < china.children[0].children.length; i++) {
      cityList.push(china.children[0].children[i].name);
    }

    for (var i = 0; i < china.children[0].children[0].children.length; i++) {
      areaList.push(china.children[0].children[0].children[i].name);
    }

    this.setData({
      isEdit: isEdit,
      deliveryId: deliveryId,
      provinceList: provinceList,
      cityList: cityList,
      areaList: areaList
    });
  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handlDialogOpen: function () {
    this.setData({
      isDialog: true
    });
  },
  handlDialogCancel: function () {
    this.setData({
      isDialog: false
    });
  },
  handlDialogOK: function () {
    var province_index = this.data.provinceCityArea[0];
    var city_index = this.data.provinceCityArea[1];
    var area_index = this.data.provinceCityArea[2];

    var deliveryProvince = china.children[province_index].name;
    var deliveryCity = china.children[province_index].children[city_index].name;
    var deliveryArea = china.children[province_index].children[city_index].children[area_index].name;

    this.setData({
      deliveryProvince: deliveryProvince,
      deliveryCity: deliveryCity,
      deliveryArea: deliveryArea,
      isDialog: false
    });
  },
  handPickerChange: function (event) {
    if (this.data.isDialog) {
      var provinceCityArea = event.detail.value;
      var province_index = provinceCityArea[0];
      var city_index = provinceCityArea[1];
      var area_index = provinceCityArea[2];

      if (this.data.provinceCityArea[0] != provinceCityArea[0]) {
        city_index = 0;
        area_index = 0;
      } else if (this.data.provinceCityArea[1] != provinceCityArea[1]) {
        area_index = 0;
      }

      var cityList = [];
      var areaList = [];

      for (var i = 0; i < china.children[province_index].children.length; i++) {
        cityList.push(china.children[province_index].children[i].name);
      }

      for (var i = 0; i < china.children[province_index].children[city_index].children.length; i++) {
        areaList.push(china.children[province_index].children[city_index].children[i].name);
      }

      this.setData({
        cityList: cityList,
        areaList: areaList,
        provinceCityArea: [province_index, city_index, area_index]
      });
    }
  },
  handleFind: function (deliveryId) {
    http.request({
      isToast: true,
      url: '/xingxiao/member/address/mobile/v1/find',
      data: {
        memberAddressId: deliveryId
      },
      success: function (resp) {
        var data = resp.data;

        this.setData({
          deliveryName: data.memberAddressName,
          deliveryPhone: data.memberAddressMobile,
          deliveryProvince: data.memberAddressProvince,
          deliveryCity: data.memberAddressCity,
          deliveryArea: data.memberAddressArea,
          deliveryStreet: data.memberAddressDetail,
          deliveryIsDefault: data.memberAddressIsDefault
        });

      }.bind(this)
    });
  },
  handelDel: function (e) {
    var slef = this;
    wx.showModal({
      title: '确定删除',
      content: '您确定删除该地址吗？',
      confirmText: "确定",
      cancelText: "返回",
      success: function (res) {
        if (res.confirm) {
          http.request({
            isToast: true,
            url: '/xingxiao/member/address/mobile/v1/delete',
            data: {
              memberAddressId: slef.data.deliveryId
            },
            success: function () {
              util.showSuccessToast({
                title: '修改成功',
                success: function () {
                  wx.navigateBack({});
                }
              });
            }.bind(this)
          })
        } else {
          // console.log('用户点击辅助操作')
        }
      }
    });
  },
  handleSubmit: function (event) {
    var deliveryName = event.detail.value.deliveryName;
    var deliveryPhone = event.detail.value.deliveryPhone;
    var deliveryStreet = event.detail.value.deliveryStreet;
    var deliveryIsDefault = event.detail.value.deliveryIsDefault;

    if (deliveryName == '') {
      util.showFailToast({
        title: '请输入收货人'
      });

      return;
    }

    if (deliveryPhone == '') {
      util.showFailToast({
        title: '请输入手机号码'
      });

      return;
    } else {
      if (!util.isPhone(deliveryPhone)) {
        util.showFailToast({
          title: '手机格式不对'
        });

        return;
      }
    }

    if (this.data.area == '') {
      util.showFailToast({
        title: '请选择省市区'
      });

      return;
    }

    if (deliveryStreet == '') {
      util.showFailToast({
        title: '请输入详细地址'
      });

      return;
    }

    var province_index = this.data.provinceCityArea[0];
    var city_index = this.data.provinceCityArea[1];
    var area_index = this.data.provinceCityArea[2];

    var deliveryProvince_id = china.children[province_index].id;
    var deliveryCity_id = china.children[province_index].children[city_index].id;
    var deliveryArea_id = china.children[province_index].children[city_index].children[area_index].id;

    var deliveryProvince_name = china.children[province_index].name;
    var deliveryCity_name = china.children[province_index].children[city_index].name;
    var deliveryArea_name = china.children[province_index].children[city_index].children[area_index].name;

    http.request({
      isToast: true,
      url: '/xingxiao/member/address/mobile/v1/' + (this.data.isEdit ? 'update' : 'save'),
      data: {
        memberAddressId: this.data.deliveryId,
        memberAddressName: deliveryName,
        memberAddressMobile: deliveryPhone,
        memberAddressProvinceId: deliveryProvince_id,
        memberAddressProvince: deliveryProvince_name,
        memberAddressCityId: deliveryCity_id,
        memberAddressCity: deliveryCity_name,
        memberAddressAreaId: deliveryArea_id,
        memberAddressArea: deliveryArea_name,
        memberAddressDetail: deliveryStreet,
        memberAddressIsDefault: deliveryIsDefault,
      },
      success: function (data) {
        notification.emit('notification_delivery_index_load', data);

        util.showSuccessToast({
          title: '保存成功',
          success: function () {
            wx.navigateBack();
          }
        });
      }.bind(this)
    });
  }
});
