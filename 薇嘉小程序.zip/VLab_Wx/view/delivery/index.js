const notification = require('../../util/notification.js');
const constant = require("../../util/constant.js");
const http = require("../../util/http.js");
const storage = require("../../util/storage.js");

Page({
    data: {
        color: constant.color,
        isLoad: false,
        isSelect: false,
        deliveryList: []
    },
    onUnload: function () {
        notification.remove('notification_delivery_index_load', this);
    },
    onLoad: function (option) {
        notification.on('notification_delivery_index_load', this, function (data) {
            this.handleLoad();
        });

        var isSelect = false;

        
        if (typeof (option.isSelect) != 'undefined') {
            isSelect = option.isSelect;
        }

        this.setData({
            isSelect: isSelect
        });

        this.handleLoad();
    },
    onReady: function () {

    },
    onShow: function () {
      this.handleLoad();
    },
    onHide: function () {

    },
    onPullDownRefresh: function () {

    },
    onReachBottom: function () {

    },
    onShareAppMessage: function () {

    },
    handleLoad: function () {
      http.request({
        isToast: true,
        url: '/xingxiao/member/address/mobile/v1/list',
          data: {

          },
          success: function (data) {
              this.setData({
                  isLoad: true,
                  deliveryList: data.data
              });
          }.bind(this)
      });
    },
    handleClick: function (event) {
        var deliveryId = event.currentTarget.id;
        var delivery = {};
        var deliveryList = this.data.deliveryList.list;
        if (this.data.isSelect) {
          console.log(this.data.isSelect);
          for (var i = 0; i < deliveryList.length; i++) {
              if (deliveryList[i].memberAddressId == deliveryId) {
                deliveryList[i].isSelect = true;

                delivery = deliveryList[i];
                break;
              }
            }

            notification.emit('notification_order_check_delivery', delivery);

            this.setData({
                deliveryList: deliveryList
            });
            setTimeout(function () {
                wx.navigateBack();
            }, 500);
        } else {
            wx.navigateTo({
                url: '/view/delivery/detail?deliveryId=' + deliveryId
            });
        }
    }
});
