const http = require("../../util/http.js");
const constant = require("../../util/constant.js");


Page({
  data: {
    imageHost: constant.imageHost,
    windowWidth: getApp().globalData.windowWidth,
    isLoad: false,
    qrcode: ''
  },
  onUnload: function () {

  },
  onLoad: function () {
    this.handleLoad();
  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleLoad: function () {
    http.request({
      is_toast: false,
      url: '/xingxiao/member/mobile/v1/myWxaCode',
      data: {

      },
      success: function (data) {
        this.setData({
          isLoad: true,
          qrcode: data.data.wxaCodePath
        });
      }.bind(this)
    });
  }
});
