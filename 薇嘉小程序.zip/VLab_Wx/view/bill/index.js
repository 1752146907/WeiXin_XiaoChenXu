const http = require("../../util/http.js");

Page({
  data: {
    isLoad: false,
    billList: []
  },
  onUnload: function () {

  },
  onLoad: function () {
    this.handleLoad();
  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleLoad: function () {
    http.request({
      is_toast: false,
      url: '/xingxiao/shareWithdrawApplication/mobile/v1/list',
      data: {
        page_index: 1,
        page_size: 20,
      },
      success: function (data) {
        this.setData({
          isLoad: true,
          billList: data.data.list
        });
      }.bind(this)
    });
  }
});
