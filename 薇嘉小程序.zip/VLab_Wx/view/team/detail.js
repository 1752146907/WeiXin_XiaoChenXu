const china = require("../../util/china.js");
const notification = require('../../util/notification.js');
const constant = require("../../util/constant.js");
const http = require('../../util/http.js');
const util = require('../../util/util.js');

Page({
  data: {
    color: constant.color,
    imageHost: constant.imageHost,
    memberList: []    
  },
  onUnload: function () {
    notification.remove("notification_team_detail_load", this);
  },
  onLoad: function (option) {
    notification.on("notification_team_detail_load", this, function (data) {
      this.handleLoadMySubordinate();
    });
    this.handleLoadMySubordinate();
  },
  handleLoadMySubordinate: function () {
    http.request({
      isToast: true,
      url: '/xingxiao/member/mobile/v1/my/subordinates',
      data: {},
      success: function (data) {
        var memberList = this.data.memberList;
        if (data.data && data.data.length > 0) {
          for (var i = 0; i < data.data.length; i++) {
            var member = data.data[i];
            member.systemCreateTime = util.timestampToTime(member.systemCreateTime);
            member.memberIsShowChildren = true;
            if (member.children && member.children.length > 0) {
              for (var j = 0; j < member.children.length; j++) {
                member.children[j].systemCreateTime = util.timestampToTime(member.children[j].systemCreateTime);
              }
            }
            memberList.push(member);
          }
        }
        this.setData({
          memberList: memberList
        });
      }.bind(this)
    });
  },
  handleShowChildren: function (e) {
    var index = e.currentTarget.dataset.index;
    var memberList = this.data.memberList;
    memberList[index].memberIsShowChildren = !memberList[index].memberIsShowChildren;
    this.setData({
      memberList: memberList
    });
  },
  onReady: function () {

  },
  onShow: function () {
    
    
  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleLoad: function () {
    http.request({
      url: '/member/team/find',
      data: {
        member_id: this.data.member_id,
      },
      success: function (data) {
        for (var i = 0; i < data.orderList.length; i++) {
          for (var j = 0; j < data.orderList[i].product_list.length; j++) {
            data.orderList[i].product_list[j].product_image_file = constant.host + data.orderList[i].product_list[j].product_image_file;

            data.orderList[i].product_list[j].order_product_price = data.orderList[i].product_list[j].order_product_price.toFixed(2);
          }
          
          data.orderList[i].order_amount = data.orderList[i].order_amount.toFixed(2);
        }

        this.setData({
          isLoad: true,
          member_name: data.member_name,
          user_avatar: data.user_avatar,
          member_level_id: data.member_level_id,
          member_level_name: data.member_level_name,
          member_commission_amount: data.member_commission_amount.toFixed(2),
          member_order_amount: data.member_order_amount.toFixed(2),
          member_status: data.member_status,
          orderList: data.orderList,
          member_level_list: data.member_level_list
        });
      }.bind(this)
    });
  },
  handleRadioChange: function (event) {
    this.setData({
      member_level_id: event.detail.value
    });
  },
  handleSubmit: function () {
    if (this.data.member_level_id == '') {
      util.showFailToast({
        title: '请选择会员等级'
      });

      return;
    }

    http.request({
      url: '/member/children/update',
      data: {
        member_id: this.data.member_id,
        member_level_id: this.data.member_level_id
      },
      success: function (data) {
        util.showSuccessToast({
          title: '提交成功',
          success: function () {
            wx.navigateBack();
          }
        });
      }.bind(this)
    });
  }
});
