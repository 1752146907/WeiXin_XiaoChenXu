const constant = require("../../util/constant.js");
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");

Page({
  data: {
    imageHost: constant.imageHost,
    color: constant.color,
    isLoad: false,
    userName: '',
    userAvatar: '',
    balance: 0.00,
    memberLevelId: '',
    memberLevelName: '',
    memberLevelValue: 999,
    memberCommissionAmount: 0,
    memberOrderAmount: 0,
    memberWaitPay: 0,
    memberWaitSend: 0,
    memberWaitReceive: 0,
    memberStatus: false,
    storage: storage
    },
    onUnload: function () {

    },
    onLoad: function () {
      // this.handleUserInfo();
    },
    onReady: function () {

    },
    onShow: function () {
      this.handleUserRmb();
      this.handleUserInfo();
    },
    onHide: function () {

    },
    onPullDownRefresh: function () {

    },
    onReachBottom: function () {

    },
    onShareAppMessage: function () {

    },
    getUserData: () => {
      
    },
    handleUserRmb: function () {
      if (storage.getToken() == '') {
        return;
      }
      var _this = this;
      http.request({
        url: '/xingxiao/member/mobile/v1/view',
        data: {

        },
        success: function (data) {
          _this.setData({
            balance: (data.data.memberBalance + data.data.memberWaitBalance).toFixed(2)
          })
        },
        fail: function () {

        }
      });
      
    },
    handleLogin: function () {
      if (storage.getToken() == '') {
        wechat.auth({
          checkLogin: true,
          success: function () {
            this.handleUserRmb();
            this.handleUserInfo();
          }.bind(this)
        });
        return;
      }
    },
    handleUserInfo: function () {
      if (storage.getToken() != ''){
        this.setData({
            userName: storage.getMember().memberNickName,
            userAvatar: storage.getMember().memberAvatarPath,
        });

        http.request({
          url: '/xingxiao/sale/order/mobile/v1/statistics',
          data: {

          },
          success: function (data) {
            var memberWaitPay = this.data.memberWaitPay;
            var memberWaitSend = this.data.memberWaitSend;
            var memberWaitReceive = this.data.memberWaitReceive;
            for (var i = 0; i < data.data.length; i++){
              if (data.data[i].saleOrderStatus == "COMPLETE") {
              }
              else if (data.data[i].saleOrderStatus === "WAITING_DELIVERY") {
                memberWaitSend = data.data[i].total
              }
              else if (data.data[i].saleOrderStatus === "WAITING_PAID") {
                memberWaitPay = data.data[i].total
              }
              else if (data.data[i].saleOrderStatus && data.data[i].saleOrderStatus === "WAITING_RECEIVE") {
                memberWaitReceive = data.data[i].total
              }
            }
            this.setData({
              memberWaitPay: memberWaitPay,
              memberWaitSend: memberWaitSend,
              memberWaitReceive: memberWaitReceive,
            });
          }.bind(this)
        });
      }
    },
    handleMoney: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/my/balance/index'
          })
        }
      })
    },
    handleAllOrder: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/order/index?orderFlow='
          })
        }
      })
    },
    handlePaymentOrder: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/order/index?orderFlow=WAITING_PAID'
          })
        }
      })
    },
    handleDeliverOrder: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/order/index?orderFlow=WAITING_DELIVERY'
          })
        }
      })
    },
    handleCollectOrder: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/order/index?orderFlow=WAITING_RECEIVE'
          })
        }
      })
    },
    handleCompleteOrder: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/order/index?orderFlow=COMPLETE'
          })
        }
      })
    },
    handleMyCard: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/bankCard/index'
          })
        }
      })
    },
    handleMyAddress: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/delivery/index'
          })
        }
      })
    },
    handleMyQrcode: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/qrcode/index'
          })
        }
      })
    },
    handleMyTeam: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: "/view/team/detail"
          })
        }
      })
    },
    handleLoad: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          // console.log('登录成功！');
        }
      })
    }
});
