const notification = require('../../../util/notification.js');
const constant = require("../../../util/constant.js");
const http = require("../../../util/http.js");
const storage = require("../../../util/storage.js");
const wechat = require("../../../util/wechat.js");
const util = require("../../../util/util.js");
// view/member/新建文件夹/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    focus: false,
    value: "",
    balance: 0.00,
    defaultBankcard: ""
  },
  bindfocus: function () {
    this.setData({
      focus: true
    })
  },
  bindblur: function () {
    this.setData({
      focus: false
    })
  },
  bindinput: function (e) {
    this.setData({
      value: e.detail.value
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _this = this;
    http.request({
      url: '/xingxiao/member/mobile/v1/view',
      data: {

      },
      success: function (data) {
        _this.setData({
          balance: (data.data.memberBalance + data.data.memberWaitBalance).toFixed(2)
        })
      },
      fail: function () {

      }
    });

    http.request({
      url: '/xingxiao/memberBankcard/mobile/v1/find/default',
      data: {

      },
      success: function (data) {
        var defaultBankcard = data.data.memberBankcardNumber;
        var reg = /^(\d{4})\d+(\d{4})$/;
        defaultBankcard = defaultBankcard.replace(reg, "$1 **** **** $2");
        _this.setData({
          defaultBankcard: defaultBankcard
        })
      },
      fail: function () {

      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  handlWithdraw: function () {
    if (this.data.value <= 0) {
      util.showFailToast({
        title: '请输入余额'
      });
      return;
    }
    if (this.data.value > this.data.balance) {
      util.showFailToast({
        title: '余额不足'
      });
      return;
    }
    if (this.data.defaultBankcard == '') {
      util.showFailToast({
        title: '请先添加银行卡'
      });
      return;
    }
    http.request({
      isToast: true,
      url: '/xingxiao/shareWithdrawApplication/mobile/v1/save',
      data: {
        amount: this.data.value
      },
      success: function (data) {
        wx.navigateTo({
          url: '/view/bill/index'
        });
      },
      fail: function () {

      }
    })
  }
   
})