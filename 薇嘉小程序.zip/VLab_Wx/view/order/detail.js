const notification = require('../../util/notification.js');
const constant = require("../../util/constant.js");
const http = require("../../util/http.js");
const storage = require("../../util/storage.js");
const wechat = require("../../util/wechat.js");
const util = require("../../util/util.js");

Page({
  data: {
    order: {
      saleOrderId: '',
      saleOrderStatus: '',
      saleOrderStatusText: '',
      productList: [],
      saleOrderExpressAmount: 0,
      saleOrderTotalAmount: 0,
      saleOrderPayAccount: 0,
      saleOrderDiscountAmount: 0,
      saleOrderReceiveName: '',
      saleOrderReceiveMobile: '',
      saleOrderReceiveAddress: '',
      saleOrderTime: 0,
      saleOrderPayWay: '微信支付',
      saleOrderPayTime: 0,
      saleOrderLogistics: ''
    },
    storage: storage
  },
  onUnload: function () {
    notification.remove("notification_order_result_pay", this);
  },
  onLoad: function (option) {
    notification.on("notification_order_result_pay", this, function (data) {
      this.handleLoad();
    });

    this.setData({
      saleOrderId: option.order_id
    });

    this.handleLoad();

    notification.on('notification_order_check_delivery', this, function (data) {
      var info = data;
      var slef = this;
      http.request({
        url: '/xingxiao/sale/order/mobile/v1/address/update',
        data: {
          saleOrderId: slef.data.saleOrderId,
          memberAddressId: data.memberAddressId
        },
        success: function () {
          slef.setData({
            order: {
              saleOrderId: info.memberAddressId,
              saleOrderReceiveName: info.memberAddressName,
              saleOrderReceiveMobile: info.memberAddressMobile,
              saleOrderReceiveAddress: info.memberAddressProvince + info.memberAddressCity + info.memberAddressArea
            }
          });
        },
        fail: function () {

        }
      });

    });
  },
  
  onReady: function () {

  },
  onShow: function () {
    
  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleLoad: function () {
    http.request({
      url: '/xingxiao/sale/order/mobile/v1/find',
      data: {
        saleOrderId: this.data.saleOrderId
      },
      success: function (data) {
        var orderStatusList = constant.orderStatusList;
        var orderStatusText = '';
        var address = '';
        for (var i = 0; i < orderStatusList.length; i++) {
          if (orderStatusList[i].order_status_value == data.data.saleOrderStatus) {
            orderStatusText = orderStatusList[i].order_status_name;

            break;
          }
        }

        for (var i = 0; i < data.data.saleOrderProductList.length; i++) {
          data.data.saleOrderProductList[i].productImagePath = constant.imageHost + data.data.saleOrderProductList[i].productImagePath;

          data.data.saleOrderProductList[i].productPrice = data.data.saleOrderProductList[i].productPrice.toFixed(2);
        }

        data.data.saleOrderPayAccount = data.data.saleOrderPayAccount.toFixed(2);
        address = data.data.saleOrderReceiveProvince + data.data.saleOrderReceiveCity + data.data.saleOrderReceiveArea + data.data.saleOrderReceiveAddress;
        this.setData({
          order: {
            saleOrderId: data.data.saleOrderId,
            saleOrderStatus: data.data.saleOrderStatus,
            saleOrderStatusText: orderStatusText,
            productList: data.data.saleOrderProductList,
            saleOrderExpressAmount: data.data.saleOrderExpressAmount,
            saleOrderTotalAmount: data.data.saleOrderTotalAmount,
            saleOrderDiscountAmount: data.data.saleOrderDiscountAmount,
            saleOrderPayAccount: data.data.saleOrderPayAccount,
            saleOrderReceiveName: data.data.saleOrderReceiveName,
            saleOrderReceiveMobile: data.data.saleOrderReceiveMobile,
            saleOrderReceiveAddress: address,
            saleOrderTime: util.formatTime(data.data.systemCreateTime),
          },
          saleOrderLogistics: data.data.saleOrderExpressList
        });
      }.bind(this)
    });
  },
  handlePay: function () {
    if (this.data.order.saleOrderReceiveName == '' || this.data.order.saleOrderReceiveMobile == '' || this.data.order.saleOrderReceiveAddress == '') {
      return;
    }
    if (this.data.order.saleOrderId == '' || this.data.order.saleOrderStatus != 'WAITING_PAID') {
      return;
    }
    wechat.auth({
      success: function (data) {
        http.request({
          isToast: true,
          url: '/wechat/wechat/pay/mobile/v1/unified/order',
          data: {
            outTradeNo: this.data.order.saleOrderId,
            openId: storage.getOpenId(),
            tradeType: 'JSAPI',
            body: '微信支付',
            totalFee: (this.data.order.saleOrderPayAccount) * 100,
            notifyUrl: ''
          },
          // this.data.order.saleOrderPayAccount
          success: function (data) {
            wx.requestPayment({
              nonceStr: data.data.nonceStr,
              package: data.data.packageStr,
              signType: data.data.signType,
              paySign: data.data.paySign,
              appId: data.data.appId,
              timeStamp: data.data.timeStamp,
              success: function (response) {
                
              },
              fail: function (response) {

              },
              complete: function (response) {
                this.handleLoad();
              }.bind(this)
            })
          }.bind(this)
        });
      }.bind(this),
      fail: function () {

      }
    });
  }
});