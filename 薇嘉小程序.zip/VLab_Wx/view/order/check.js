const constant = require("../../util/constant.js");
const notification = require('../../util/notification.js');
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");
const Quantity = require('../../component/quantity/index');

Page(Object.assign({}, Quantity, {
  data: {
    memberAddressId: '',
    memberAddressName: '',
    memberAddressMobile: '',
    memberAddressProvince: '',
    memberAddressCity: '',
    memberAddressArea: '',
    memberAddressDetail: '',
    saleOrderProductList: [],
    totalAmount: 0,
    expressAmount: 0
  },
  onUnload: function () {
    notification.remove('notification_order_check_delivery', this);
  },
  onLoad: function (option) {
    if (option.saleOrderProductList && option.totalAmount) {
      this.setData({
        saleOrderProductList: JSON.parse(option.saleOrderProductList),
        totalAmount: parseFloat(option.totalAmount)
      });
      this.handleLoadDefaultAddress();
      notification.on('notification_order_check_delivery', this, function (data) {
        if (data.memberAddressId) {
          this.setData({
            memberAddressId: data.memberAddressId,
            memberAddressName: data.memberAddressName,
            memberAddressMobile: data.memberAddressMobile,
            memberAddressProvince: data.memberAddressProvince,
            memberAddressCity: data.memberAddressCity,
            memberAddressArea: data.memberAddressArea,
            memberAddressDetail: data.memberAddressDetail
          })
        }
      });
    }
  },
  haledToDelivery: function () {
    wx.navigateTo({
      url: '/view/delivery/index?isSelect=true'
    });
  },
  handleLoadDefaultAddress: function () {
    http.request({
      isToast: true,
      url: '/xingxiao/member/address/mobile/v1/find/default',
      data: {},
      success: function (data) {
        if (data.data && data.data.memberAddressId) {
          this.setData({
            memberAddressId: data.data.memberAddressId,
            memberAddressName: data.data.memberAddressName,
            memberAddressMobile: data.data.memberAddressMobile,
            memberAddressProvince: data.data.memberAddressProvince,
            memberAddressCity: data.data.memberAddressCity,
            memberAddressArea: data.data.memberAddressArea,
            memberAddressDetail: data.data.memberAddressDetail
          });
        }
      }.bind(this)
    })
  },
  handleCreateOrder: function () {
    if (this.data.memberAddressId == '') {
      return;
    }
    if (this.data.totalAmount <= 0) {
      return;
    }
    if (this.data.saleOrderProductList.length == 0) {
      return;
    }
    http.request({
      isToast: true,
      url: '/xingxiao/sale/order/mobile/v1/save',
      data: {
        saleOrderProductList: this.data.saleOrderProductList,
        memberAddressId: this.data.memberAddressId,
        memberCouponId: "",
        memberInvoiceId: "",
        saleOrderDeliverPattern: "",
        saleOrderIsOpenInvoice: false,
        saleOrderRemark: "",
        saleOrderFrom: "V+Lab_wx",
      },
      success: function (data) {
        if (data.result && data.data && data.data.saleOrderId && data.data.saleOrderPayAccount) {
          this.handlePay(data.data.saleOrderId,  data.data.saleOrderPayAccount);
        }
      }.bind(this)
    });
  },
  handlePay: function (outTradeNo, totalFee) {
    wechat.auth({
      success: function (data) {
        http.request({
          isToast: true,
          url: '/wechat/wechat/pay/mobile/v1/unified/order',
          data: {
            outTradeNo: outTradeNo,
            openId: storage.getOpenId(),
            tradeType: 'JSAPI',
            body: '微信支付',
            totalFee: totalFee * 100,
            notifyUrl: ''
          },
          success: function (data) {
            wx.requestPayment({
              nonceStr: data.data.nonceStr,
              package: data.data.packageStr,
              signType: data.data.signType,
              paySign: data.data.paySign,
              appId: data.data.appId,
              timeStamp: data.data.timeStamp,
              success: function (response) {
                
              },
              complete: function (response) {
                setTimeout(function () {
                  wx.reLaunch({
                    url: '/view/product/index?saleOrderId=' + outTradeNo,
                  });
                }, 300)
              }
            })
          }.bind(this),
          file: function(){

          }
        });
      }.bind(this),
      fail: function () {

      }
    });
  },

  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  }
}));