const notification = require('../../util/notification.js');
const constant = require("../../util/constant.js");
const http = require("../../util/http.js");

Page({
  data: {
    orderStatusList: constant.orderStatusList,
    windowWidth: getApp().globalData.windowWidth,
    sliderOffset: 0,
    sliderLeft: 0,
    sliderWidth: 0,
    isoad: false,
    list: [],
    orderFlow: '',
    orderList: [],
    pageIndex: 1,
    pageSize: 8
  },
  onUnload: function () {
    notification.remove("notification_order_result_pay", this);
  },
  onLoad: function (option) {
    notification.on("notification_order_result_pay", this, function (data) {
      this.handleLoad();
    });

    var index = 0;
    for (var i = 0; i < this.data.orderStatusList.length; i++) {
      if (option.orderFlow == this.data.orderStatusList[i].order_status_value) {
        index = i;

        break;
      }
    }

    var sliderWidth = this.data.windowWidth / this.data.orderStatusList.length;

    this.setData({
      sliderLeft: 0,
      sliderOffset: sliderWidth * index,
      sliderWidth: sliderWidth,
      orderFlow: option.orderFlow
    });

  },
  onReady: function () {

  },
  onShow: function () {
    this.handleLoad();
  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleLoad: function () {
    http.request({
      url: '/xingxiao/sale/order/mobile/v1/list',
      data: {
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize,
        saleOrderStatus: this.data.orderFlow
      },
      success: function (data) {
        var orderList = [];
        var orderList = data.data.list;
        for (var i = 0; i < orderList.length; i++) {
          for (var j = 0; j < orderList[i].saleOrderProductList.length; j++) {
            orderList[i].saleOrderProductList[j].productImagePath = constant.imageHost + orderList[i].saleOrderProductList[j].productImagePath;

            orderList[i].saleOrderProductList[j].productPrice = orderList[i].saleOrderProductList[j].productPrice.toFixed(2);
          }

          orderList[i].saleOrderPayAccount = orderList[i].saleOrderPayAccount.toFixed(2);

          if (orderList[i].saleOrderStatus == this.data.orderFlow || this.data.orderFlow == '') {
            if (orderList.length > orderList.length) {
              orderList.push(orderList[i]);
            }
          }
        }

        this.setData({
          isoad: true,
          list: data,
          orderList: orderList
        });
      }.bind(this)
    });
  },
  handleTab: function (event) {
    var orderFlow = event.currentTarget.id;
    var orderList = [];
    this.setData({
      orderFlow: orderFlow
    });
    this.handleLoad();
    this.setData({
      sliderOffset: event.currentTarget.offsetLeft
    });
  },
  onReachBottom: function () {
    var pageIndex = this.data.pageIndex + 1;
    var pageSize = this.data.pageSize
    this.setData({
      pageIndex: pageIndex,
      pageSize: pageSize
    });
    this.handleLoad();
  }
});
