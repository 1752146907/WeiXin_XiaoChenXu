const constant = require("../../util/constant.js");
const notification = require('../../util/notification.js');
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");
const util = require("../../util/util.js");
const Quantity = require('../../component/quantity/index');
const WxParse = require('../../wxParse/wxParse.js');

Page(Object.assign({}, Quantity, {
  data: {
    imageHost: constant.imageHost,
    productPrice: 0,
    productSkuPriceList: [],
    productInfo: '',
    selectId: 0,
    isLoad: false,
    showSelectActive: true,
    productQuantity: {
      quantity: 1,
      min: 1,
      max: 100
    },
    product_total: 0,
    windowWidth: getApp().globalData.windowWidth,
    tabIndex: 0,
    productIsPay: false,
    skuId: '',
    productId: '1002483230350774273',
    productName: '',
    productImageFile: '',
    productImageFileList: [],
    productContent: [],
    cartCount: [],
    storage: storage
  },
  bindtapActive: function (e) {
    var selectId = e.currentTarget.dataset.id;   
    var slef = this;
    var quantity = slef.data.productQuantity.quantity
    if (e.currentTarget.dataset.index == 0){
      slef.setData({
        productQuantity: {
          quantity: 1,
          min: 1,
          max: 100
      }})
    }
    if (e.currentTarget.dataset.index == 1) {
      slef.setData({
        productQuantity: {
          quantity: 10,
          min: 1,
          max: 100
        }
      })
    }
    if (e.currentTarget.dataset.index == 2) {
      slef.setData({
        productQuantity: {
          quantity: 100,
          min: 1,
          max: 100
        }
      })
    }
    var number = this.data.productQuantity.quantity;
    this.calPriceByNumber(this, number);
  },
  onUnload: function () {

  },
  onLoad: function (options) {
    if (options.saleOrderId) {
      wx.navigateTo({
        url: '/view/order/detail?order_id=' + options.saleOrderId
      });
    }

    if (options.scene) {
      var scene = decodeURIComponent(options.scene);
      storage.setScene(scene);
      if (storage.getToken() == '') {
        wechat.auth({
          checkLogin: true,
          success: function () {
           
          }.bind(this)
        });
      } else {
        wechat.becomeSubordinate();
      }
    }
  },
  onReady: function () {

  },
  onShow: function () {
    this.handleLoad();
  },
  onHide: function () {

  },
  onPullDownRefresh: function () {

  },
  onReachBottom: function () {

  },
  onShareAppMessage: function () {

  },
  handleZanQuantityChange(event) {
    
    var componentId = event.componentId;
    var number = event.quantity;

    this.calPriceByNumber(this, number);
  },
  handleImageLoad: function (event) {
    var width = event.detail.width;
    var height = event.detail.height;
    var index = event.currentTarget.dataset.index;
    this.data.productContent[index].attr.height = (height / width) * getApp().globalData.windowWidth;
    this.setData({
      productContent: this.data.productContent
    });
  },
  handleLoad: function () {
    http.request({
      url: '/xingxiao/product/mobile/v1/view',
      data: {
        productId: this.data.productId
      },
      success: function (data) {
        var productSkuPriceList = this.data.productSkuPriceList;
        var productInfo = this.data;
        var graphics = data.data.productDetail.productDetailContentMobile;
        WxParse.wxParse('graphics', 'html', graphics, this, 5);
        
        this.setData({
          productInfo: data.data,
          productSkuPriceList: data.data.productSkuPriceList,
          productName: data.data.productTitle,
        });
        this.calPriceByNumber(this, 1);
      }.bind(this)
    });
  },
  handleToOrder: function () {
    if (storage.getToken() == '') {
      wechat.auth({
        checkLogin: true,
        success: function () {
        }
      });
      return;
    }
    wx.navigateTo({
      url: '/view/order/check?saleOrderProductList=' + JSON.stringify([
        {
          productId: this.data.productId,
          productImagePath: this.data.productInfo.productImageList[0].imagePath,
          productQuantity: this.data.productQuantity.quantity,
          productSkuId: this.data.selectId,
          productTitle: this.data.productInfo.productTitle,
        }
      ]) + '&totalAmount=' + this.data.product_total
    });
  },
  calPriceByNumber: function (target, number) {
    if (number >= 1 && number < 10) {
      var productSku = target.data.productInfo.productSkuPriceList[0];
      var price = productSku.productSkuPrice;
      target.setData({
        showSelectActive: true,
        selectId: productSku.productSkuId,
        productPrice: price.toFixed(2),
        product_total: (price * number).toFixed(2)
      });
      if(number != 1) {
        target.setData({
          showSelectActive: false
        })
      }
    } else if (number >= 10 && number < 100) {
      var productSku = target.data.productInfo.productSkuPriceList[1];
      var price = productSku.productSkuPrice / 10;
      target.setData({
        showSelectActive: true,
        selectId: productSku.productSkuId,
        productPrice: price.toFixed(2),
        product_total: (price * number).toFixed(2)
      });
      if (number != 10) {
        target.setData({
          showSelectActive: false
        })
      }
    } else if (number == 100) {
      var productSku = target.data.productInfo.productSkuPriceList[2];
      var price = productSku.productSkuPrice / 100;
      target.setData({
        showSelectActive: true,
        selectId: productSku.productSkuId,
        productPrice: price.toFixed(2),
        product_total: (price * number).toFixed(2)
      });
      if (number != 100) {
        target.setData({
          showSelectActive: false
        })
      }
    }
    target.setData({
      productQuantity: {
        quantity: number,
        min: 1,
        max: 100
      }
    });
  }
}));