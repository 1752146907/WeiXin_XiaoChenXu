const constant = {
  appId: '999557245638234113',
  wechatAppId: 'wxe423115f9bdcd344',
  host: 'https://api.vpluslab.com',
  // host: 'http://localhost:8088',
  imageHost: 'https://api.vpluslab.com',
  platform: 'WAWIPET',
  version: '1.0.0',
  color: '#e994a9',
  duration: 2000,
  orderStatusList: [{ 
    order_status_value: '', 
    order_status_name: '全部' 
  }, { 
    order_status_value: 'WAITING_PAID', 
    order_status_name: '待付款' 
  }, { 
    order_status_value: 'WAITING_DELIVERY', 
    order_status_name: '待发货' 
  }, { 
    order_status_value: 'WAITING_RECEIVE', 
    order_status_name: '待收货' 
  }, { 
    order_status_value: 'COMPLETE', 
    order_status_name: '已完成'
  }],
  timestamp: Date.parse(new Date())
}

module.exports = constant;