const http = require('./http.js');
const constant = require('./constant.js');
const storage = require('./storage.js');

function initWebsocket() {
  connectWebSocket();
  onWebSocketOpen();
  onWebSocketClose();
  onWebSocketError();
  cyclePingWebSocket();
}

function cyclePingWebSocket() {
  setInterval(function () {
    sendPingMessage();
  }, 15000);
}

function connectWebSocket() {
  wx.connectSocket({
    url: constant.wshost + '/jiyi/endpoint/mobile/v1/dialog',
    success: function (res) {
      console.log("connect successfully");
    }
  });
}

function onWebSocketOpen() {
  wx.onSocketOpen(function (res) {
    sendPingMessage();
    console.log("socket is open");
  });
}

function onWebSocketClose() {
  wx.onSocketClose(function (res) {
    console.log("socket is closed");
  });
}

function onWebSocketError() {
  wx.onSocketError(function (res) {
    console.log("socket error");
  });
}

function onWebSocketMessageNotInConsult() {
  wx.onSocketMessage(function (res) {
    tipSumOfUnreadMessage();
  });
}

function sendPingMessage() {
  var msg = {};
  msg.isPing = true;
  msg.token = storage.getToken();
  msg.appId = constant.appId;
  msg.platform = constant.platform;
  msg.version = constant.version;
  msg.timestamp = constant.timestamp;

  wx.sendSocketMessage({
    data: JSON.stringify(msg),
    success: function (e) {
      console.log("ping successfully");
    },
    fail: function (e) {
      console.log("ping fail");
    }
  });
}

function sendTextMessage(dialogId, content) {
  if (content.trim() == '') {
    wx.showToast({
      title: '发送内容不能为空',
      icon: 'none',
      duration: 2000
    })
    return;
  }
  sendMessage(dialogId, 'text', content);
}

function sendImage(dialogId, canvasId) {
  wx.chooseImage({
    sizeType: ['original'],
    success: (res) => {
      drawCanvasAndSendImage(dialogId, canvasId, res.tempFilePaths[0]);
    }
  });
}

function drawCanvasAndSendImage(dialogId, canvasId, filePath) {
  wx.getImageInfo({
    src: filePath,
    success: (res) => {
      var ratio = 2;
      var canvasWidth = res.width
      var canvasHeight = res.height;
      while (canvasWidth > 200 || canvasHeight > 200) {
        canvasWidth = Math.trunc(res.width / ratio)
        canvasHeight = Math.trunc(res.height / ratio)
        ratio++;
      }
      const ctx = wx.createCanvasContext(canvasId);
      ctx.drawImage(filePath, 0, 0, canvasWidth, canvasHeight);
      ctx.draw();
      setTimeout(() => {
        sendImageFromCanvas(dialogId, canvasId);
      }, 300);
    }
  })
}

function sendImageFromCanvas(dialogId, canvasId) {
  wx.canvasToTempFilePath({
    canvasId: canvasId,
    success: (res) => {
      wx.uploadFile({
        url: constant.imageHost + '/file/file/mobile/v1/image/file/upload',
        filePath: res.tempFilePath,
        name: 'file',
        formData: {
          'appId': constant.appId,
          'token': storage.getToken()
        },
        success: (res) => {
          var data = JSON.parse(res.data);
          var fileObj = data.data[0];
          sendMessage(dialogId, 'image', null, fileObj.fileId, fileObj.fileOriginalPath);
        }
      });
    },
    complete: function complete(e) { }
  });
}

function sendMessage(dialogId, mediaType, content, mediaId, mediaPath) {
  var msg = {};
  msg.token = storage.getToken();
  msg.appId = constant.appId;
  msg.platform = constant.platform;
  msg.version = constant.version;
  msg.timestamp = constant.timestamp;

  msg.dialogId = dialogId;
  msg.dialogItemMediaType = mediaType;

  if (mediaType == 'text') {
    msg.dialogItemContent = content;
  } else {
    msg.dialogItemMediaId = mediaId;
    msg.dialogItemMediaPath = mediaPath;
  }
  console.log(msg);

  wx.sendSocketMessage({
    data: JSON.stringify(msg),
    success: function (e) {
      console.log("发送消息成功");
    },
    fail: function (e) {
      if (e.errMsg.indexOf('not connected')) {
        initWebsocket();
      }
      console.log("发送消息失败");
    }
  });
}

function tipSumOfUnreadMessage() {
  if (storage.getToken() == '') {
    return;
  }
  http.request({
    url: '/jiyi/dialog/mobile/v1/unread/message/sum',
    data: {},
    success: function (res) {
      var sumOfUnreadMessage = res.data.sumOfUnreadMessage;
      if (sumOfUnreadMessage > 0) {
        wx.setTabBarBadge({
          index: 0,
          text: sumOfUnreadMessage + ''
        })
      } else {
        wx.removeTabBarBadge({
          index: 0
        })
      }
    }
  });

}

function checkMessageRead(dialogId) {
  http.request({
    url: constant.host + '/jiyi/dialog/mobile/v1/check/message/read',
    data: {
      dialogId: dialogId
    },
    success: (res) => {
      console.log(res);
    }
  });
}

module.exports = {
  tipSumOfUnreadMessage: tipSumOfUnreadMessage,
  checkMessageRead: checkMessageRead,
  initWebSocket: initWebsocket,
  sendTextMessage: sendTextMessage,
  sendImage: sendImage,
  onWebSocketMessageNotInConsult: onWebSocketMessageNotInConsult
};