const constant = {
  appId: '1012272162714206210',
  wechatAppId: 'wx39ab0ac1de022d19',
  wshost: 'ws://tapi.vpluslab.com',
  host: 'http://tapi.vpluslab.com',
  imageHost: 'http://tapi.vpluslab.com',
  // wshost: 'ws://192.168.1.125:20801',
  // host: 'http://192.168.1.125:8088',
  // imageHost: 'http://192.168.1.125:8088',
  platform: 'WAWIPET',
  version: '1.0.0',
  color: '#e994a9',
  duration: 2000,
  timestamp: Date.parse(new Date())
}

module.exports = constant;