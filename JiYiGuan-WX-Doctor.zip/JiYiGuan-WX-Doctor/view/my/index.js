const constant = require("../../util/constant.js");
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");

Page({
  data: {
      imageHost: constant.imageHost,
      userName: '',
      userAvatar: '',
      storage: storage
    },
    onUnload: function () {

    },
    handleMyData: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/detail/detail'
          })
        }
      })
    },
    onLoad: function () {
      // this.handleUserInfo();
    },
    onReady: function () {

    },
    onShow: function () {
      this.handleUserInfo();
    },
    handleLogin: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          this.setData({
            userName: storage.getMember().memberNickName,
            userAvatar: storage.getMember().memberAvatarPath,
          });
        }.bind(this)
      })
    },
    handleUserInfo: function () {
      if (storage.getToken() != '') {
        this.setData({
          userName: storage.getMember().memberNickName,
          userAvatar: storage.getMember().memberAvatarPath,
        });
        // http.request({
        //   isToast: true,
        //   url: '/jiyi/member/admin/v1/find',
        //   data: {
        //   },
        //   success: function (data) {
        //     console.log(this.data)
        //   }.bind(this)
        // });
      }
    },
    onHide: function () {

    },
    onPullDownRefresh: function () {
      this.handleUserInfo();
      wx.stopPullDownRefresh()
    },
    onReachBottom: function () {

    },
    onShareAppMessage: function () {

    },
    handleLogin: function () {
      if (storage.getToken() == '') {
        wechat.auth({
          checkLogin: true,
          success: function () {
            this.setData({
              userName: storage.getMember().memberNickName,
              userAvatar: storage.getMember().memberAvatarPath,
            });
          }.bind(this)
        });
        return;
      }
    },
    handleMyAddress: function () {
      // wechat.auth({
      //   checkLogin: true,
      //   success: function () {
      //     wx.navigateTo({
      //       url: '/view/my/archives/index'
      //     })
      //   }
      // })
      wx.navigateTo({
        url: '/view/my/archives/index'
      })
    },
    handleLoad: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          // console.log('登录成功！');
        }
      })
    }
});
