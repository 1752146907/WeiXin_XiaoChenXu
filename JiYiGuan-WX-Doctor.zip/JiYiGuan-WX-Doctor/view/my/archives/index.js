// view/my/archives/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sexIndex: 0,
    sex: ['男', '女'],
    sexValue: '请选择性别',
    arriageIndex: 0,
    arriage: ['已婚', '未婚'],
    arriageValue: "请选择是否已婚",
    isAllergyIndex: 0,
    isAllergyValue: "请选择是否有过敏史",
    isAllergy: ['是', '否'],
    memberName: '',
    memberHeight: '',
    memberWeight: '',
    memberAge: ''
  },

  bindPickerChangeSex: function (e) {
    this.setData({
      sexIndex: e.detail.value,
      sexValue: this.data.sex[e.detail.value]
    })
    console.log(this.data.sexValue)
  },
  bindPickerChangeArriage: function (e) {
    this.setData({
      arriageIndex: e.detail.value,
      arriageValue: this.data.arriage[e.detail.value]
    })
    console.log(this.data.sexValue)
  },
  bindPickerChangeIsAllergy: function (e) {
    this.setData({
      isAllergyIndex: e.detail.value,
      isAllergyValue: this.data.isAllergy[e.detail.value]
    })
    console.log(this.data.sexValue)
  },
  handleSubmit: function (e) {
    console.log(e.detail.value)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})