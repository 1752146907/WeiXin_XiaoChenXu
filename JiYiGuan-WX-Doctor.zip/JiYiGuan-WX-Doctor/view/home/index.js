const constant = require("../../util/constant.js");
const storage = require("../../util/storage.js");
const http = require("../../util/http.js");
const wechat = require("../../util/wechat.js");
const util = require("../../util/util.js");
const notification = require("../../util/notification.js");
const chat = require("../../util/chat.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageHost: constant.imageHost,
    chatList: [],
    dialogid: '',
    isLogin: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.handleWebSocket();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  handleLogin: function () {
    wechat.auth({
      checkLogin: true,
      success: function () {
        this.setData({
          isLogin: 0
        });
        this.onShow();
      }.bind(this)
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    chat.tipSumOfUnreadMessage();
    this.handleWebSocketMessage();
    if (storage.getToken() != '') {
      this.handleLoad();
    } else {
      this.setData({
        isLogin: 1
      })
    }
  },
  handleIsArchives: function (e) {
    var index = e.currentTarget.dataset.index
    console.log(e.currentTarget.dataset)
    console.log(this.data.chatList[index].healthArchiveId)
    this.setData({
      dialogid: e.currentTarget.dataset.dialogid
    })
    wx.navigateTo({
      url: '/view/consult/chat?dialogid=' + e.currentTarget.dataset.dialogid,
    });
  },
  handleToChat: function (e) {
    wx.navigateTo({
      url: '/view/consult/chat?dialogid=' + e.currentTarget.dataset.dialogid,
    });
  },
  handleLoad: function () {
    http.request({
      url: '/jiyi/dialog/mobile/v1/list',
      data: {
        pageIndex: 1,
        pageSize: 10,
      },
      success: function (data) {
        for (var i = 0; i < data.data.length; i++) {
          data.data[i].systemCreateTime = util.timeToDateStr(data.data[i].systemCreateTime)
        }
        this.setData({
          chatList: data.data
        })
      }.bind(this)
    });
  },
  handleWebSocketMessage: function () {
    wx.onSocketMessage((res) => {
      chat.tipSumOfUnreadMessage();
      var msg = JSON.parse(res.data);
      var chatList = this.data.chatList;
      for (var idx in chatList) {
        if (chatList[idx].dialogId == msg.dialogId) {
          var unreadCount = chatList[idx].unreadCount + 1;
          chatList[idx].unreadCount = unreadCount;
          this.setData({
            chatList: chatList
          });
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    chat.onWebSocketMessageNotInConsult();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    if (storage.getToken() != '') {
      this.handleLoad();
    }
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})