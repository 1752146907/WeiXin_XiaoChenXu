const constant = {
  appId: 'df2078d6c9eb46babb0df957127273ab',
  wechatAppId: 'wxaf3915c78eaa13ee',
  wechatAesKey: '!aes!0123456789!',
  host: 'https://www.wawipet.com',
  // host: 'http://47.100.172.196:8088',
  // host: 'http://192.168.3.130:8080',
  imageHost: 'https://www.wawipet.com',
  platform: 'WAWIPET',
  version: '1.0.0',
  color: '#c81623',
  duration: 2000
}

module.exports = constant;