module.exports = Behavior({
	behaviors: [],
	properties: {},
	data: {
		windowWidth: 0,
		windowHeight: 0
	},
	attached: function () {
	},
	methods: {}
})