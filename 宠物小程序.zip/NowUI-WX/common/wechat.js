const constant = require("./constant.js");
const http = require("./http.js");
const storage = require("./storage.js");
const notification = require("./notification.js");

function auth(config) {
  var token = storage.getToken();
  if (token == '') {
    if (storage.getIsLanuch()) {
      if (config.checkLogin) {
        // wx.openSetting({
        //   success: function (res) {
        //     if (res.authSetting['scope.userInfo']) {
              
        //     }
        //   }
        // });
        
        wx.navigateTo({
          url: '/view/login/wx-login'
        });
        notification.on("login-callback", this, function(data) {
          if (data.success && config.success) {
            config.success();
          } else {
            if (config.fail) {
              config.fail();
            }
          }
        });
      }
    } else {
      storage.setIsLanuch();
      wx.navigateTo({
        url: '/view/login/wx-login'
      });
      notification.on("login-callback", this, function (data) {
        if (data.success && config.success) {
          config.success();
        } else {
          if (config.fail) {
            config.fail();
          }
        }
      });
    }
  } else {
    config.success();
  }
}

function login(userinfo, config) {
  if (userinfo.detail.errMsg == 'getUserInfo:ok') {
    wx.login({
      success: function(res) {
        var code = res.code;
        if (code) {
          http.request({
            url: '/wechat/mini/mobile/v1/auth',
            data: {
              jsCode: code,
              encryptedData: userinfo.detail.encryptedData,
              iv: userinfo.detail.iv
            },
            success: function (data) {
              if (data.openId) {
                var params = {
                  appId: constant.appId,
                  wechatOpenId: data.openId,
                  wechatUnionId: data.unionId ? data.unionId : '',
                  wechatCity: data.city ? data.city : '',
                  wechatCountry: data.country ? data.country : '',
                  wechatProvince: data.province ? data.province : '',
                  wechatLanguage: data.language ? data.language : '',
                  wechatHeadImgUrl: data.avatarUrl ? data.avatarUrl : '',
                  wechatSex: data.gender ? data.gender : '',
                  wechatNickName: data.nickName ? data.nickName : ''
                }
                wechatAuthLogin(config, params);
              }
            }.bind(this),
            fail: function () {
              config.fail();
            }
          });
        }
      }.bind(this)
    });
  } else if (userinfo.detail.errMsg == 'getUserInfo:fail auth deny') { 
    config.fail();
  }
}

function wechatAuthLogin(config, params) {
  http.request({
    url: '/member/mobile/v1/wechat/auth/login',
    data: params,
    success: function (data) {
      if (data.token === undefined || data.token === null || data.token.trim() === '') {
        config.fail();
        return;
      }
      storage.setToken(data.token);
      storage.setOpenId(data.openId);
      var member = {
        memberId: data.memberId,
        memberAvatarPath: data.memberAvatarPath,
        memberNickName: data.memberNickName
      }
      storage.setMember(member);
      config.success();
    }, 
    fail: function () {
      config.fail();
    }
  });
}

module.exports = {
  auth: auth,
  login: login
};