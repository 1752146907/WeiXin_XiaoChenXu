const constant = require("./constant.js");

const opoen_id_key = ('opoen_id_' + constant.version);
const token_key = ('token_' + constant.version);
const member_key = ('member_' + constant.version);

function getIsLanuch() {
  var is_lanuch = wx.getStorageSync('is_lanuch');

  if (is_lanuch == "") {
    return false;
  }

  return is_lanuch;
}

function setIsLanuch() {
  wx.setStorageSync('is_lanuch', true);
}

function getOpenId() {
  return wx.getStorageSync(opoen_id_key);
}

function setOpenId(opoen_id) {
  wx.setStorageSync(opoen_id_key, opoen_id);
}

function getToken() {
  // return 'eyJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE0OTY1MjAxNzAsImV4cCI6NDY1MjE5Mzc3MCwiYXV0aG9yaXphdGlvbl9pZCI6ImE0N2U4ZTMzMGRkYjQ5MGJhMDdkZGUxZGY5NTM4ZTg3IiwidXNlcl9pZCI6IjUxOWI3YWNhYjIzNzRmMTI5ZWY0ZGY1ZDRhYjNlYzI1In0.r-nt2tNL1FXG9t5f6QqnbtWDYYszh1qrxuCclxhggDOBChKuWw4jToEz5zB5Q-G5wevZg1VfU4SO17Xjth44ag';
  // return 'eyJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE0OTU0Mjg4ODEsImV4cCI6MTUyNjk2NDg4MSwiYXV0aG9yaXphdGlvbl9pZCI6IjFhZTczMWFjZDE3MzRkMTFhZTI1M2VjNzJhYWVhY2YwIiwidXNlcl9pZCI6IjQwZDRmYTZlNGE3MzRkMzM4NjIzMzY2ZTQzNDViNzg0In0.KfE3zG-W4DCRSanwlMoMvF_d6jUcpCSIDbedPCa_QBVy3JY026GUFYMFtk_9GHlGqZA9-8k2kfR6RojfK_NTrQ';
  return wx.getStorageSync(token_key);
}

function setToken(token) {
  wx.setStorageSync(token_key, token);
}

function getMember() {
  var member = wx.getStorageSync(member_key);

  if (member == "") {
    return {
      memberId: '',
      memberAvatarPath: '',
      memberNickName: ''
    };
  }

  return JSON.parse(member);
}

function setMember(member) {
  wx.setStorageSync(member_key, JSON.stringify(member));
}

module.exports = {
  getIsLanuch: getIsLanuch,
  setIsLanuch: setIsLanuch,
  getOpenId: getOpenId,
  setOpenId: setOpenId,
  getToken: getToken,
  setToken: setToken,
  getMember: getMember,
  setMember: setMember
};