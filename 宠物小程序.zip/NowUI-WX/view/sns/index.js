const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
    data: {
      windowWidth: getApp().globalData.windowWidth,
      windowHeight: getApp().globalData.windowHeight,
      memberFollowForumPageIndex: 1,
      memberFollowForumPageSize: 3,
      memberFollowForumList: [],
      recommendForumPageIndex: 1,
      recommendForumPageSize: 3,
      recommendForumList: [],
      recommendMemberPageIndex: 1,
      recommendMemberPageSize: 9,
      recommendMemberlist: [],
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 6,
      topicTotal: 0,
      tap: 'forum',
      imageHost: constant.imageHost,
      isLogin: false
    },
    onChangeTap: function (event) {
      var tap = event.currentTarget.dataset.tap;
      if (tap === 'topic') {
        this.getRecommendMemberData();
        this.setData({
          topicList: [],
          topicPageIndex: 1,
          topicTotal: 0
        });
        this.getTopicData();
      }
      this.setData({
        tap: tap
      })
    },
    bindViewTap: function () {

    },
    onTabItemTap: function () {

    },
    onLoad: function (options) {
      if (options.tap) {
        this.setData({
          tap: options.tap
        });
        if (options.tap === 'topic') {
          this.getRecommendMemberData();
          this.setData({
            topicList: [],
            topicPageIndex: 1,
            topicTotal: 0
          });
          this.getTopicData();
        }
      }

      notification.on("member-add-topic", this, function (data) {
        if (this.data.tap === 'topic') {
          this.setData({
            topicList: [],
            topicPageIndex: 1,
            topicTotal: 0
          });
          this.getTopicData();
        }
      });
      notification.on("member-delete-topic", this, function (data) {
        if (this.data.tap === 'topic') {
          this.setData({
            topicList: [],
            topicPageIndex: 1,
            topicTotal: 0
          });
          this.getTopicData();
        }
      });
      wechat.auth({
        checkLogin: false,
        success: function () {
          this.getMemberFollowForumData();
          this.setData({ isLogin: true });
        }.bind(this),
        fail: function () {

        }.bind(this)
      });
      notification.on("member-follow-forum", this, function(data) {
        this.getMemberFollowForumData();
        this.getRecommendForumData();
      });
      notification.on("member-cancel-follow-forum", this, function (data) {
        this.getMemberFollowForumData();
        this.getRecommendForumData();
      });
      notification.on("member-follow-member", this, function (data) {
        this.setData({
          topicList: [],
          topicPageIndex: 1,
          topicTotal: 0
        });
        this.getTopicData();
        this.getRecommendMemberData();
      });
      notification.on("member-cancel-follow-member", this, function (data) {
        this.setData({
          topicList: [],
          topicPageIndex: 1,
          topicTotal: 0
        });
        this.getTopicData();
        this.getRecommendMemberData();
      });
      notification.on("member-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = topicList[i];
            topic.topicLikeCount++;
            topic.memberIsLike = true;
            topicList[i] = topic;
            break;
          }
        }
        this.setData({
          topicList: topicList
        });
      });
      notification.on("member-cancel-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = topicList[i];
            topic.topicLikeCount--;
            topic.memberIsLike = false;
            topicList[i] = topic;
            break;
          }
        }
        this.setData({
          topicList: topicList
        });
      });
      this.getRecommendForumData();
    },
    onReachBottom: function () {
      if (this.data.tap === 'topic') {
        var pageIndex = this.data.topicPageIndex;
        var pageSize = this.data.topicPageSize;
        var total = this.data.topicTotal;
        if (pageIndex * pageSize >= total) {
          return;
        }
        pageIndex++;
        var topicList = this.data.topicList;
        this.setData({
          topicPageIndex: pageIndex
        });

        this.getTopicData();
      }
    },
    //获取我加入的圈子列表
    getMemberFollowForumData: function () {
      http.request({
        url: '/forum/member/follow/mobile/v1/my/follow/list',
        data: {
          advertisementCategoryCode: this.data.advertisementCategoryCode,
          pageIndex: this.data.memberFollowForumPageIndex,
          pageSize: this.data.memberFollowForumPageSize
        },
        success: function (data) {
          this.setData({
            memberFollowForumList: data.list
          })
          console.log(this.data.memberFollowForumList.length)
        }.bind(this)
      });
    },
    //获取你可能感兴趣的圈子列表
    getRecommendForumData: function () {
      http.request({
        url: '/forum/mobile/v1/interest/list',
        data: {
          pageIndex: this.data.memberFollowForumPageIndex,
          pageSize: this.data.memberFollowForumPageSize
        },
        success: function (data) {
          this.setData({
            recommendForumList: data.list
          })
        }.bind(this)
      });
    },
    //获取推荐的宠物用户列表
    getRecommendMemberData: function () {
      http.request({
        url: '/sns/member/mobile/v1/recommend/list',
        data: {
          pageIndex: this.data.recommendMemberPageIndex,
          pageSize: this.data.recommendMemberPageSize
        },
        success: function (data) {
          console.log('推荐');
          console.log(data);
          this.setData({
            recommendMemberList: data.list
          })
        }.bind(this)
      });
    },
    //获取用户动态列表
    getTopicData: function () {
      http.request({
        url: '/topic/mobile/v1/list',
        data: {
          pageIndex: this.data.topicPageIndex,
          pageSize: this.data.topicPageSize
        },
        success: function (data) {
          var topicList = this.data.topicList;
          if (data.list.length > 0) {
            for (var i = 0; i < data.list.length; i++) {
              var topic = data.list[i];
              topic.systemCreateTime = util.timeToDateStr(topic.systemCreateTime);
              topicList.push(topic);
            }
          }
          this.setData({
            topicList: topicList,
            topicTotal: data.total
          })
        }.bind(this)
      });
    },
    //加入圈子
    handleFollowForum: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/forum/member/follow/mobile/v1/save',
            data: {
              forumId: event.currentTarget.dataset.forumId
            },
            success: function (data) {
              this.getMemberFollowForumData();
              this.getRecommendForumData();
              wx.showToast({
                title: '加入成功',
                icon: 'success',
                duration: 2000
              });
            }.bind(this),
            error: function (data) {
              this.setData({
                isLogin: true
              });
              notification.emit("member-follow-forum", {});
            }.bind(this)
          });
        }.bind(this),
        fail: function () {

        }
      });
      
    },
    //关注会员
    handleFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/sns/member/follow/mobile/v1/save',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-follow-member", { memberId: event.currentTarget.dataset.memberId});
                wx.showToast({
                  title: '关注成功',
                  icon: 'none',
                  duration: 1500
                })
              } 
            }.bind(this)
          });
        }.bind(this) 
      })
    },
    handleCancelFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/sns/member/follow/mobile/v1/delete',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-cancel-follow-member", { memberId: event.currentTarget.dataset.memberId});
                wx.showToast({
                  title: '取消关注成功',
                  icon: 'none',
                  duration: 1500
                })
              } 
            }.bind(this)
          });
        }.bind(this)
      })
    },
    handleLikeTopic: function (e) {
      var topicId = e.currentTarget.dataset.topicId;
      if (!topicId || topicId === '') {
        return;
      }
      http.request({
        isToast: true,
        url: '/topic/member/like/mobile/v1/save',
        data: {
          topicId: topicId
        },
        success: function (data) {
          if (data) {
            notification.emit("member-like-topic", {topicId: topicId});        
          } 
        }.bind(this)
      });
    },
    handleCancelLikeTopic: function (e) {
      var topicId = e.currentTarget.dataset.topicId;
      if (!topicId || topicId === '') {
        return;
      }
      http.request({
        isToast: true,
        url: '/topic/member/like/mobile/v1/delete',
        data: {
          topicId: topicId
        },
        success: function (data) {
          if (data) {
            notification.emit("member-cancel-like-topic", { topicId: topicId }); 
          }
        }.bind(this)
      });
    },
    //更多圈子
    handleAddJoin: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/forum/list'
          })
        }.bind(this)
      })
    },
    //创建圈子
    handleAddTopic: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/forum/add'
          })
        }.bind(this)
      })
    },
    //关注更多宠物用户
    handleMoreUsers: function () {
      wechat.auth({
        checkLogin: true,
        success: function () {
          wx.navigateTo({
            url: '/view/member/list'
          })
        }.bind(this)
      })
    },
    toKnowledge: function (e) {
      wx.navigateTo({
        url: '/view/knowledge/detail?topicId=' + e.currentTarget.dataset.topicId,
      })
    },
    touchMove: function (e) { 
      console.log("111111")
    },
    //刷新
    onPullDownRefresh: function () {
      if (this.data.tap === 'topic') {
        this.getRecommendMemberData();
        this.setData({
          topicList: [],
          topicPageIndex: 1,
          topicTotal: 0
        });
        this.getTopicData();
      }
      wx.stopPullDownRefresh();
    },
})
