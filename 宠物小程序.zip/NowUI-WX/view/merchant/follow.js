const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
Page({
	data: {
    memberFollowList: [],
    pageIndex: 1,
    pageSize: 18,
    total: 0,
    merchantId: '',
    imageHost: constant.imageHost
	},
	onLoad: function (options) {

    if (options.merchantId) {
      this.setData({
        merchantId: options.merchantId
      });
      this.getMemberFollowData();
    }
    
	},
  loadMore: function () {
    var pageIndex = this.data.pageIndex;
    var pageSize = this.data.pageSize;
    var total = this.data.total;
    if ((pageIndex * pageSize) >= total) {
      return;
    }
    pageIndex++;
    this.setData({
      pageIndex: pageIndex
    });
    this.getMemberFollowData();
  },
	getMemberFollowData: function () {
    http.request({
      url: '/merchant/member/like/mobile/v1/follow/member/list',
      data: {
        merchantId: this.data.merchantId,
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize
      },
      success: function (data) {
        console.log(data);
        this.setData({
          memberFollowList: data.list,
          total: data.total
        })
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
