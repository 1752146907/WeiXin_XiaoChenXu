const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
	data: {
		windowWidth: getApp().globalData.windowWidth,
		windowHeight: getApp().globalData.windowHeight,
		merchantId: '',
    merchant: {},
    memberFollowList: [],
    memberFollowTotal: 0,
    topicTotal: 0,
    topicList: [],
    topicPageIndex: 1,
    topicPageSize: 4,
    imageHost: constant.imageHost
	},
	onLoad: function (options) {
    if (options.merchantId) {
      this.setData({
        merchantId: options.merchantId
      });
      this.getMerchantData();
      this.getMerchantLikeFollowMemberData();
      this.getTopicData();

      notification.on("member-follow-member", this, function (data) {
        var topicList = this.data.topicList;
        for (var i = 0; i < topicList.length; i++) {
          var topic = topicList[i];
          if (topic.memberId === data.memberId) {
            topic.memberIsFollow = true;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        });
      });
      notification.on("member-add-topic", this, function (data) {
        if (data.shareMerchantId && data.shareMerchantId === this.data.merchantId) {
          this.setData({
            topicTotal: 0,
            topicList: [],
            topicPageIndex: 1,
            topicPageSize: 4
          });
          this.getTopicData();
        }
      });
      notification.on("member-cancel-follow-member", this, function (data) {
        var topicList = this.data.topicList;
        for (var i = 0; i < topicList.length; i++) {
          var topic = topicList[i];
          if (topic.memberId === data.memberId) {
            topic.memberIsFollow = false;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        });
      });
      notification.on("member-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        if (this.data.topicList.length > 0) {
          for (var i = 0; i < this.data.topicList.length; i++) {
            if (data.topicId === this.data.topicList[i].topicId) {
              var topic = this.data.topicList[i];
              topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
              topic.memberIsLike = true;
              topicList[i] = topic;
            }
          }
          this.setData({
            topicList: topicList
          })
        }
      });
      notification.on("member-cancel-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        if (this.data.topicList.length > 0) {
          for (var i = 0; i < this.data.topicList.length; i++) {
            if (data.topicId === this.data.topicList[i].topicId) {
              var topic = this.data.topicList[i];
              topic.topicLikeCount = topic.topicLikeCount > 1 ? topic.topicLikeCount - 1 : 0;
              topic.memberIsLike = false;
              topicList[i] = topic;
            }
          }
          this.setData({
            topicList: topicList
          })
        }
      });
    }
	},
  handleFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-follow-member", { memberId: event.currentTarget.dataset.memberId });
            } 
          }.bind(this)
        });
      }.bind(this)
    })
  },
  handleCancelFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/delete',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-follow-member", { memberId: event.currentTarget.dataset.memberId });
            }
          }.bind(this)
        });
      }.bind(this)
    })
  },
  handleLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/save',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handlePhoneCall: function() {
    wx.makePhoneCall({
      phoneNumber: this.data.merchant.merchantPhone, 
      success: function () {
        
      },
    })  
  },
  handleCancelLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/delete',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  onReachBottom: function () {
    var pageIndex = this.data.topicPageIndex;
    var pageSize = this.data.topicPageSize;
    var total = this.data.topicTotal;

    if (pageIndex * pageSize >= total) {
      return false;
    }
    pageIndex++;
    this.setData({
      topicPageIndex: pageIndex,
    });
    this.getTopicData();
  },  
  handleCancelBookmarkMerchant: function (e) {
    http.request({
      isToast: true,
      url: '/merchant/member/bookmark/mobile/v1/delete',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        if (data) {
          var merchant = this.data.merchant;
          merchant.merchantMemberBookmarkCount = merchant.merchantMemberBookmarkCount - 1;
          merchant.memberIsBookmark = false;
          this.setData({
            merchant: merchant
          });
        }
      }.bind(this)
    });
  },
  handleMerchantCancelMemberLikeCount: function () {
    http.request({
      isToast: true,
      url: '/merchant/member/like/mobile/v1/delete',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        if (data) {
          var merchant = this.data.merchant;
          merchant.merchantMemberLikeCount = merchant.merchantMemberLikeCount - 1;
          merchant.memberIsLike = false;
          this.setData({
            merchant: merchant
          });
        }
      }.bind(this)
    });
  },
  getMerchantData: function () {
    http.request({
      url: '/merchant/mobile/v1/find',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        this.setData({
          merchant: data,
          isCollection: data.memberIsBookmark,
          isLike: data.memberIsLike,
        })
        console.log(this.data.isCollection)
        console.log(this.data.isLike)
      }.bind(this)
    });
  },
  getMerchantLikeFollowMemberData: function () {
    http.request({
      url: '/merchant/member/like/mobile/v1/follow/member/list',
      data: {
        merchantId: this.data.merchantId,
        pageIndex: 1,
        pageSize: 8
      },
      success: function (data) {
        this.setData({
          memberFollowList: data.list,
          memberFollowTotal: data.total
        })
      }.bind(this)
    });
  },
  getTopicData: function () {
    http.request({
      url: '/topic/merchant/share/mobile/v1/topic/list/by/merchant/id',
      data: {
        shareMerchantId: this.data.merchantId,
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
      },
      success: function (data) {
        var topicList = this.data.topicList;

        if (data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topic = data.list[i];
            topic.systemCreateTime = util.timeToDateStr(topic.systemCreateTime);
            topicList.push(topic);
          }
        }
        
        this.setData({
          topicList: topicList,
          topicTotal : data.total
        })
      }.bind(this)
    });
  },
  handleLikeMerchant: function () {
    http.request({
      isToast: true,
      url: '/merchant/member/like/mobile/v1/save',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        if (data) {
          var merchant = this.data.merchant;
          merchant.merchantMemberLikeCount = merchant.merchantMemberLikeCount + 1;
          merchant.memberIsLike = true;
          this.setData({
            merchant: merchant,
          });
        }
      }.bind(this)
    });
  },
  handleBookmarkMerchant: function () {
    http.request({
      isToast: true,
      url: '/merchant/member/bookmark/mobile/v1/save',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        if (data) {
          var merchant = this.data.merchant;
          merchant.merchantMemberBookmarkCount = merchant.merchantMemberBookmarkCount + 1;
          merchant.memberIsBookmark = true;
          this.setData({
            merchant: merchant
          });
        }
      }.bind(this)
    });
  },
  handleToHomePage: function (e) {
    var memberId = e.currentTarget.dataset.memberId;
    var memberIsSelf = e.currentTarget.dataset.memberIsSelf;
    wx.navigateTo({
      url: memberIsSelf ? '/view/member/homePage' : '/view/member/otherHomePage?memberId=' + memberId
    })
  },
  handleToTopicDetail: function (e) {
    var topicId = e.currentTarget.dataset.topicId;

    wx.navigateTo({
      url: '/view/topic/detail?topicId=' + topicId,
    });
  },
  handleToMerchantFollow: function () {
    wx.navigateTo({
      url: '/view/merchant/follow?merchantId=' + this.data.merchantId
    });
  },
  handleToAddTopic: function () {
    wx.navigateTo({
      url: '/view/topic/add?merchantId=' + this.data.merchantId + '&merchantName=' + this.data.merchant.merchantName + '&merchantAvatarPath=' + this.data.merchant.merchantAvatarPath
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
