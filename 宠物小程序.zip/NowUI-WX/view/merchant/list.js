const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
Page({
    data: {
      windowWidth: getApp().globalData.windowWidth,
      windowHeight: getApp().globalData.windowHeight,
      tagFrontendCategoryList: [],
      activeIndex: 0,
      toView: "category0",
      tagFrontendCategoryId: '',
      merchantLongitude: '',
      merchantLatitude: '',
      merchantList: [],
      pageIndex: 1,
      pageSize: 5,
      merchantTotal: 0,
      sort: "nearest",
      imageHost: constant.imageHost
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      wx.getLocation({
        type: 'wgs84',
        success: function (res) {
          this.setData({
            merchantLongitude: res.longitude,
            merchantLatitude: res.latitude
          });
        }.bind(this),
        complete: function (res) {
          this.getMerchantData();
        }.bind(this)
      })
      if (options.tagFrontendCategoryId) {
        this.setData({
          tagFrontendCategoryId: options.tagFrontendCategoryId
        });
      }
      this.getMerchantTagFrontendCategoryData();
    },
    getMerchantTagFrontendCategoryData: function () {
      http.request({
        url: '/tag/frontend/category/mobile/v1/list',
        data: {
          tagFrontendCategoryCategoryCode: "INDEX_MERCHANT"
        },
        success: function (data) {
          var activeIndex = this.data.activeIndex;
          var toView = this.data.toView;
          if (this.data.tagFrontendCategoryId && data.length > 0) {
            for (var i = 0; i < data.length; i++) {
              if (this.data.tagFrontendCategoryId === data[i].tagFrontendCategoryId) {
                activeIndex = i + 1;
                toView = "category" + activeIndex;
              }
            }
          } else {
            toView = "category0";
          }
          this.setData({
            activeIndex: activeIndex,
            toView: toView,
            tagFrontendCategoryList: data
          })
        }.bind(this)
      });
    },
    changeSort: function (e) {
      var sort = this.data.sort;
      if (sort === "nearest") {
        sort = "hot";
      } else {
        sort = "nearest";
      }
      this.setData({
        sort: sort,
        merchantList: [],
        pageIndex: 1,
        pageSize: 5,
        merchantTotal: 0,
      });
      this.getMerchantData();
    },
    getMerchantData: function () {
      if (this.data.sort === "nearest") {
        this.getNearestMerchantData();
      } else {
        this.getHotMerchantData();
      }
    },
    getNearestMerchantData: function () {
      http.request({
        url: '/merchant/moblie/v1/nearest/list',
        data: {
          tagFrontendCategoryId: this.data.tagFrontendCategoryId,
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize,
          merchantName: "",
          merchantLongitude: this.data.merchantLongitude,
          merchantLatitude: this.data.merchantLatitude
        },
        success: function (data) {
          var merchantList = this.data.merchantList;
          if (data.list.length > 0) {
            if (this.data.pageIndex === 1) {
              merchantList = data.list;
            } else {
              merchantList = merchantList.concat(data.list);
            }
          }
          this.setData({
            merchantList: merchantList,
            merchantTotal: data.total
          })
        }.bind(this)
      });
    },
    getHotMerchantData: function () {
      http.request({
        url: '/merchant/moblie/v1/hot/list',
        data: {
          tagFrontendCategoryId: this.data.tagFrontendCategoryId,
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize,
          merchantName: "",
          merchantLongitude: this.data.merchantLongitude,
          merchantLatitude: this.data.merchantLatitude
        },
        success: function (data) {
          var merchantList = this.data.merchantList;
          if (data.list.length > 0) {
            if (this.data.pageIndex === 1) {
              merchantList = data.list;
            } else {
              merchantList = merchantList.concat(data.list);
            }
          }
          
          this.setData({
            merchantList: merchantList,
            merchantTotal: data.total
          })
        }.bind(this)
      });
    },
    selectCategory: function (e) {
      var index = e.currentTarget.dataset.index;
      var tagFrontendCategoryId = e.currentTarget.dataset.tagFrontendCategoryId;
      if (tagFrontendCategoryId === this.data.tagFrontendCategoryId) {
        return;
      }
      this.setData({
        activeIndex: index,
        pageIndex: 1,
        tagFrontendCategoryId: tagFrontendCategoryId
      })
      this.getMerchantData();
    },
    onReachBottom: function () {
      var pageIndex = this.data.pageIndex;
      var pageSize = this.data.pageSize;
      var total = this.data.merchantTotal;
      if ((pageIndex * pageSize) >= total) {
        return;
      }
      this.setData({
        pageIndex: pageIndex + 1
      });
      this.getMerchantData();
    },
    openLocation: function (e) {
      var index = e.currentTarget.dataset.index;
      var merchant = this.data.merchantList[index];

      if (merchant.merchantLongitude && merchant.merchantLatitude) {
        wx.openLocation({
          latitude: parseFloat(merchant.merchantLatitude),
          longitude: parseFloat(merchant.merchantLongitude),
        })
      }
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
