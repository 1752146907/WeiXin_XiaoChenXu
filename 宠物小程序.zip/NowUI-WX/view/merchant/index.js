const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js"); 
Page({
	data: {
		windowWidth: getApp().globalData.windowWidth,
		windowHeight: getApp().globalData.windowHeight,
		bannerList: [],
    advertisementCategoryCode: 'INDEX_MERCHANT',
    tagFrontendCategoryList: [],
    tagFrontendCategoryCategoryCode: "INDEX_MERCHANT",
    recommendMerchantPageIndex: 1,
    recommendMerchantPageSize: 5,
    recommendMerchantList: [],
    recommnedMerchantTotal: 0,
    topicPageIndex: 1,
    topicPageSize: 2,
    topicList: [],
    topicTotal: 0,
    imageHost: constant.imageHost,
    height: ''
	},
	onLoad: function () {
    this.getMerchantBannerData();
    this.getMerchantTagFrontendCategoryData();
    this.getRecommendMerchantData(this.data.recommendMerchantPageIndex);
    this.getMerchantTopicData();
    notification.on("member-follow-member", this, function (data) {
      var topicList = this.data.topicList;
      for (var i = 0; i < topicList.length; i++) {
        var topic = topicList[i];
        if (topic.memberId === data.memberId) {
          topic.memberIsFollow = true;
          topicList[i] = topic;
        }
      }
      this.setData({
        topicList: topicList
      });
    });
    notification.on("member-cancel-follow-member", this, function (data) {
      var topicList = this.data.topicList;
      for (var i = 0; i < topicList.length; i++) {
        var topic = topicList[i];
        if (topic.memberId === data.memberId) {
          topic.memberIsFollow = false;
          topicList[i] = topic;
        }
      }
      this.setData({
        topicList: topicList
      });
    });
    notification.on("member-like-topic", this, function (data) {
      var topicList = this.data.topicList;
      if (this.data.topicList.length > 0) {
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = this.data.topicList[i];
            topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
            topic.memberIsLike = true;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        })
      }
    });
    notification.on("member-cancel-like-topic", this, function (data) {
      var topicList = this.data.topicList;
      if (this.data.topicList.length > 0) {
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = this.data.topicList[i];
            topic.topicLikeCount = topic.topicLikeCount > 1 ? topic.topicLikeCount - 1 : 0;
            topic.memberIsLike = false;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        })
      }
    });
	},
	onReady: function () {

	},
  //获取商户广告数据
  getMerchantBannerData: function () {
    http.request({
      url: '/advertisement/mobile/v1/list/by/category/code',
      data: {
        advertisementCategoryCode: this.data.advertisementCategoryCode
      },
      success: function (data) {
        this.setData({
          bannerList: data
        })
      }.bind(this)
    });
  },
  // 获取商户标签分类列表
  getMerchantTagFrontendCategoryData: function () {
    http.request({
      url: '/tag/frontend/category/mobile/v1/list',
      data: {
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode
      },
      success: function (data) {
        this.setData({
          tagFrontendCategoryList: data
        })
      }.bind(this)
    });
  },
  // 获取推荐的商户列表
  getRecommendMerchantData: function (pageIndex) {
    http.request({
      url: '/merchant/moblie/v1/recommend/list',
      data: {
        pageIndex: pageIndex,
        pageSize: this.data.recommendMerchantPageSize
      },
      success: function (data) {
        var recommendMerchantList = this.data.recommendMerchantList;
        
        recommendMerchantList = recommendMerchantList.concat(data.list);
        this.setData({
          recommendMerchantPageIndex: pageIndex,
          recommendMerchantList: recommendMerchantList,
          recommendMerchantTotal: data.total
        })
      }.bind(this)
    });
  },
  // 加载推荐的商户
  loadRecommendMerchantData: function () {
    var pageIndex = this.data.recommendMerchantPageIndex;
    var pageSize = this.data.recommendMerchantPageSize;
    var total = this.data.recommendMerchantTotal;
    if ((pageIndex * pageSize) >= total) {
      return;
    }
    pageIndex++;
    this.getRecommendMerchantData(pageIndex);

  },
  onReachBottom: function () {
    var pageIndex = this.data.topicPageIndex;
    var pageSize = this.data.topicPageSize;
    var total = this.data.topicTotal;
    if (pageIndex * pageSize >= total) {
      return;
    }
    pageIndex++;
    var topicList = this.data.topicList;
    this.setData({
      topicPageIndex: pageIndex
    });

    this.getMerchantTopicData();

  },
  // 获取分享商户动态列表
  getMerchantTopicData: function () {
    http.request({
      url: '/topic/merchant/share/mobile/v1/topic/list',
      data: {
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
      },
      success: function (data) {
        var topicList = this.data.topicList;
        if (data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topic = data.list[i];
            topic.systemCreateTime = util.timeToDateStr(topic.systemCreateTime);
            topicList.push(topic);
          }
        }
        this.setData({
          topicList: topicList,
          topicTotal: data.total
        })
      }.bind(this)
    });
  },
  //关注会员
  handleFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-follow-member", { memberId: event.currentTarget.dataset.memberId });
            }
          }.bind(this)
        });
      }.bind(this)
    })
  },
  handleCancelFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/delete',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-follow-member", { memberId: event.currentTarget.dataset.memberId });
            }
          }.bind(this)
        });
      }.bind(this)
    })
  },
  handleLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/save',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleCancelLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/delete',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
