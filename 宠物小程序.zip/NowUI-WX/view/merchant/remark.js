const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
// const htmlToWxml = require("../../common/htmlToWxml.js");
const WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    merchantId: '',
  },
  onLoad: function (options) {
    if (options.merchantId) {
      this.setData({
        merchantId: options.merchantId
      });
      this.getRemarkData();
    }
  },
  getRemarkData() {
    http.request({
      url: '/merchant/mobile/v1/find/remark',
      data: {
        merchantId: this.data.merchantId
      },
      success: function (data) {
        WxParse.wxParse('merchantRemark', 'html', data.merchantRemark, this, 5);
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})