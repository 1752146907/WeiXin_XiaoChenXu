const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    inputShowed: false,
    tagName: "",
    tagFrontendCategoryCategoryCode: "",
    hotPageIndex: 1,
    hotPageSize: 20,
    hotList: [],
    historyPageIndex: 1,
    historyPageSize: 10,
    historyList: [],
    tagList: [],
    pageIndex: 1,
    pageSize: 8,
    tagTotal: 0,
    isMatch: true
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      tagName: "",
      tagList: [],
      pageIndex: 1,
      pageSize: 8,
      tagTotal: 0,
      isPerfetMatch: false,
      inputShowed: false
    });
  },
  clearInput: function () {
    this.setData({
      tagName: "",
      tagList: [],
      pageIndex: 1,
      pageSize: 8,
      tagTotal: 0,
      isPerfetMatch: false
    });
  },
  inputTagName: function (e) {
    var tagName = e.detail.value;
    
    this.setData({
      tagName: tagName
    });
    if (tagName.trim() !== '') {
      this.handleSearchTag();
    }
  },
  onLoad: function (options) {
    if (options.tagFrontendCategoryCategoryCode) {
      this.setData({
        tagFrontendCategoryCategoryCode: options.tagFrontendCategoryCategoryCode
      });
    }
    wechat.auth({
      success: function (data) {
        this.getHistoryData();
      }.bind(this),
      fail: function () {

      }
    });
    this.getHotData();
  },
  //获取历史标签列表
  getHistoryData: function() {
    http.request({
      url: '/tag/history/mobile/v1/list',
      data: {
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode,
        pageIndex: this.data.historyPageIndex,
        pageSize: this.data.historyPageSize
      },
      success: function (data) {
        this.setData({
          historyList: data.list
        })
      }.bind(this)
    });
  },
  //获取热门标签列表
  getHotData: function() {
    http.request({
      url: '/tag/frontend/category/tag/map/mobile/v1/hot/list',
      data: {
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode,
        pageIndex: this.data.hotPageIndex,
        pageSize: this.data.hotPageSize
      },
      success: function (data) {
        this.setData({
          hotList: data.list
        })
      }.bind(this)
    });
  },
  //清除历史标签
  clearHistory: function() {
    http.request({
      isToast: true,
      url: '/tag/history/mobile/v1/clear',
      data: {
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode
      },
      success: function (data) {
        this.getHistoryData();
      }.bind(this)
    });
  },
  // 搜索标签
  handleSearchTag() {
    var tagName = this.data.tagName;
    if (tagName.trim() === '') {
      return;
    }
    http.request({
      url: '/tag/frontend/category/tag/map/mobile/v1/list',
      data: {
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode,
        tagName: tagName,
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize
      },
      success: function (data) {
        var tagList = data.list;
        var isMatch = true;
        if (tagList.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            if (tagName === data.list[i].tagName) {
              isMatch = false;
              var temp = tagList[0];
              tagList[0] = data.list[i];
              tagList[i] = temp;
            }
          }
        }
        this.setData({
          isMatch: isMatch,
          tagList: tagList,
          tagTotal: data.total
        })
      }.bind(this)
    });
  },
  // 创建标签
  handleCreateTag: function() {
    var tagName = this.data.tagName;
    console.log(tagName);
    if (tagName.trim() === '') {
      return;
    }
    http.request({
      isToast: true,
      url: '/tag/mobile/v1/save',
      data: {
        tagName: tagName,
        tagFrontendCategoryCategoryCode: this.data.tagFrontendCategoryCategoryCode
      },
      success: function (data) {
        this.handleSearchTag();
      }.bind(this)
    });

  }, 
  //选中标签
  selectedTag: function(event) {
    var tagId = event.currentTarget.dataset.tagId;
    var tagName = event.currentTarget.dataset.tagName;
    if (this.data.tagFrontendCategoryCategoryCode) {
      notification.emit(this.data.tagFrontendCategoryCategoryCode, {
        tagId: tagId,
        tagName: tagName
      });
      wx.navigateBack();
    }
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
});