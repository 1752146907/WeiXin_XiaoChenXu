Page({
    data: {
      atlas: true,
      dynamic: false
    },
    tapAtlas: function(e) {
      this.setData({ 
        atlas: true,
        dynamic: false
      })
    },
    tapDynamic: function (e) {
      this.setData({
        atlas: false,
        dynamic: true
      })
    },
    bindViewTap: function () {

    },
    onLoad: function () {

    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
