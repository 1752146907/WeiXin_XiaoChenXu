const notification = require("../../common/notification.js");
Page({
    data: {
      topicIsPrivate: false
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      this.setData({
        topicIsPrivate: !(options.topicIsPrivate === 'false')
      });
    },
    handleSelect: function (e) {
      notification.emit("topic-add-select-pulic", {
        topicIsPrivate: e.detail.value
      });
      wx.navigateBack();
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
