Page({
    data: {
      items: [
        { name: 'USA', value: '广告内容' },
        { name: 'CHN', value: '不友善内容', checked: 'true' },
        { name: 'BRA', value: '垃圾内容' },
        { name: 'JPN', value: '违法内容' },
        { name: 'ENG', value: '其它' },
      ],
      files: []
    },
    radioChange: function (e) {
      console.log('radio发生change事件，携带value值为：', e.detail.value)
    }, 
    chooseImage: function (e) {
      var that = this;
      wx.chooseImage({
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (res) {
          // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
          that.setData({
            files: that.data.files.concat(res.tempFilePaths)
          });
        }
      })
    },
    previewImage: function (e) {
      wx.previewImage({
        current: e.currentTarget.id, // 当前显示图片的http链接
        urls: this.data.files // 需要预览的图片http链接列表
      })
    },
    bindViewTap: function () {

    },
    onLoad: function () {

    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
