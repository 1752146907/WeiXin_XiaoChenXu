const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    inputShowed: false,
    merchantName: "",
    searchNone: false,
    mask: false,
    merchantList: [],
    merchantPageIndex: 1,
    merchantPageSize: 10,
    merchantTotal: 0,
    merchantLongitude: "",
    merchantLatitude: "",
    imageHost: constant.imageHost
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      merchantName: "",
      merchantPageIndex: 1,
      merchantList: [],
      searchNone: false,
      inputShowed: false
    });
    this.getMerchantData();
  },
  clearInput: function () {
    this.setData({
      merchantName: "",
      merchantPageIndex: 1,
      merchantList: [],
      searchNone: false
    });
    this.getMerchantData();
  },
  inputMerchantName: function (e) {
    var merchantName = e.detail.value;
    this.setData({
      merchantName: merchantName,
      merchantPageIndex: 1,
      merchantList: [],
      searchNone: false
    });

    this.getMerchantData();
  },
  onLoad: function () {
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        this.setData({
          merchantLongitude: res.longitude,
          merchantLatitude: res.latitude
        });
      }.bind(this),
      complete: function (res) {
        this.getMerchantData();
      }.bind(this)
    })
  },
  onReachBottom: function () {
    var pageIndex = this.data.merchantPageIndex;
    var pageSize = this.data.merchantPageSize;
    var total = this.data.merchantTotal;
    if ((pageIndex * pageSize) >= total) {
      return;
    }
    this.setData({
      merchantPageIndex: pageIndex + 1
    });
    this.getMerchantData();
  },
  getMerchantData: function () {
    http.request({
      url: '/merchant/moblie/v1/nearest/list',
      data: {
        tagFrontendCategoryId: "",
        merchantName: this.data.merchantName,
        pageIndex: this.data.merchantPageIndex,
        pageSize: this.data.merchantPageSize,
        merchantLongitude: this.data.merchantLongitude,
        merchantLatitude: this.data.merchantLatitude
      },
      success: function (data) {
        var merchantList = this.data.merchantList;
        if (data.list.length > 0) {
          merchantList = merchantList.concat(data.list);
        }
        this.setData({
          merchantList: merchantList,
          merchantTotal: data.total,
          searchNone: data.length <= 0
        })
      }.bind(this)
    });
  },
  openLocation: function (e) {
    var longitude = e.currentTarget.dataset.longitude;
    var latitude = e.currentTarget.dataset.latitude;

    if (longitude && latitude) {
      wx.openLocation({
        longitude: parseFloat(longitude),
        latitude: parseFloat(latitude)
      })
    }
  },
  selectedMerchant: function (e) {
    var merchantId = e.currentTarget.dataset.merchantId;
    var merchantName = e.currentTarget.dataset.merchantName;
    var merchantAvatarPath = e.currentTarget.dataset.merchantAvatarPath;
    notification.emit("topic-add-select-merchant", {
      merchantId: merchantId,
      merchantName: merchantName,
      merchantAvatarPath: merchantAvatarPath
    });
    wx.navigateBack();
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
});