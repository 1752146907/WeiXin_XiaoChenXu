const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
Page({
    data: {
      windowWidth: getApp().globalData.windowWidth,
      windowHeight: getApp().globalData.windowHeight,
      inputShowed: true,
      topicMemberCommentContent: "",
      replyCommentId: "",
      replyMemberNickName: "",
      replyMemberId: "",
      topicId: '',
      commentList: [],
      commentPageIndex: 1,
      commentPageSize: 10,
      commentTotal: 0,
      placeholder: '喜欢吗？来聊一句吧！',
      imageHost: constant.imageHost,
      member: storage.getMember()
    },
    showInput: function () {
      this.setData({
        inputShowed: true
      });
    },
    hideInput: function () {
      this.setData({
        topicMemberCommentContent: "",
        inputShowed: false
      });
    },
    clearInput: function () {
      this.setData({
        topicMemberCommentContent: ""
      });
    },
    inputTyping: function (e) {
      this.setData({
        topicMemberCommentContent: e.detail.value
      });
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      if (options.topicId) {
        this.setData({
          topicId: options.topicId
        })
        this.getCommentData();
        notification.on("member-comment-topic", this, function (data) {
          if (data.topicId === this.data.topicId) {
            this.setData({
              inputShowed: false,
              topicMemberCommentContent: "",
              replyCommentId: "",
              replyMemberId: "",
              commentList: [],
              commentPageIndex: 1,
              commentPageSize: 10,
              commentTotal: 0,
              placeholder: "喜欢吗？来聊一句吧！"
            });
            this.getCommentData();
          }
        });
      }
    },
    onReachBottom: function () {
      var pageIndex = this.data.commentPageIndex;
      var pageSize = this.data.commentPageSize;
      var total = this.data.commentTotal;
      if (pageIndex * pageSize >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        commentPageIndex: pageIndex
      })
      this.getCommentData();
    },
    onPageScroll: function () {
      this.cancelReply()
    },
    getCommentData: function() {
      http.request({
        url: '/topic/member/comment/mobile/v1/list',
        data: {
          topicId: this.data.topicId,
          pageIndex: this.data.commentPageIndex,
          pageSize: this.data.commentPageSize
        },
        success: function (data) {
          var commentList = this.data.commentList;

          if (data.list.length > 0) {
            for (var i = 0; i < data.list.length; i++) {
              var comment = data.list[i];
              comment.systemCreateTime = util.timeToDateStr(comment.systemCreateTime);
              
              if (comment.topicMemberCommentReplyCommentList.length > 0) {
                var replyCommentList = comment.topicMemberCommentReplyCommentList;
                for (var j = 0; j < replyCommentList.length; j++) {
                  var replyComment = replyCommentList[j];
                  replyComment.systemCreateTime = util.timeToDateStr(replyComment.systemCreateTime);
                  replyCommentList[j] = replyComment;
                }
                comment.topicMemberCommentReplyCommentList = replyCommentList;
              }
              commentList.push(comment);
            }
          }
          console.log(commentList);
          this.setData({
            commentList: commentList,
            commentTotal: data.total
          })
        }.bind(this)
      });
    },
    handleCommentLike: function (e) {
      var commentIndex = e.currentTarget.dataset.commentIndex;
      var replyCommentIndex = e.currentTarget.dataset.replyCommentIndex;
      var commentId = e.currentTarget.dataset.commentId;
      http.request({
        isToast: true,
        url: '/topic/member/comment/like/mobile/v1/save',
        data: {
          commentId: commentId
        },
        success: function (data) {
          var commentList = this.data.commentList;
          var comment = commentList[commentIndex];
          if (replyCommentIndex >= 0) {
            var replyComment = comment.topicMemberCommentReplyCommentList[replyCommentIndex];
            replyComment.topicMemberCommentLikeCount = replyComment.topicMemberCommentLikeCount != null ? replyComment.topicMemberCommentLikeCount + 1 : 1;
            replyComment.memberIsLike = true;
            comment.topicMemberCommentReplyCommentList[replyCommentIndex] = replyComment;
          } else {
            comment.topicMemberCommentLikeCount = comment.topicMemberCommentLikeCount != null ? comment.topicMemberCommentLikeCount + 1 : 1;
            comment.memberIsLike = true;
          }
          commentList[commentIndex] = comment;
          this.setData({
            commentList: commentList
          });
        }.bind(this)
      });
    },
    handleCancelCommentLike: function (e) {
      var commentIndex = e.currentTarget.dataset.commentIndex;
      var replyCommentIndex = e.currentTarget.dataset.replyCommentIndex;
      var commentId = e.currentTarget.dataset.commentId;
      http.request({
        isToast: true,
        url: '/topic/member/comment/like/mobile/v1/delete',
        data: {
          commentId: commentId
        },
        success: function (data) {
          var commentList = this.data.commentList;
          var comment = commentList[commentIndex];
          if (replyCommentIndex >= 0) {
            var replyComment = comment.topicMemberCommentReplyCommentList[replyCommentIndex];
            replyComment.topicMemberCommentLikeCount = replyComment.topicMemberCommentLikeCount - 1;
            replyComment.memberIsLike = false;
            comment.topicMemberCommentReplyCommentList[replyCommentIndex] = replyComment;
          } else {
            comment.topicMemberCommentLikeCount = comment.topicMemberCommentLikeCount - 1;
            comment.memberIsLike = false;
          }
          commentList[commentIndex] = comment;
          this.setData({
            commentList: commentList
          });
        }.bind(this)
      });
    },
    expandReplyComment: function (e) {
      var commentIndex = e.currentTarget.dataset.commentIndex;
      var commentList = this.data.commentList;
      var comment = commentList[commentIndex];
      comment.isExpand = comment.isExpand ? false : true;
      commentList[commentIndex] = comment;
      this.setData({
        commentList: commentList
      })
    },
    handleReply: function (e) {
      var replyCommentId = e.currentTarget.dataset.replyCommentId;
      var replyMemberId = e.currentTarget.dataset.replyMemberId;
      var replyMemberNickName = e.currentTarget.dataset.replyMemberNickName;
      this.setData({
        replyCommentId: replyCommentId,
        replyMemberNickName: replyMemberNickName,
        replyMemberId: replyMemberId,
        placeholder: '回复 ' + replyMemberNickName,
        inputShowed: true
      });
    },
    cancelReply: function (e) {
      this.setData({
        replyCommentId: "",
        replyMemberNickName: "",
        replyMemberId: "",
        placeholder: "喜欢吗？来聊一句吧！"
      });
    },
    handleSubmit: function () {
      if (this.data.topicMemberCommentContent.trim() === '') {
        wx.showToast({
          title: '评论不能为空',
          icon: 'none',
          duration: 2000
        });
        this.cancelReply();
        return;
      }
      http.request({
        isToast: true,
        url: '/topic/member/comment/mobile/v1/save',
        data: {
          topicId: this.data.topicId,
          replyCommentId: this.data.replyCommentId,
          replyMemberId: this.data.replyMemberId,
          topicMemberCommentContent: this.data.topicMemberCommentContent
        },
        success: function (data) {
          notification.emit("member-comment-topic", { topicId: this.data.topicId });
        }.bind(this)
      });
    },
    //头像进入
    commentImageTap:function(e){
      var memberId  = e.target.dataset.memberId;  
      memberId
      console.log('进入头像'+memberId);
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + memberId
      });
    },
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        windowWidth: getApp().globalData.windowWidth,
        windowHeight: getApp().globalData.windowHeight,
        commentList: [],
        commentPageIndex: 1,
        commentPageSize: 10,
        commentTotal: 0
      });
      this.getCommentData();
      wx.stopPullDownRefresh();
    }
})
