footer -bookmarkconst constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    isActive: false,
    forumList: [],
  },
  handelSelect: function (e) {
    var index = e.currentTarget.dataset.index;

    var forumList = this.data.forumList;
    var selectForum = forumList[index];

    selectForum.isActive = (selectForum.isActive ? false : true);

    forumList[index] = selectForum;

    var isActive = false;
    for (var i = 0; i < forumList.length; i ++) {
      if (forumList[i].isActive) {
        isActive = true;
        break;
      }
    }
    this.setData({
      forumList: forumList,
      isActive: isActive
    })
  },

  bindViewTap: function () {

  },
  onLoad: function () {
    this.getForumData();
  },
  getForumData: function () {
    http.request({
      url: '/forum/member/follow/mobile/v1/my/follow/list',
      data: {
        pageIndex: 1,
        pageSize: 100
      },
      success: function (data) {
        this.setData({
          forumList: data.list
        })
      }.bind(this)
    });
  },
  selectedForum: function () {
    var forumList = [];
    
    for (var i = 0; i < this.data.forumList.length; i++) {
      if (this.data.forumList[i].isActive) {
        forumList.push(this.data.forumList[i]);
      }
    }
    if (forumList.length > 3) {
      wx.showToast({
        title: '标签不能超过3个',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    
    notification.emit("topic-add-select-forum", {
      forumList: forumList
    });
    wx.navigateBack();
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
