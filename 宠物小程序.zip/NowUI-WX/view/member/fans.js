const http = require("../../common/http.js");   //链接后台接口数据
const wechat = require("../../common/wechat.js");  //微信接口
const constant = require("../../common/constant.js"); //图片地址
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js"); //跨页面传值
Page({
    data: {
      followMobileList:[],
      member: '', //当前登陆的会员信息
      imageHost: constant.imageHost, //图片地址
      pageIndex : 0, 
      pageSize : 10 ,
      memberId: ''
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      var member = storage.getMember().memberId;
      this.setData({
        member: member
      });
      if (options.memberId) {
        this.setData({
          memberId: options.memberId
        });
        this.getMemberFollowData();
      } else {
        this.getFollowMobileData();
      }
    }, 
    //他人粉丝列表
    getMemberFollowData: function () {
      http.request({
        url: '/sns/member/follow/mobile/v1/follow/list',
        data: {
          followMemberId: this.data.memberId,
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          console.log(data);
          if (data) {
            console.log('他人粉丝');
            this.setData({
              followMobileList: data.list
            })

          }
        }.bind(this)
      });
    },
    //我的粉丝列表
    getFollowMobileData:function(){
      http.request({
        url: '/sns/member/follow/mobile/v1/follow/me/list',
        data: {
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          if (data) {
            this.setData({
              followMobileList: data.list
            })
          }
        }.bind(this)
      });
    },
    //关注按钮
    addMobileChange:function(e){
      var index = e.target.dataset.index;
      console.log("关注会员："+index);
      console.log('当前会员id:' + this.data.member.memberId);
      if(index == this.data.member.memberId){
        wx.showToast({
          title: '不能关注自己',
          mask: true,
          icon: "none",
          duration: 1000
        });
        return;
      }
      http.request({
        isToast: true,
        url: '/sns/member/follow/mobile/v1/save',
        data: {
          followMemberId: index
        },
        success: function (data) {
          if (data) {
            if (this.data.memberId) {
              this.getMemberFollowData();
            } else {
              this.getFollowMobileData();
            }
          }

        }.bind(this)
      });
    },
  noMemberChange: function (event){
    console.log('进入取消关注');
    http.request({
      isToast: true,
      url: '/sns/member/follow/mobile/v1/delete',
      data: {
        followMemberId: event.currentTarget.dataset.index
      },
      success: function (data) {
       console.log('取消！');
       if (this.data.memberId) {
         console.log('他人粉丝列表');
         this.getMemberFollowData();
       } else {
         console.log('我的粉丝列表');
         this.getFollowMobileData();
       }
      }.bind(this)
    });

  },
    
    toMemberHomePage: function (e) {
      var memberId = e.target.dataset.memberid;
      var member = storage.getMember();
      console.log(memberId)
      console.log(member.memberId)
      if (memberId === member.memberId) {
        wx.navigateTo({
          url: '/view/member/homePage'
        });
      } else {
        wx.navigateTo({
          url: '/view/member/otherHomePage?memberId=' + memberId
        });
      }
    },
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        pageIndex: 0,
        pageSize: 10
      });
      if (this.data.memberId) {
        this.setData({
          memberId: options.memberId
        });
        this.getMemberFollowData();
      } else {
        this.getFollowMobileData();
      }
      wx.stopPullDownRefresh();
    }
})
