const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");

Page({
    data: {
      memberList:[],
      memberId: '', //当前登陆用户id
      memberNickName: '', //会员昵称
      memberAvatarPath: '',
      memberBackgroundImagePath: '',
      memberTopicCount: 0, //动态
      memberFollowCount: 0, //关注数
      memberBeFollowedCount: 0, //粉丝数,
      imageHost: constant.imageHost,
      IsRead:true
    },
    bindViewTap: function () {
    },
    //页面加载方法
    onShow: function(){
      this.dialogueData();
    },
    //页面第一次加载
    onLoad: function () {
      

      wechat.auth({
        checkLogin: true,
        success: function () {
          this.getMemberData();
          notification.on("member-delete-topic", this, function () {
            this.getMemberData();
          });
          notification.on("member-add-topic", this, function () {
            this.getMemberData();
          });
          notification.on("member-follow-member", this, function () {
            this.getMemberData();
          });
          notification.on("member-cancel-follow-member", this, function () {
            this.getMemberData();
          });
        }.bind(this),
        fail: function () {
          
        }.bind(this)
      });
    },
    //获取当前用户宠物列表
    getMemberData: function () {
      http.request({
        url: '/sns/member/mobile/v1/find',
        data: {},
        success: function (data) {
          if (data) {
            this.setData({
              memberNickName: data.memberNickName,
              memberTopicCount: data.memberTopicCount, //动态
              memberFollowCount: data.memberFollowCount, //关注数
              memberBeFollowedCount: data.memberBeFollowedCount, //粉丝数
              memberId: data.memberId,
              memberAvatarPath: data.memberAvatarPath,
              memberBackgroundImagePath: data.memberBackgroundImagePath ? data.memberBackgroundImagePath : ''
            })
          }
        }.bind(this)
      });
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    },
    //对话列表
    dialogueData: function () {
      //初始化红点
      this.setData({
        IsRead: true
      });

      http.request({
        url: '/sns/member/dialogue/mobile/v1/listByInitiateMemberId',
        data: {
          
        },
        success: function (data) {
          console.log(data);
          //创建一个list
          // var list = [];
          if (data.length > 0) {
            for (var i = 0; i < data.length; i++) {
              var topicLike = data[i];
              topicLike.systemCreateTime = util.timestampToTime(topicLike.systemCreateTime);
              topicLike.systemTime = util.timeToDateStr(topicLike.newTime);
              // list.push(topicLike);
              if (data[i].IsRead == false) {
                this.setData({
                  IsRead: false
                });
              }
            }

          }
        }.bind(this)
      });
    },
    
})
