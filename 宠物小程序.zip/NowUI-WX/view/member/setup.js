Page({
    data: {
      
    },
    handleClearStorage: function () {
      wx.showToast({
        title: '清除成功',
        icon: 'success',
        duration: 3000
      })
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      wx.getStorageInfo({
        success: function (res) {
          console.log(res.keys)
          console.log(res.currentSize)
          console.log(res.limitSize)
        }
      })
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
