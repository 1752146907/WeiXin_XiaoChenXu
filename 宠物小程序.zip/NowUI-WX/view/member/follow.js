const upload = require("../../common/upload.js");
const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
Page({
    data: {
      member: storage.getMember(), //当前登陆的会员信息
      followList: [],
      imageHost: constant.imageHost,
      pageIndex: 1,
      pageSize: 10,
      total: 0,
      memberId: ''
    },
    bindViewTap: function () {
      
    },
    onLoad: function (options) {
      this.getFollowList();
      notification.on("member-cancel-member-follow", this, function (data) {
        var followList = this.data.followList;
        for (var i = 0; i < this.data.followList.length; i++) {
          if (data.memberId === this.data.followList[i].followMemberId) {
            followList.splice(i, 1);
          }
        }
        this.setData({
          followList: followList
        });
      });
    },
    // 取消关注
    handleCancelFollow: function (e) {
      http.request({
        isToast: true,
        url: '/sns/member/follow/mobile/v1/delete',
        data: {
          followMemberId: e.currentTarget.dataset.memberId,
        },
        success: function (data) {
          wx.showToast({
            title: '取消关注成功',
            icon: 'none',
            duration: 1500
          });
          notification.emit("member-cancel-member-follow", { memberId: e.currentTarget.dataset.memberId})
        }.bind(this)
      })
    },
    // 获取会员关注列表
    getFollowList: function () {
      http.request({
        url: '/sns/member/follow/mobile/v1/my/follow/list',
        data: {
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          var followList = this.data.followList;
          if (data.list.length > 0) {
            followList = followList.concat(data.list);
          }
          this.setData({
            followList: followList
          })
        }.bind(this)
      });
    },
    handleToHomePage:function(e){
      var memberId = e.target.dataset.memberId;  
      var member = storage.getMember();
      if (memberId === member.memberId) {
        wx.navigateTo({
          url: '/view/member/homePage'
        });
      } else {
        wx.navigateTo({
          url: '/view/member/otherHomePage?memberId=' + memberId
        });
      }
    },
    onReachBottom: function () {
      var pageIndex = this.data.pageIndex;
      var pageSize = this.data.pageSize;
      var total = this.data.total;
      if (pageIndex * pageSize >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        pageIndex: pageIndex
      });
      this.getFollowList();
    },  
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        followList: []
      })
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
