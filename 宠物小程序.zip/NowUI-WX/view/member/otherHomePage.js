const http = require("../../common/http.js");   //链接后台接口数据
const wechat = require("../../common/wechat.js");  //微信接口
const constant = require("../../common/constant.js"); //图片地址
const util = require("../../common/util.js");
const notification = require("../../common/notification.js"); //跨页面传值
const storage = require("../../common/notification.js");
Page({
    data: {
      imageHost: constant.imageHost,
      memberId: "",
      member: {},
      topicPageIndex: 1,
      topicPageSize: 6,
      topicList: [],
      topicId: '',
      topicTotal: 0,
      forumPageIndex: 1,
      forumPageSize: 4,
      forumTotal: 0,
      forumList: [],
      petList: [],
      deleteTap: false,
      tabs: [
        {
          name: "动态"
        }, {
          name: "圈子"
        }, {
          name: "宠物"
        }
      ],
      activeIndex: 0,
      sliderOffset: 0,
      sliderLeft: 54
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      if (options.memberId) {
        this.setData({
          memberId: options.memberId
        });
        this.handleLoadMemberData();
        this.handleLoadTopicData();
        this.handleLoadForumData();
        this.handleLoadPetData();
        notification.on("member-follow-member", this, function (data) {
          var member = this.data.member;

          member.memberIsFollow = true;
          this.setData({
            member: member
          });
        });

        notification.on("member-cancel-follow-member", this, function (data) {
          var member = this.data.member;

          member.memberIsFollow = false;
          this.setData({
            member: member
          });
        });

        notification.on("member-like-topic", this, function (data) {
          var topicList = this.data.topicList;
          if (this.data.topicList.length > 0) {
            for (var i = 0; i < this.data.topicList.length; i++) {
              if (data.topicId === this.data.topicList[i].topicId) {
                var topic = this.data.topicList[i];
                topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
                topic.memberIsLike = true;
                topicList[i] = topic;
              }
            }
            this.setData({
              topicList: topicList
            })
          }
        });
        notification.on("member-cancel-like-topic", this, function (data) {
          var topicList = this.data.topicList;
          if (this.data.topicList.length > 0) {
            for (var i = 0; i < this.data.topicList.length; i++) {
              if (data.topicId === this.data.topicList[i].topicId) {
                var topic = this.data.topicList[i];
                topic.topicLikeCount = topic.topicLikeCount > 1 ? topic.topicLikeCount - 1 : 0;
                topic.memberIsLike = false;
                topicList[i] = topic;
              }
            }
            this.setData({
              topicList: topicList
            })
          }
        });
      }
    },
    handleFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/sns/member/follow/mobile/v1/save',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              notification.emit("member-follow-member", { memberId: event.currentTarget.dataset.memberId});
            }.bind(this)
          });
        }.bind(this)
      });
    },
    handleCancelFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/sns/member/follow/mobile/v1/delete',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              notification.emit("member-cancel-follow-member", { memberId: event.currentTarget.dataset.memberId });
            }.bind(this)
          });
        }.bind(this)
      });
    },
    handleLikeTopic: function (e) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/topic/member/like/mobile/v1/save',
            data: {
              topicId: e.currentTarget.dataset.topicId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-like-topic", { topicId: e.currentTarget.dataset.topicId });
              }
            }.bind(this)
          });
        }.bind(this)
      });
    },
    handleCancelLikeTopic: function (e) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/topic/member/like/mobile/v1/delete',
            data: {
              topicId: e.currentTarget.dataset.topicId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-cancel-like-topic", { topicId: e.currentTarget.dataset.topicId });
              }
            }.bind(this)
          });
        }.bind(this)
      });
    },
    tabClick: function (e) {
      this.setData({
        sliderOffset: e.currentTarget.offsetLeft,
        activeIndex: e.currentTarget.id
      });
    },
    handleLoadMemberData: function () {
      http.request({
        url: '/sns/member/mobile/v1/find/by/member/id',
        data: {
          memberId: this.data.memberId
        },
        success: function (data) {
          if (data) {
            this.setData({
              member: data
            })
          }
        }.bind(this)
      });

    },
    //动态数据
    handleLoadTopicData: function () {
      http.request({
        url: '/topic/mobile/v1/list/by/member/id',
        data: {
          memberId: this.data.memberId,
          pageIndex: this.data.topicPageIndex,
          pageSize: this.data.topicPageSize
        },
        success: function (data) {
          if (data) {
            var topicList = data.list;
            if (topicList.length > 0) {
              for (var i = 0; i < topicList.length; i++) {
                topicList[i].systemCreateTime = util.timeToDateStr(topicList[i].systemCreateTime);
              }
            }
            topicList = this.data.topicList.concat(topicList);
            this.setData({
              topicList: topicList,
              topicTotal: data.total
            });
          }
        }.bind(this)
      });
    },
    //圈子数据
    handleLoadForumData: function () {
      http.request({
        url: '/forum/member/follow/mobile/v1/my/follow/member/list',
        data: {
          memberId: this.data.memberId,
          pageIndex: this.data.forumPageIndex,
          pageSize: this.data.forumPageSize
        },
        success: function (data) {
          var forumList = this.data.forumList;
          if (data.list && data.list.length > 0) {
            forumList = forumList.concat(data.list);
          }
          this.setData({
            forumList: forumList,
            forumTotal: data.total
          })
        }.bind(this)
      });
    },
    //宠物列表
    handleLoadPetData: function () {
      http.request({
        url: '/pet/mobile/v1/list/by/member/id',
        data: {
          memberId: this.data.memberId
        },
        success: function (data) {
          if (data) {
            this.setData({
              petList: data
            })
          }
        }.bind(this)
      });
    },
    //滑动最底部加载
    onReachBottom: function () {
      var activeIndex = this.data.activeIndex;
      if (activeIndex == 0) {
        var pageIndex = this.data.topicPageIndex;
        var pageSize = this.data.topicPageSize;
        var total = this.data.topicTotal;
        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          topicPageIndex: pageIndex
        });
        this.handleLoadTopicData();
      } else if (activeIndex == 1) {
        var pageIndex = this.data.forumPageIndex;
        var pageSize = this.data.forumPageSize;
        var total = this.data.forumTotal;
        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          forumPageIndex: pageIndex
        });
        this.handleLoadForumData();
      } else {

      }
    },
    toDialogue: function (e) {
      console.log("会员id:"+e.target.dataset.memberid);
      wx.navigateTo({
        url: '/view/member/dialogue/index?memberDialogueId=' + e.target.dataset.memberid
      })
    },
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        member: {},
        topicPageIndex: 1,
        topicPageSize: 6,
        topicList: [],
        topicId: '',
        topicTotal: 0,
        forumPageIndex: 1,
        forumPageSize: 4,
        forumTotal: 0,
        forumList: [],
        petList: [],
      });
      this.handleLoadMemberData();
      this.handleLoadTopicData();
      this.handleLoadForumData();
      this.handleLoadPetData();
      wx.stopPullDownRefresh();
    }
})
