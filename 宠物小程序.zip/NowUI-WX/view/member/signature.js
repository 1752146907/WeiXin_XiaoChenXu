const http = require("../../common/http.js");   //链接后台接口数据
const wechat = require("../../common/wechat.js");  //微信接口
const constant = require("../../common/constant.js"); //图片地址
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    isFocus: false,
    memberSignature: ''
  }, 
  bindViewTap: function () {

  },
  autographFocus: function (e) {
    var memberSignature = e.detail.value;
    console.log(memberSignature)
    if (memberSignature.trim() !== '') {
      this.setData({
        isFocus: true,
        memberSignature: memberSignature
      })
    } else{
      this.setData({
        isFocus: false
      })
    }
  },
  onLoad: function (options) {
    var memberSignature = options.memberSignature;
    if (memberSignature && memberSignature !== '') {
      this.setData({
        memberSignature: memberSignature
      })
    }
  },
  handleUpdateSignature: function (e) {
    var memberSignature = e.currentTarget.dataset.membersignature
    this.setData({
      memberSignature: e.currentTarget.dataset.membersignature
    });
    http.request({
      isToast: true,
      url: '/member/mobile/v1/update/signature',
      data: {
        memberSignature: memberSignature
      },
      success: function (data) {
        notification.emit("member-update-signature", {memberSignature: memberSignature});
        wx.navigateBack({
          delta: 1
        })
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
