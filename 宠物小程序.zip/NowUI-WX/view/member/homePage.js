const http = require("../../common/http.js");   //链接后台接口数据
const wechat = require("../../common/wechat.js");  //微信接口
const constant = require("../../common/constant.js"); //图片地址
const util = require("../../common/util.js");
const upload = require("../../common/upload.js");
const notification = require("../../common/notification.js"); //跨页面传值
const storage = require("../../common/notification.js");

Page({
    data: {
      imageHost: constant.imageHost,
      member: {}, 
      topicPageIndex: 1,
      topicPageSize: 4,
      topicList: [],
      topicId: '',
      topicTotal: 0,
      forumPageIndex: 1,
      forumPageSize: 4,
      forumTotal: 0,
      forumList: [],
      petList: [],  
      deleteTap:false,
      tabs: [
        {
          name:"动态"
        }, {
          name:"圈子"
        }, {
          name: "宠物"
        }
      ],
      activeIndex: 0,
      sliderOffset: 0,
      sliderLeft: 20
    },
    bindViewTap: function () {

    },
    onLoad: function (options) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          this.handleLoadMemberData();
          this.handleLoadTopicData();
          this.handleLoadForumData();
          this.handleLoadPetData();
        }.bind(this),
        fail: function () {

        }.bind(this)
      });
      notification.on("member-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        if (this.data.topicList.length > 0) {
          for (var i = 0; i < this.data.topicList.length; i++) {
            if (data.topicId === this.data.topicList[i].topicId) {
              var topic = this.data.topicList[i];
              topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
              topic.memberIsLike = true;
              topicList[i] = topic;
            }
          }
          this.setData({
            topicList: topicList
          })
        }
      });
      notification.on("member-cancel-like-topic", this, function (data) {
        var topicList = this.data.topicList;
        if (this.data.topicList.length > 0) {
          for (var i = 0; i < this.data.topicList.length; i++) {
            if (data.topicId === this.data.topicList[i].topicId) {
              var topic = this.data.topicList[i];
              topic.topicLikeCount = topic.topicLikeCount > 1 ? topic.topicLikeCount - 1 : 0;
              topic.memberIsLike = false;
              topicList[i] = topic;
            }
          }
          this.setData({
            topicList: topicList
          })
        }
      });
      notification.on("member-delete-topic", this, function (data) {
        var topicList = this.data.topicList;
        var topicTotal = this.data.total;

        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            topicList.splice(i, 1);
            topicTotal = topicTotal > 0 ? topicTotal - 1 : 0;
          }
        }
        this.setData({
          topicList: topicList,
          topicTotal: topicTotal
        });
      });
    },
    changeBackground: function () {
      wx.showActionSheet({
        itemList: ['更换封面相册'],
        success: function (res) {
          wx.chooseImage({
            count: 1,
            sizeType: ['compressed'],
            sourceType: ['album', 'camera'],
            success: function (res) {
              upload.uploadImage(res, function (result) {
                if (result.imageList && result.imageList.length > 0) {
                  this.handleUpdateBackground(result.imageList[0].fileId, result.imageList[0].filePath);
                }
              }.bind(this));
            }.bind(this)
          })
        }.bind(this)
      });
    },
    handleUpdateBackground: function (memberBackgroundImageId, memberBackgroundImagePath) {
      http.request({
        url: '/member/mobile/v1/update/background',
        data: {
          memberBackgroundImageId: memberBackgroundImageId,
          memberBackgroundImagePath: memberBackgroundImagePath
        },
        success: function (data) {
          if (data) {
            var member = this.data.member;
            member.memberBackgroundImagePath = memberBackgroundImagePath;
            this.setData({
              member: member
            });
          }
        }.bind(this)
      });
    },
    tabClick: function (e) {
      this.setData({
        sliderOffset: e.currentTarget.offsetLeft,
        activeIndex: e.currentTarget.id
      });
    },
    handleLoadMemberData: function () {
      http.request({
        url: '/sns/member/mobile/v1/find',
        data: { 
        },
        success: function (data) {
          if (data) {
            this.setData({
              member: data
            })
          }
        }.bind(this)
      });
    },
    //动态数据
    handleLoadTopicData: function() {
       http.request({
         url: '/topic/mobile/v1/list/by/user/id',
         data: {
           pageIndex: this.data.topicPageIndex,
           pageSize: this.data.topicPageSize
         },
         success: function (data) {
           if (data) {
             var topicList = data.list;
             if (topicList.length > 0) {
               for (var i = 0; i < topicList.length; i++) {
                 topicList[i].systemCreateTime = util.timeToDateStr(topicList[i].systemCreateTime);
               }
             }
             topicList = this.data.topicList.concat(topicList);
             this.setData({
               topicList: topicList,
               topicTotal: data.total
             });
           }
         }.bind(this)
       });
    },
    //圈子数据
    handleLoadForumData: function () {
      http.request({
        url: '/forum/member/follow/mobile/v1/my/follow/list',
        data: {
          pageIndex: this.data.forumPageIndex,
          pageSize: this.data.forumPageSize
        },
        success: function (data) {
          if (data) {
            if (data.list && data.list.length > 0) {
              this.setData({
                forumList: this.data.forumList.concat(data.list),
                forumTotal: data.total
              })
            }
          }
        }.bind(this)
      });
    },
    //宠物列表
    handleLoadPetData: function() {
      http.request({
        url: '/pet/mobile/v1/list/by/user/id',
        data: {},
        success: function (data) {
          if (data) {
            this.setData({
              petList: data
            })
          }
        }.bind(this)
      });
    },
    //滑动最底部加载
    onReachBottom: function () {
      var activeIndex = this.data.activeIndex;
      if (activeIndex == 0) {
        var pageIndex = this.data.topicPageIndex;
        var pageSize = this.data.topicPageSize;
        var total = this.data.topicTotal;
        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          topicPageIndex: pageIndex
        });
        this.handleLoadTopicData();
      } else if (activeIndex == 1) {
        var pageIndex = this.data.forumPageIndex;
        var pageSize = this.data.forumPageSize;
        var total = this.data.forumTotal;
        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          forumPageIndex: pageIndex
        });
        this.handleLoadForumData();
      } else {

      }
    },
    handleToAddPet: function () {
      wx.navigateTo({
        url: '/view/member/pet/addPet'
      });
    },
    handlePet: function (e) {
      var index = e.currentTarget.dataset.index;
      var petList = this.data.petList;
      var pet = petList[index];
      pet.petIsEdit = pet.petIsEdit ? false : true;
      petList[index] = pet;
      this.setData({
        petList: petList
      });
    },
    handleTopic: function (e) {
      var index = e.currentTarget.dataset.index;
      var topicList = this.data.topicList;
      var topic = topicList[index];
      topic.topicIsDelete = topic.topicIsDelete ? false : true;
      topicList[index] = topic;
      this.setData({
        topicList: topicList
      });
    },
    handelDeleteTopic: function (e) {
      wx.showModal({
        title: '提示',
        content: '您确定要删除这条动态吗？',
        success: function (res) {
          if (res.confirm) {
            var index = e.currentTarget.dataset.index;
            var topicList = this.data.topicList;
            var topic = topicList[index];
            wechat.auth({
              checkLogin: true,
              success: function () {
                http.request({
                  isToast: true,
                  url: '/topic/mobile/v1/delete',
                  data: {
                    topicId: topic.topicId
                  },
                  success: function (data) {
                    if (data) {
                      notification.emit("member-delete-topic", { topicId: topic.topicId });
                    }
                  }.bind(this)
                });
              }.bind(this)
            });
          } else if (res.cancel) {
            
          }
        }.bind(this)
      })
    },
    handleLikeTopic: function (e) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/topic/member/like/mobile/v1/save',
            data: {
              topicId: e.currentTarget.dataset.topicId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-like-topic", { topicId: e.currentTarget.dataset.topicId });
              }
            }.bind(this)
          });
        }.bind(this)
      });
    },
    handleCancelLikeTopic: function (e) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            isToast: true,
            url: '/topic/member/like/mobile/v1/delete',
            data: {
              topicId: e.currentTarget.dataset.topicId
            },
            success: function (data) {
              if (data) {
                notification.emit("member-cancel-like-topic", { topicId: e.currentTarget.dataset.topicId });
              }
            }.bind(this)
          });
        }.bind(this)
      });
    }, 
    handleDeletePet: function(e) {
      var index = e.currentTarget.dataset.index;
      var petList = this.data.petList;
      var pet = petList[index];
      http.request({
        url: '/pet/mobile/v1/delete',
        data: {
          petId: pet.petId,
          systemVersion: pet.systemVersion
        },
        success: function (data) {
          if (data) {
            wx.showToast({
              title: '删除成功',
              mask: true,
              icon: "none",
              duration: 1500
            });
            petList.splice(index, 1);
            this.setData({
              petList: petList
            });
          }
        }.bind(this)
      });
    },
    handleEditPet: function (e) {
      var index = e.currentTarget.dataset.index;
      var petList = this.data.petList;
      var pet = petList[index];
      wx.navigateTo({
        url: '/view/member/pet/editPet?petIndexCode=' + pet.petId + '&isFromHomePage=true',
      });
    },
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        topicPageIndex: 1,
        topicPageSize: 4,
        topicList: [],
        topicId: '',
        topicTotal: 0,
        forumPageIndex: 1,
        forumPageSize: 4,
        forumTotal: 0,
        forumList: [],
        petList: [],  
      });
      this.handleLoadMemberData();
      this.handleLoadTopicData();
      this.handleLoadForumData();
      this.handleLoadPetData();
      wx.stopPullDownRefresh();
    }
})
