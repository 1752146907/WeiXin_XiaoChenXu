const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
Page({
    data: {
      list: [],
      pageIndex:1,
      pageSize: 6,
      total: 0,
      imageHost: constant.imageHost,
      member: storage.getMember()
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      this.setData({
        list: [],
        pageIndex: 1,
        pageSize: 6,
        total: 0
      });
      this.handleLoadTopicLikeData();
    },
    handleLoadTopicLikeData: function () {
      http.request({
        url: '/topic/member/like/mobile/v1/list',
        data: {
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          var list = this.data.list;
          if (data.list && data.list.length > 0) {
            for (var i = 0; i < data.list.length; i++) {
              var topicLike = data.list[i];
              topicLike.systemCreateTime = util.timeToDateStr(topicLike.systemCreateTime);
              list.push(topicLike);
            }
          }
          this.setData({
            list: list,
            total: data.total
          });
        }.bind(this)
      });
    },
    onReachBottom: function () {
      var pageIndex = this.data.pageIndex;
      var pageSize = this.data.pageSize;
      var total = this.data.total;
      if ((pageIndex * pageSize) >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        pageIndex: pageIndex
      });
      this.handleLoadTopicLikeData();
    },
    handleToHomePage: function (e) {
      var memberId = e.currentTarget.dataset.memberId;
      if (memberId === this.data.member.memberId) {
        wx.navigateTo({
          url: '/view/member/homePage',
        });
      } else {
        wx.navigateTo({
          url: '/view/member/otherHomePage?memberId=' + memberId,
        });
      }
    },
    handleToTopic: function (e) {
      var topicId = e.currentTarget.dataset.topicId;
      var topicType = e.currentTarget.dataset.topicType;

      if (topicType === 'SHORT_TEXT') {
        wx.navigateTo({
          url: '/view/topic/detail?topicId=' + topicId,
        });
      } else if (topicType === 'LONG_TEXT') {
        wx.navigateTo({
          url: '/view/knowledge/detail?topicId=' + topicId,
        });
      }
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
