const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
const storage = require("../../common/storage.js");

Page({
  data: {
    IsRead:true,
    member: storage.getMember(), //当前登陆的会员信息
    dialogueList:[],
    items: [],
    startX: 0, //开始坐标
    startY: 0
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      // this.dialogueData();
      // for (var i = 0; i < 1; i++) {
      //   this.data.items.push({
      //     isTouchMove: false //默认全隐藏删除
      //   })
      // }
      // this.setData({
      //   items: this.data.items
      // })
    },
    onShow: function () {
      console.log('进入');
      this.dialogueData();
      for (var i = 0; i < 1; i++) {
        this.data.items.push({
          isTouchMove: false //默认全隐藏删除
        })
      }
      this.setData({
        items: this.data.items
      })
    },
    //手指触摸动作开始 记录起点X坐标
    touchstart: function (e) {
      //开始触摸时 重置所有删除
      this.data.items.forEach(function (v, i) {
        if (v.isTouchMove)//只操作为true的
          v.isTouchMove = false;
      })
      this.setData({
        startX: e.changedTouches[0].clientX,
        startY: e.changedTouches[0].clientY,
        items: this.data.items
      })
    },
    //滑动事件处理
    touchmove: function (e) {
      var that = this,
        index = e.currentTarget.dataset.index,//当前索引
        startX = that.data.startX,//开始X坐标
        startY = that.data.startY,//开始Y坐标
        touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
        touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
        //获取滑动角度
        angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
      that.data.items.forEach(function (v, i) {
        v.isTouchMove = false
        //滑动超过30度角 return
        if (Math.abs(angle) > 30) return;
        if (i == index) {
          if (touchMoveX > startX) //右滑
            v.isTouchMove = false
          else //左滑
            v.isTouchMove = true
        }
      })
      //更新数据
      that.setData({
        items: that.data.items
      })
    },
    /**
     * 计算滑动角度
     * @param {Object} start 起点坐标
     * @param {Object} end 终点坐标
     */
    angle: function (start, end) {
      var _X = end.X - start.X,
        _Y = end.Y - start.Y
      //返回角度 /Math.atan()返回数字的反正切值
      return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
    },
    //删除事件
    delete: function (e) {
      this.data.items.splice(e.currentTarget.dataset.index, 1)
      this.setData({
        items: this.data.items
      })
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    },

  //对话列表
  dialogueData: function () {
    //初始化红点
    this.setData({
      IsRead: true
    });

      http.request({
        url: '/sns/member/dialogue/mobile/v1/listByInitiateMemberId',
        data: {

        },
        success: function (data) {
          console.log(data);
          //创建一个list
          // var list = [];
          if (data.length > 0) {
            for (var i = 0; i < data.length; i++) {
              var topicLike = data[i];
              topicLike.systemCreateTime = util.timestampToTime(topicLike.systemCreateTime);
              topicLike.systemTime = util.timeToDateStr(topicLike.newTime);
              // list.push(topicLike);
              if (data[i].IsRead == false){
                console.log('false');
                this.setData({
                  IsRead:false
                });
              }
            }

          }

          // this.setData({
          //   dialogueList: list
          // })
        }.bind(this)
      });
    },
})
