const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
Page({
  data: {
    isShop: true,
    isTopic: false,
    memberId: '',
    merchantBookmarkList: [],
    merchantBookmarkPageIndex: 1,
    merchantBookmarkPageSize: 8,
    merchantBookmarkTotal: 0,
    topicBookmarkList: [],
    topicBookmarkPageIndex: 1,
    topicBookmarkPageSize: 8,
    topicBookmarkTotal: 0,
    imageHost: constant.imageHost
  },
  handleShop: function () {
    this.setData({
      isShop: !this.data.isShop,
      isTopic: !this.data.isTopic
    })
  },
  handleTopic: function () {
    this.setData({
      isShop: !this.data.isShop,
      isTopic: !this.data.isTopic
    })
  },
  bindViewTap: function () {

  },
  onLoad: function (options) {
    if (options.memberId) {
      this.setData({
        memberId: options.memberId
      });
    } 
    this.getMerchantCollectionData();
    this.getTopicCollectionData();
  },
  getMerchantCollectionData: function () {
    if (this.data.memberId && this.data.memberId !== '') {
      this.getMemberMerchantCollectionData();
    } else {
      this.getUserMerchantCollectionData();
    }
  },
  getTopicCollectionData: function () {
    if (this.data.memberId && this.data.memberId !== '') {
      this.getMemberTopicCollectionData();
    } else {
      this.getUserTopicCollectionData();
    }
  },
  getMemberMerchantCollectionData: function () {
    http.request({
      url: '/merchant/member/bookmark/mobile/v1/list/by/member/id',
      data: {
        memberId: this.data.memberId,
        pageIndex: this.data.merchantBookmarkPageIndex,
        pageSize: this.data.merchantBookmarkPageSize
      },
      success: function (data) {
        var merchantBookmarkList = this.data.merchantBookmarkList;
        if (data.list && data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var merchantBookmark = data.list[i];
            merchantBookmark.systemCreateTime = util.timeToDateStr(merchantBookmark.systemCreateTime);
            merchantBookmarkList.push(merchantBookmark);
          }
        }
        this.setData({
          merchantBookmarkList: merchantBookmarkList,
          merchantBookmarkTotal: data.total
        });
      }.bind(this)
    });
  },
  getUserMerchantCollectionData: function () {
    http.request({
      url: '/merchant/member/bookmark/mobile/v1/list/by/user/id',
      data: {
        pageIndex: this.data.merchantBookmarkPageIndex,
        pageSize: this.data.merchantBookmarkPageSize
      },
      success: function (data) {
        var merchantBookmarkList = this.data.merchantBookmarkList;
        if (data.list && data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var merchantBookmark = data.list[i];
            merchantBookmark.systemCreateTime = util.timeToDateStr(merchantBookmark.systemCreateTime);
            merchantBookmarkList.push(merchantBookmark);
          }
        }
        this.setData({
          merchantBookmarkList: merchantBookmarkList,
          merchantBookmarkTotal: data.total
        });
      }.bind(this)
    });
  },
  getMemberTopicCollectionData: function () {
    http.request({
      url: '/topic/member/bookmark/mobile/v1/list/by/member/id',
      data: {
        memberId: this.data.memberId,
        pageIndex: this.data.topicBookmarkPageIndex,
        pageSize: this.data.topicBookmarkPageSize
      },
      success: function (data) {
        var topicBookmarkList = this.data.topicBookmarkList;
        if (data.list && data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topicBookmark = data.list[i];
            topicBookmark.systemCreateTime = util.timeToDateStr(topicBookmark.systemCreateTime);
            topicBookmarkList.push(topicBookmark);
          }
        }
        this.setData({
          topicBookmarkList: topicBookmarkList,
          topicBookmarkTotal: data.total
        });
      }.bind(this)
    });
  },
  getUserTopicCollectionData: function () {
    http.request({
      url: '/topic/member/bookmark/mobile/v1/list/by/user/id',
      data: {
        pageIndex: this.data.topicBookmarkPageIndex,
        pageSize: this.data.topicBookmarkPageSize
      },
      success: function (data) {
        var topicBookmarkList = this.data.topicBookmarkList;
        if (data.list && data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topicBookmark = data.list[i];
            topicBookmark.systemCreateTime = util.timeToDateStr(topicBookmark.systemCreateTime);
            topicBookmarkList.push(topicBookmark);
          }
        }
        this.setData({
          topicBookmarkList: topicBookmarkList,
          topicBookmarkTotal: data.total
        });
      }.bind(this)
    });
  },
  onReachBottom: function () {
    if (this.data.isShop) {
      var pageIndex = this.data.merchantBookmarkPageIndex;
      var pageSize = this.data.merchantBookmarkPageSize;
      var total = this.data.merchantBookmarkTotal;

      if ((pageIndex * pageSize) >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        merchantBookmarkPageIndex: pageIndex
      });
      this.getMerchantCollectionData();
    } else {
      var pageIndex = this.data.topicBookmarkPageIndex;
      var pageSize = this.data.topicBookmarkPageSize;
      var total = this.data.topicBookmarkTotal;

      if ((pageIndex * pageSize) >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        topicBookmarkPageIndex: pageIndex
      });
      this.getTopicCollectionData();
    }
  },
  //刷新
  onPullDownRefresh: function () {
    this.setData({
      merchantBookmarkList: [],
      merchantBookmarkPageIndex: 1,
      merchantBookmarkPageSize: 8,
      merchantBookmarkTotal: 0,
      topicBookmarkList: [],
      topicBookmarkPageIndex: 1,
      topicBookmarkPageSize: 8,
      topicBookmarkTotal: 0,
    });
    this.getMerchantCollectionData();
    this.getTopicCollectionData();
    wx.stopPullDownRefresh();
  }
})
