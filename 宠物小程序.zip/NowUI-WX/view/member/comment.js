const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
Page({
    data: {
      isComment: true,
      isShare: false,
      commentList: [],
      commentPageIndex: 1,
      commentPageSize: 5,
      commentTotal: 0,
      shareList: [],
      sharePageIndex: 1,
      sharePageSize: 5,
      shareTotal: 0,
      imageHost: constant.imageHost,
      member: storage.getMember()
    },
    handleComment: function () {
      this.setData({
        isComment: !this.data.isComment,
        isShare: !this.data.isShare
      });
    },
    handleShare: function () {
      this.setData({
        isComment: !this.data.isComment,
        isShare: !this.data.isShare
      })
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      this.setData({
        commentList: [],
        commentPageIndex: 1,
        commentPageSize: 5,
        commentTotal: 0,
        shareList: [],
        sharePageIndex: 1,
        sharePageSize: 5,
        shareTotal: 0
      });
      this.handleLoadCommentData();
      this.handleLoadShareData();
    },
    handleLoadCommentData: function () {
      http.request({
        url: '/topic/member/comment/mobile/v1/list/by/topic/user/id',
        data: {
          pageIndex: this.data.commentPageIndex,
          pageSize: this.data.commentPageSize
        },
        success: function (data) {
          var commentList = this.data.commentList;
          if (data.list && data.list.length > 0) {
            for (var i = 0; i < data.list.length; i++) {
              var comment = data.list[i];
              comment.systemCreateTime = util.timeToDateStr(comment.systemCreateTime);
              commentList.push(comment);
            }
          }
          this.setData({
            commentList: commentList,
            commentTotal: data.total
          });
        }.bind(this)
      });
    },
    handleLoadShareData: function () {
      http.request({
        url: '/topic/topic/share/mobile/v1/list',
        data: {
          pageIndex: this.data.sharePageIndex,
          pageSize: this.data.sharePageSize
        },
        success: function (data) {
          var shareList = this.data.shareList;
          if (data.list && data.list.length > 0) {
            for (var i = 0; i < data.list.length; i++) {
              var share = data.list[i];
              share.systemCreateTime = util.timeToDateStr(share.systemCreateTime);
              shareList.push(share);
            }
          }
          this.setData({
            shareList: shareList,
            shareTotal: data.total
          });
        }.bind(this)
      });
    },
    onReachBottom: function () {
      if (this.data.isComment) {
        var pageIndex = this.data.commentPageIndex;
        var pageSize = this.data.commentPageSize;
        var total = this.data.commentTotal;

        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          commentPageIndex: pageIndex
        });
        this.handleLoadCommentData();
      } else {
        var pageIndex = this.data.sharePageIndex;
        var pageSize = this.data.sharePageSize;
        var total = this.data.shareTotal;

        if ((pageIndex * pageSize) >= total) {
          return;
        }
        pageIndex++;
        this.setData({
          sharePageIndex: pageIndex
        });
        this.handleLoadShareData();
      }
    },
    handleToHomePage: function (e) {
      var memberId = e.currentTarget.dataset.memberId;
      if (memberId === this.data.member.memberId) {
        wx.navigateTo({
          url: '/view/member/homePage',
        });
      } else {
        wx.navigateTo({
          url: '/view/member/otherHomePage?memberId=' + memberId,
        });
      }
    },
    handleToTopic: function (e) {
      var topicId = e.currentTarget.dataset.topicId;
      var topicType = e.currentTarget.dataset.topicType;

      if (topicType === 'SHORT_TEXT') {
        wx.navigateTo({
          url: '/view/topic/detail?topicId=' + topicId,
        });
      } else if (topicType === 'LONG_TEXT') {
        wx.navigateTo({
          url: '/view/knowledge/detail?topicId=' + topicId,
        });
      }
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
