const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    mask: false,
    activeIndex: 1,
    createForumList: [],
    followForumList: [],
    forumId: '',
    imageHost: constant.imageHost
  },
  handleEdit: function(e) {
    var forumId = e.currentTarget.dataset.forumId;
    this.setData({ 
      mask: !this.mask,
      forumId: forumId
    })
  },
  handleHideMask: function (e) {
    this.setData({
      mask: false,
      forumId: ''
    })
  },
  handleTab: function (e) {
    this.setData({
      activeIndex: e.currentTarget.dataset.index,
    })
  },
  onLoad: function () {
    this.getCreateForumData();
    this.getFollowForumData();
  },
  onShow: function () {
    this.getCreateForumData();
    this.getFollowForumData();
  },
  // 获取创建圈子的列表
  getCreateForumData: function() {
    http.request({
      url: '/forum/mobile/v1/my/create/list',
      data: {},
      success: function (data) {
        this.setData({
          createForumList: data
        })
      }.bind(this)
    });
  },
  // 获取加入圈子的列表
  getFollowForumData: function () {
    http.request({
      url: '/forum/mobile/v1/my/follow/list',
      data: {},
      success: function (data) {
        this.setData({
          followForumList: data
        })
      }.bind(this)
    });
  },
  // 跳转到编辑页面
  toEdit: function () {

    wx.navigateTo({
      url: '/view/forum/edit?forumId=' + this.data.forumId,
      success: function() {
        this.setData({
          mask: false,
          forumId: ''
        })
      }.bind(this)
    });
    
  },
  // 退出圈子
  handleQuit: function () {
    http.request({
      isToast: true,
      url: '/forum/member/follow/mobile/v1/delete',
      data: {
        forumId: this.data.forumId
      },
      success: function (data) {
        var followForumList = this.data.followForumList;
        for (var i = 0; i < this.data.followForumList.length; i++) {
          if (this.data.followForumList[i].forumId === this.data.forumId) {
            followForumList.splice(i, 1);
            break;
          }
        }
        this.setData({
          followForumList: followForumList,
          mask: false,
          forumId: ''
        })
        notification.emit("member-cancel-follow-forum", {});
        wx.showToast({
          title: '退出圈子成功',
          icon: 'success',
          duration: 2000
        });

      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
});