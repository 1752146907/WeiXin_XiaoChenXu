const http = require("../../common/http.js");   //链接后台接口数据
const wechat = require("../../common/wechat.js");  //微信接口
const constant = require("../../common/constant.js"); //图片地址
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    region: [],
    customItem: '全部',
    member: {},
    imageHost: constant.imageHost
  }, 
  bindViewTap: function () {

  },
  onShow: function () {
    
  },
  onLoad: function () {
    wechat.auth({
      checkLogin: true,
      success: function () {
        this.handleLoadMember();
      }.bind(this),
      fail: function () {

      }.bind(this)
    });
    notification.on("member-update-signature", this, function (data) {
      var member = this.data.member;
      member.memberSignature = data.memberSignature;
      this.setData({
        member: member
      })
    });
  },
  memberSignature: function (e) {
    wx.navigateTo({
      url: "/view/member/signature?memberSignature=" + this.data.member.memberSignature
    })
  },
  bindRegionChange: function (e) {
    var region = e.detail.value;
    if (region[0] === '全部') {
      region[0] = '';
    }
    if (region[1] === '全部') {
      region[1] = '';
    }
    if (region[2] === '全部') {
      region[2] = '';
    }
    http.request({
      isToast: true,
      url: '/member/mobile/v1/update/address',
      data: {
        memberProvince: region[0],
        memberCity: region[1],
        memberArea: region[2]
      },
      success: function (data) {
        this.setData({
          region: region
        });
      }.bind(this)
    });
  },
  handleLoadMember: function () {
    http.request({
      url: '/sns/member/mobile/v1/find',
      data: {
      },
      success: function (data) {
        if (data) {
          var region = this.data.region;
          if (data.memberProvince && data.memberCity && data.memberArea) {
            region.push(data.memberProvince);
            region.push(data.memberCity);
            region.push(data.memberArea);
          }
          this.setData({
            member: data,
            region: region
          });
        }
      }.bind(this)
    });
  },
  handleChangeSex: function (e) {
    http.request({
      isToast: true,
      url: '/member/mobile/v1/update/sex',
      data: {
        memberSex: e.detail.value
      },
      success: function (data) {
        
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
