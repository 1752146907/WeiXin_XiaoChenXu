const http = require("../../../common/http.js");
const wechat = require("../../../common/wechat.js");
const constant = require("../../../common/constant.js");
const util = require("../../../common/util.js");
const notification = require("../../../common/notification.js");
const storage = require("../../../common/storage.js");

Page({
    data: {
      dialogueRecordList: [], //聊天内容数据
      dialogueData:[],//聊天数据
      memberDialogueCode: '' ,//接收父级页面code
      imageHost: constant.imageHost,
      memberId: '', //当前登陆的会员信息id
      text:'', //发送的内容
      initiateMemberId:'',
      initiateUserId: '',
      respondMemberId:'',
      respondUserId: '',
      pageIndex: 1,
      pageSize: 5
  }, 
  bindViewTap: function () {
  },
  onLoad: function (options) {
    //得到单条聊天室id
    if (options.memberDialogueId) {
      this.setData({
        memberDialogueCode: options.memberDialogueId
      });
    };

    console.log("对方会员id:----"+this.data.memberDialogueCode);
     this.dialogueRecordData();
     this.dialogueIsRead();
     var memberId = storage.getMember().memberId;
     console.log("登录人会员id:---"+memberId);
     this.setData({
       memberId: memberId
     });
  },
  //用户点击页面就关闭未读状态
  dialogueIsRead:function() {
    http.request({
      url: '/sns/member/dialogue/record/model/v1/updateDialogueIsRead',
      data: {
        memberDialogueId: this.data.memberDialogueCode
      },
      success: function (data) {
      }.bind(this)
    });
  
  },

//对话内容列表
  dialogueRecordData: function () {
    http.request({
      url: '/sns/member/dialogue/record/mobile/v1/listByInitiateMemberId',
      data: {
        memberDialogueId: this.data.memberDialogueCode, //聊天室编号id
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize
      },
      success: function (data) {
        //没有聊天室
        if(!data){
          console.log('没有聊天内容');
          this.setData({
            initiateMemberId: this.data.memberId,
            respondMemberId: this.data.memberDialogueCode
          });
          return;
        };
        console.log('有聊天内容');
          var list = [];
          if (data[0].list.length > 0) {
            var time = '';
            for (var i = 0; i < data[0].list.length; i++) {
              var topicLike = data[0].list[i];
              // 当循环到最后一个数时再给他一个时间
              if (i == data[0].list.length - 1) {
                console.log('最后一个数' + i);
                console.log(data[0].list[i].memberDialogueContent);
                console.log("时间戳" + topicLike.systemCreateTime);
                topicLike.systemCreateTime = util.timestampToTime(topicLike.systemCreateTime);
                console.log("最顶上时间：---"+topicLike.systemCreateTime);
              }

              //判断时间数据是否重复
              if (time == util.timeToDateStrTime(topicLike.systemCreateTime)){
                console.log(topicLike.systemCreateTime);
                topicLike.systemCreateTime = " ";
              }else{
                console.log(topicLike.systemCreateTime);
                time = util.timeToDateStrTime(topicLike.systemCreateTime);
                topicLike.systemCreateTime = util.timeToDateStrTime(topicLike.systemCreateTime);
              }
              console.log('data长度：' + data[0].list.length);
              console.log('i：'+i);
              
              
              // list.push(topicLike);
              list.unshift(topicLike);
            }
          }
          this.setData({
            dialogueRecordList: list,
            dialogueData: data[0].data,
            initiateMemberId: data[0].data.initiateMemberId,
            respondMemberId: data[0].data.respondMemberId,
            initiateUserId: data[0].data.initiateUserId,
            respondUserId: data[0].data.respondUserId
          });
          console.log('------------------------');
          console.log(this.data.dialogueRecordList);
          console.log(this.data.dialogueData);
          wx.pageScrollTo({
            scrollTop: 1000000
          });

      }.bind(this)
    });
  },
  //获取发送的内容
  textInput: function (e) {
    this.setData({
      text: e.detail.value
    })
  },

  // 获取容器高度，使页面滚动到容器底部  
  pageScrollToBottom: function () {
    wx.createSelectorQuery().select('#j_page').boundingClientRect(function (rect) {
      // 使页面滚动到底部  
      wx.pageScrollTo({
        scrollTop: rect.bottom
      })
    }).exec()
  },  

  //发送
  addDialogueRecord:function(){
    if (this.data.text.trim() === '') {
      wx.showToast({
        title: '输入内容不能为空',
        mask: true,
        icon: "none",
        duration: 1000
      });
      return;
    }

    //发送前刷新一次
    this.dialogueRecordData();
    http.request({
      url: '/sns/member/dialogue/record/mobile/v1/save',
      data: {
        initiateMemberId: this.data.initiateMemberId,
        initiateUserId: this.data.initiateUserId,
        respondMemberId: this.data.respondMemberId,
        respondUserId: this.data.respondUserId,
        memberDialogueContent: this.data.text
      },
      success: function (data) {
        //刷新
        this.dialogueRecordData();
        //初始输入框
        this.setData({
          text:''
        });
        // 使页面滚动到底部  
        wx.pageScrollTo({
          scrollTop: 1000000
        });
      }.bind(this)
    });
  },

  onPullDownRefresh: function () {
    // Do something when pull down.
    console.log('刷新');
    var pageIndex = this.data.pageIndex;
    var pageSize = this.data.pageSize;

    pageSize+=5;
    this.setData({
      pageSize: pageSize
    });
    this.dialogueRecordData();
    wx.stopPullDownRefresh()
  },


  //滑动最顶部加载
  onReachBottom: function () {

     
  },



})
