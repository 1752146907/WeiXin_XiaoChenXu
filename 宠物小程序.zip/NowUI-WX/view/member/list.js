const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
    data: {
      activeIndex: 0,
      tagFrontendCategoryList: [],
      tagFrontendCategoryId: '',
      memberList: [],
      pageIndex: 1,
      pageSize: 8,
      memberTotal: 0,
      systemCreateTime: util.formatTime(new Date()),
      imageHost: constant.imageHost
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      this.handleLoadMemberTagFrontendCategoryList();
      this.handleLoadMemberData();
    },
    handleLoadMemberTagFrontendCategoryList: function () {
      http.request({
        url: '/tag/frontend/category/mobile/v1/list',
        data: {
          tagFrontendCategoryCategoryCode: "INDEX_MEMBER"
        },
        success: function (data) {
          this.setData({
            tagFrontendCategoryList: data
          })
        }.bind(this)
      });
    },
    handleSelectCategory: function (e) {
      var index = e.currentTarget.dataset.index;
      var tagFrontendCategoryId = e.currentTarget.dataset.tagFrontendCategoryId;
      if (tagFrontendCategoryId === this.data.tagFrontendCategoryId) {
        return;
      }
      this.setData({
        activeIndex: index,
        pageIndex: 1,
        memberList: [],
        memberTotal: 0,
        tagFrontendCategoryId: tagFrontendCategoryId
      })
      this.handleLoadMemberData();
    },
    handleLoadMemberData: function () {
      http.request({
        url: '/sns/member/mobile/v1/list',
        data: {
          tagFrontendCategoryId: this.data.tagFrontendCategoryId,
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          this.setData({
            memberList: this.data.memberList.concat(data.list),
            memberTotal: data.total
          })
        }.bind(this)
      });
    },
    onReachBottom: function () {
      var pageIndex = this.data.pageIndex;
      var pageSize = this.data.pageSize;
      var total = this.data.memberTotal;

      if ((pageIndex * pageSize) >= total) {
        return;
      }
      pageIndex++;
      this.setData({
        pageIndex: pageIndex
      });
      this.handleLoadMemberData();
    },
    handleFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            url: '/sns/member/follow/mobile/v1/save',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              if (data) {
                var memberList = this.data.memberList;
                var index = event.currentTarget.dataset.index;
                var member = memberList[index];
                member.memberIsFollow = true;
                notification.emit("member-follow-member", {});
                this.setData({
                  memberList: memberList
                });
              }
            }.bind(this)
          });
        }.bind(this)
      })
    },
    handleCancelFollowMember: function (event) {
      wechat.auth({
        checkLogin: true,
        success: function () {
          http.request({
            url: '/sns/member/follow/mobile/v1/delete',
            data: {
              followMemberId: event.currentTarget.dataset.memberId
            },
            success: function (data) {
              if (data) {
                var memberList = this.data.memberList;
                var index = event.currentTarget.dataset.index;
                var member = memberList[index];
                member.memberIsFollow = false;
                notification.emit("member-cancel-follow-member", {});
                this.setData({
                  memberList: memberList
                });
              }
            }.bind(this)
          });
        }.bind(this)
      })
    },
    toOtherHomePage: function (e) {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + e.currentTarget.dataset.memberId,
      })
    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
