const http = require("../../../common/http.js");
const wechat = require("../../../common/wechat.js");
const constant = require("../../../common/constant.js");
const util = require("../../../common/util.js");
const notification = require("../../../common/notification.js");

Page({
  data: {
    petIndexCode:'', //修改所用id
    index:0,  //版本号
    petList: [],
    condition: true,
    imageHost: constant.imageHost,
    mask: false
  },
  handleEdit: function (e) {
    this.setData({
      mask: !this.mask,
      index: e.target.dataset.index,
      petIndexCode: this.data.petList[e.target.dataset.index].petId
    })
  },
  handleHideMask: function (e) {
    this.setData({
      mask: false
    })
  },
  bindViewTap: function () {

  },
  onShow: function () {
    this.getPetByUserIdData();
  },
  onLoad: function () {
    
  },
  //获取当前用户宠物列表
  getPetByUserIdData: function () {
    http.request({
      url: '/pet/mobile/v1/list/by/user/id',
      data: {},
      success: function (data) {
        console.log(data);
        if (data && data.length > 0) {
          this.setData({
            petList: data
          })
        } else {
          //提示还未添加宠物
          this.setData({
            condition: false
          });
        }
      }.bind(this)
    });
  },
  //删除方法
  deletePetChange: function (e) {
    //获取下标
    var petIndex = this.data.index;
    //获取宠物
    var petList = this.data.petList;
    var pet = petList[petIndex];
  
    http.request({
      url: '/pet/mobile/v1/delete',
      data: {
        petId: pet.petId,
        systemVersion: pet.systemVersion
      },
      success: function (data) {
        if (data) {
          wx.showToast({
            title: '删除成功',
            mask: true,
            icon: "none",
            duration: 1000
          });
          //关闭弹出框
          this.setData({
            mask:false
          });
          petList.splice(petIndex, 1);
          this.setData({
            petList: petList,
            condition: petList.length > 0
          })
        } 
      }.bind(this)
    });
  },

  //刷新
  onPullDownRefresh: function () {
    
    this.onLoad();
    wx.stopPullDownRefresh();
  },


})
