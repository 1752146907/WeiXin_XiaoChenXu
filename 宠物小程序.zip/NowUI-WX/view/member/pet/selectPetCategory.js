const http = require("../../../common/http.js");
const wechat = require("../../../common/wechat.js");
const constant = require("../../../common/constant.js");
const util = require("../../../common/util.js");
const notification = require("../../../common/notification.js");

Page({
  data: {
    petCategoryCategoryCode:'', //接收父级页面code
    index:0,
    petCategoryList:[],
    inputShowed: false,
    inputVal: "",
    selectList: [
      {
        id: '',
        name: ''
      }
    ]
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  //取消搜索
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    this.getPetCategoryData();
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });

    this.getPetCategoryData();
  },
  //搜索方法
  inputTyping: function (e) {
    
    this.setData({
      inputVal: e.detail.value
    });
    this.getPetCategoryData();
  }, 
  onLoad: function (options) {
    this.getPetCategoryData();
    
    //得到父页面穿过来的code
    if (options.petCategoryCategoryCode) {
      this.setData({
        petCategoryCategoryCode: options.petCategoryCategoryCode
      });
    }
  },

//获取宠物分类列表
    getPetCategoryData: function () {

    http.request({
      url: '/pet/category/mobile/v1/findByPetCategoryName',
      data: {
        petCategoryName: this.data.inputVal
      },
      success: function (data) {
        if (data) {
          this.setData({
            petCategoryList: data
          });
        }
      }.bind(this)
    });

  },
   
  //选中列表 
  deletePetCategoryTap: function(e){
    var index = e.target.dataset.index;
    //类型id
    var petCategoryId = this.data.petCategoryList[index].petCategoryId;
    //类型名称
    var petCategoryName = this.data.petCategoryList[index].petCategoryName;

    
    //塞入要传递的参数
    notification.emit(this.data.petCategoryCategoryCode, {
      petCategoryId: petCategoryId,
      petCategoryName: petCategoryName
    });
    //回退父页面
    wx.navigateBack();
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
});