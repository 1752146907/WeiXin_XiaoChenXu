const upload = require("../../../common/upload.js");
const constant = require("../../../common/constant.js");
const http = require("../../../common/http.js");
const wechat = require("../../../common/wechat.js");
const notification = require("../../../common/notification.js");

Page({
  data: {
    petCategoryCategoryCode:'ADD_PET_VALUE', //声明跨页面取值标识
    forumGalleryList: [],          //图片存放
    imageHost: constant.imageHost, //图片地址
    petCategoryId:'',//宠物分类编号
    petCategoryName:'',//宠物分类名称
    selectpetCategoryName:'请选择您的宠物品种',//选中分类name
    petName:'', //宠物名称
    petSex:1,  //性别
    petBirthday:'', //生日
    petIsOpen:1, //是否可看
    gender: [
      { name: '0', value: '公' },
      { name: '1', value: '母', checked: 'true' }
    ],
    jurisdiction: [
      { name: '0', value: '公开' },
      { name: '1', value: '仅自己', checked: 'true' }
    ],
    date: '请选择您的宠物生日',
  }, 
  //日期
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value,
      petBirthday: e.detail.value
    })
    // this.data.petBirthday = e.detail.value;
    console.log("日期---"+this.data.petBirthday);
  },
  bindViewTap: function () {

  },
  onLoad: function () {
    //回调
    notification.on(this.data.petCategoryCategoryCode, this, function (data) {
      
      if (data) {
        console.log(data.petCategoryName+"选中分类：---"+data.petCategoryId);
        this.setData({
          petCategoryId: data.petCategoryId,
          petCategoryName: data.petCategoryName,
          selectpetCategoryName: data.petCategoryName
        })
      }
      
    });
    
  },
  //获取sex单选框选中
  sexChange: function (e) {

    this.setData({
      petSex: e.detail.value
    })
    // this.data.petSex = e.detail.value;
    console.log("sex----" + this.data.petSex);
  },
  //是否公开
  isOpenChange:function(e){
    this.setData({
      petIsOpen:e.detail.value
    })
    // this.data.petIsOpen = e.detail.value;
    console.log("是否公开---" + this.data.petIsOpen);
  },
  
  petNameInput: function (e) {
    //数据绑定绑定
    this.setData({
      petName: e.detail.value
    });
  },
  
  //上传图片
  uploadImage: function (event) {
    let forumGalleryList = this.data.forumGalleryList;
    // if (forumGalleryList.length >= 1) {
    //   wx.showToast({
    //     title: '最多上传可以上传1张图片',
    //     mask: true,
    //     duration: 2000
    //   });
    //   return;
    // }

    console.log('上传头像');
    //上传头像
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'],      // 可以指定来源是相册还是相机，默认二者都有
      
      success: function (res) {

        upload.uploadImage(res, function (result) {
          console.log(result.imageList);
          forumGalleryList = result.imageList;
          //数据绑定
          this.setData({
            forumGalleryList: forumGalleryList
          });

        }.bind(this));

      }.bind(this)
    })
  },

//添加宠物 提交
  fromSubmit: function (e) {
   console.log('点击');

   if (this.data.forumGalleryList.length<=0) {
     wx.showToast({
       title: '宠物头像不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
   }

  //验证
   if (this.data.petName.trim() === '') {
     wx.showToast({
       title: '宠物名称不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
   }
  
   if (this.data.petCategoryId == ''){
     wx.showToast({
       title: '宠物品种不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
  }

   if (this.data.petBirthday == ''){
     wx.showToast({
       title: '宠物日期不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
  }

  

   console.info(this.data.petName + "-缓存-" + this.data.petSex +"---"+ this.data.petBirthday +"---"+ this.data.petIsOpen);
   http.request({
     url: '/pet/mobile/v1/save',
     data: {
       petName: this.data.petName, //宠物名称
       petSex: this.data.petSex,   //性别
       petBirthday: this.data.petBirthday, //生日
       petIsOpen: this.data.petIsOpen, //是否可看
       petDescription: '',             //宠物简介
       petCategoryId: this.data.petCategoryId,               //宠物分类编号
       petCategoryName: this.data.petCategoryName,           //宠物分类名称
       petAvatarId: this.data.forumGalleryList[0].fileId,    //宠物头像编号
       petAvatarPath: this.data.forumGalleryList[0].filePath //宠物头像路径
     },
     success: function (data) {
       //初始化
      this.setData({
         forumName: '',
         forumGalleryList: []
      })

      //成功提示框
      wx.showToast({
         title: '提交成功',
         mask: true,
         icon: "none",
         duration: 500,
         success: function () {
           
          setTimeout(function () {
             //关闭所有页面 跳转到指定
             wx.navigateTo({
               url: '/view/member/pet/pet'
             });
          }, 500) //延迟时间

         }
      })


       // wx.showToast({
        //   title: '分享不能为空',
        //   mask: true,
        //   icon: "none",
        //   duration: 1000
        // });
        // return;

     }.bind(this)
   });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }

})
