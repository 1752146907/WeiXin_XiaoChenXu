const upload = require("../../../common/upload.js");
const constant = require("../../../common/constant.js");
const http = require("../../../common/http.js");
const wechat = require("../../../common/wechat.js");
const notification = require("../../../common/notification.js");

Page({
  data: {
    petList:[],
    petIndexCode:'', //接收宠物id
    petCategoryCategoryCode:'UPDATE_PET_VALUE',
    petGalleryList: [],          //上传图片存放
    imageHost: constant.imageHost, //图片地址
    imageUrl: '',                   //完整图片地址
    fileId:'',                     //上传图片Id
    petAvatarPath:'',              //头像路径
    petCategoryId:'',//宠物分类编号
    petCategoryName:'',//宠物分类名称
    selectpetCategoryName:'请选择您的宠物品种',//选中分类name
    petName:'', //宠物名称
    petSex:false,  //性别
    petBirthday:'', //生日
    petIsOpen:false, //是否可看
    systemVersion:'',
    date: '请选择您的宠物生日',
    isFromHomePage: false,
  }, 
  //日期
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value,
      petBirthday: e.detail.value
    })
  },
  bindViewTap: function () {

  },
  onLoad: function (options) {
    if (options.petIndexCode) {
      this.setData({
        isFromHomePage: options.isFromHomePage ? true : false,
        petIndexCode: options.petIndexCode
      });
    }
    this.getPetByPetIdData();
    //分类回调
    notification.on(this.data.petCategoryCategoryCode, this, function (data) {
      if (data) {
        this.setData({
          petCategoryId: data.petCategoryId,     //宠物分类id
          petCategoryName: data.petCategoryName, //宠物名称
          selectpetCategoryName: data.petCategoryName //页面显示
        })
      }
    });
  },
  //获取单挑宠物
  getPetByPetIdData: function () {
    http.request({
      url: '/pet/mobile/v1/find',
      data: {
        petId: this.data.petIndexCode
      },
      success: function (data) {
        if (data) {
          this.setData({
            fileId: data.petAvatarId,                      //头像Id
            petAvatarPath: data.petAvatarPath,             //头像路径          
            imageUrl: this.data.imageHost+""+data.petAvatarPath, //完整图片路径
            petName: data.petName,                               //昵称
            petSex: data.petSex,                                 //性别
            date: data.petBirthday,                              //生日前端(供显示)
            petBirthday: data.petBirthday,                       //生日
            petIsOpen: data.petIsOpen,                           //可查范围
            petCategoryId: data.petCategoryId,                   //分类编号
            petCategoryName: data.petCategoryName,                 //分类名称
            selectpetCategoryName: data.petCategoryName,         //宠物分类(供显示)
            systemVersion: data.systemVersion                    //版本号
          })
        }
      }.bind(this)
    });
  },
  //获取sex单选框选中
  sexChange: function (e) {
    this.setData({
      petSex: e.currentTarget.dataset.sex
    });
  },
  //是否公开
  isOpenChange:function(e){
    this.setData({
      petIsOpen: e.currentTarget.dataset.open
    });
  },
  petNameInput: function (e) {
    //数据绑定绑定
    this.setData({
      petName: e.detail.value
    });
  },
  //上传图片
  uploadImage: function (event) {
    let petGalleryList = this.data.petGalleryList;
    //上传头像
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'],      // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        upload.uploadImage(res, function (result) {
          petGalleryList = result.imageList;
          var imageUrl = this.data.imageHost + "" + result.imageList[0].filePath;
          this.setData({
            petGalleryList: petGalleryList,
            imageUrl: imageUrl,
            fileId: result.imageList[0].fileId,
            petAvatarPath: result.imageList[0].filePath      //头像路径    
          });

        }.bind(this));

      }.bind(this)
    })
  },
  //修改宠物 提交
  fromSubmit: function (e) {

    if (this.data.petAvatarId === '') {
      wx.showToast({
        title: '宠物头像不能为空',
        mask: true,
        icon: "none",
        duration: 1000
      });
      return;
    }
   if (this.data.petName.trim() === '') {
     wx.showToast({
       title: '宠物名称不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
   }
  
   if (this.data.petCategoryId == '') {
     wx.showToast({
       title: '宠物品种不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
   }

   if (this.data.petBirthday == '') {
     wx.showToast({
       title: '宠物日期不能为空',
       mask: true,
       icon: "none",
       duration: 1000
     });
     return;
   }



   var petSex = 0;
   var petIsOpen = 0;

   if (this.data.petSex == false) {
     petSex = 0;
   } else {
     petSex = 1;
   }
   if (this.data.petIsOpen == false) {
     petIsOpen = 0;
   } else {
     petIsOpen = 1;
   } 
   http.request({
     url: '/pet/mobile/v1/update',
     data: {
       petId: this.data.petIndexCode, //宠物编号
       petName: this.data.petName, //宠物名称
       petSex: petSex,   //性别
       petBirthday: this.data.petBirthday, //生日
       petIsOpen: petIsOpen, //是否可看
       petCategoryId: this.data.petCategoryId,               //宠物分类编号
       petCategoryName: this.data.petCategoryName,           //宠物分类名称
       petAvatarId: this.data.fileId,    //宠物头像编号
       petAvatarPath: this.data.petAvatarPath, //宠物头像路径
       systemVersion: this.data.systemVersion //版本号
     },
     success: function (data) {
        //初始化
        this.setData({
          petGalleryList: []
        });
        
        wx.navigateTo({
          url: this.data.isFromHomePage ? '/view/member/homePage' : '/view/member/pet/pet'
        });

      }.bind(this)
   });
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }

})
