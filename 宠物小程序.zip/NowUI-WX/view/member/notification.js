Page({
    data: {
      
    },
    bindViewTap: function () {

    },
    onLoad: function () {

    },
    //刷新
    onPullDownRefresh: function () {
      this.onLoad();
      wx.stopPullDownRefresh();
    }
})
