const upload = require("../../common/upload.js");
const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    member: storage.getMember(), //当前登陆的会员信息
    memberList: [],
    imageHost: constant.imageHost,
    pageIndex: 1,
    pageSize: 10,
    total: 0,
    memberId: ''
  },
  bindViewTap: function () {

  },
  onLoad: function (options) {
    if (options.memberId) {
      this.setData({
        memberId: options.memberId
      });
      this.getMemberFollowList();
      notification.on("member-member-follow", this, function (data) {
        var memberList = this.data.memberList;
        for (var i = 0; i < this.data.memberList.length; i++) {
          if (data.memberId === this.data.memberList[i].followMemberId) {
            var member = memberList[i];
            member.memberIsFollow = true;
            member.memberBeFollowedCount = member.memberBeFollowedCount ? member.memberBeFollowedCount + 1 : 1;
            memberList[i] = member;
          }
        }
        this.setData({
          memberList: memberList
        });
      });
      notification.on("member-cancel-member-follow", this, function (data) {
        var memberList = this.data.memberList;
        for (var i = 0; i < this.data.memberList.length; i++) {
          if (data.memberId === this.data.memberList[i].followMemberId) {
            var member = memberList[i];
            member.memberIsFollow = false;
            member.memberBeFollowedCount = member.memberBeFollowedCount && member.memberBeFollowedCount > 0 ? member.memberBeFollowedCount - 1 : 0;
            memberList[i] = member;
          }
        }
        this.setData({
          memberList: memberList
        });
      });
    } 
  },
  handleFollow: function (e) {
    http.request({
      isToast: true,
      url: '/sns/member/follow/mobile/v1/save',
      data: {
        followMemberId: e.currentTarget.dataset.memberId,
      },
      success: function (data) {
        wx.showToast({
          title: '关注成功',
          icon: 'none',
          duration: 1500
        });
        notification.emit("member-member-follow", { memberId: e.currentTarget.dataset.memberId })
      }.bind(this)
    });
  },
  // 取消关注
  handleCancelFollow: function (e) {
    http.request({
      isToast: true,
      url: '/sns/member/follow/mobile/v1/delete',
      data: {
        followMemberId: e.currentTarget.dataset.memberId,
      },
      success: function (data) {
        wx.showToast({
          title: '取消关注成功',
          icon: 'none',
          duration: 1500
        });
        notification.emit("member-cancel-member-follow", { memberId: e.currentTarget.dataset.memberId })
      }.bind(this)
    })
  },
  getMemberFollowList: function () {
    http.request({
      url: '/sns/member/follow/mobile/v1/list',
      data: {
        memberId: this.data.memberId,
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize
      },
      success: function (data) {
        var memberList = this.data.memberList;
        if (data.list.length > 0) {
          memberList = memberList.concat(data.list);
        }
        this.setData({
          memberList: memberList
        })
      }.bind(this)
    });
  },
  handleToHomePage: function (e) {
    var memberId = e.target.dataset.memberId;
    var member = storage.getMember();
    if (memberId === member.memberId) {
      wx.navigateTo({
        url: '/view/member/homePage'
      });
    } else {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + memberId
      });
    }
  },
  onReachBottom: function () {
    var pageIndex = this.data.pageIndex;
    var pageSize = this.data.pageSize;
    var total = this.data.total;
    if (pageIndex * pageSize >= total) {
      return;
    }
    pageIndex++;
    this.setData({
      pageIndex: pageIndex
    });
    if (this.data.memberId) {
      this.getMemberFollowList();
    } 
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
