const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
Page({
	data: {
    isShow:false,
    windowWidth: getApp().globalData.windowWidth,
    windowHeight: getApp().globalData.windowHeight,
    tagFrontendCategoryList: [],
    activeIndex: 0,
    tagFrontendCategoryId: '',
		imageHost: constant.imageHost,
		topicBannerList: [],
    topicList: [],
		topicPageIndex: 1,
		topicPageSize: 10,
		topicTotal: 0,
    isSearchNone: false
	},
	bindViewTap: function () {

	},
	onLoad: function (options) {
    if (options.tagFrontendCategoryCodeText){
      console.log('有' + options.tagFrontendCategoryCodeText);
        this.setData({
          tagFrontendCategoryId: options.tagFrontendCategoryCodeText,
          isShow:true
        })
    }

		this.getTopicTagFrontendCategoryData();
    this.getTopicData();
	},
  getTopicTagFrontendCategoryData: function () {
    http.request({
      url: '/tag/frontend/category/mobile/v1/list',
      data: {
        tagFrontendCategoryCategoryCode: "INDEX_TOPIC"
      },
      success: function (data) {
      var list = [];
        
      for(var i = 0; i < data.length;i++){
        if (data[i].tagFrontendCategoryName == '健康' || data[i].tagFrontendCategoryName == '护理' || data[i].tagFrontendCategoryName == '出行' || data[i].tagFrontendCategoryName == '饮食' || data[i].tagFrontendCategoryName == '家居时尚' || data[i].tagFrontendCategoryName == '训练' || data[i].tagFrontendCategoryName == '领养救助' || data[i].tagFrontendCategoryName == '其它') {
          list.push(data[i]);
        }
      }



        this.setData({
          tagFrontendCategoryList: list
        })
      }.bind(this)
    });
  },
  selectCategory: function (e) {
    var index = e.currentTarget.dataset.index;
    var tagFrontendCategoryId = e.currentTarget.dataset.tagFrontendCategoryId;
    if (tagFrontendCategoryId === this.data.tagFrontendCategoryId) {
      return;
    }
    this.setData({
      activeIndex: index,
      topicPageIndex: 1,
      topicBannerList: [],
      topicList: [],
      tagFrontendCategoryId: tagFrontendCategoryId
    });
    this.getTopicData();
  },
	getTopicData: function () {
    // var testId =  this.data.tagFrontendCategoryId;
    // if (testId == '637ce371cc214afc8cf4531d8af5bde5'){


    // }
		http.request({
      url: '/topic/mobile/v1/long/text/topic/list',
			data: {
        tagFrontendCategoryId: this.data.tagFrontendCategoryId,
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
			},
			success: function (data) {
        console.log(data);
        var topicBannerList = this.data.topicBannerList;
        var topicList = this.data.topicList;
        var isSearchNone = false;
        if (data.list.length > 0) {
          if (this.data.topicPageIndex === 1) {
            if (data.list.length <= 6) {
              topicBannerList = data.list;
            } else {
              topicBannerList = data.list.slice(0, 5);
              topicList = data.list.slice(6);
            }
          } else {
            topicList = topicList.concat(data.list)
          }
        } else {
          isSearchNone = (this.data.topicPageIndex === 1);
        }

        for (var t = 0; t < data.list.length; t++) {  
          data.list[t].systemCreateTime = util.timeToDateStr(data.list[t].systemCreateTime);
        }
        
        this.setData({
          topicBannerList: topicBannerList,
          topicList: topicList,
          topicTotal: data.total,
          isSearchNone: isSearchNone,
        });
			}.bind(this)
		});
	},
  onReachBottom: function (e) {
    var pageIndex = this.data.topicPageIndex;
    var pageSize = this.data.topicPageSize;
    var total = this.data.topicTotal;

    if ((pageIndex * pageSize) > total) {
      return;
    }

    pageIndex++;
    this.setData({
      topicPageIndex: pageIndex
    });
    this.getTopicData();
  },
  //刷新
  onPullDownRefresh: function () {
    this.setData({
      tagFrontendCategoryList: [],
      activeIndex: 0,
      tagFrontendCategoryId: '',
      imageHost: constant.imageHost,
      topicBannerList: [],
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 10,
      topicTotal: 0
    });
    this.getTopicTagFrontendCategoryData();
    this.getTopicData();
    wx.stopPullDownRefresh();
  }
})
