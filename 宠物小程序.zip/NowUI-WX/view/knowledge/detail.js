const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
const WxParse = require('../../wxParse/wxParse.js');

Page({
	data: {
		windowWidth: getApp().globalData.windowWidth,
		windowHeight: getApp().globalData.windowHeight,
		imageHost: constant.imageHost,
		topic: {},
		topicId: '',
		topicCreateTime: '',
		topicCommentList: [],
		topicCommentPageIndex: 1,
		topicCommentPageSize: 3,
		topicCommentTotal: 0,
    topicImagePath: '',
    topicMemberCommentContent: "",
		member: storage.getMember(),
    handleComment: false,
    commentBottom: false
	},
	bindViewTap: function () {

	},
	onLoad: function (options) {
		var topicId = options.topicId;
		if (topicId && topicId !== '') {
			this.setData({
				topicId: topicId
			})
			this.getTopicData();
			this.getCommentData();
      notification.on("member-add-topic", this, function (data) {
        if (data.shareTopicId && data.shareTopicId === this.data.topicId) {
          this.setData({
            topic: {},
            topicCreateTime: '',
            topicCommentList: [],
            topicCommentPageIndex: 1,
            topicCommentPageSize: 3,
            topicCommentTotal: 0,
          });
          this.getTopicData();
          this.getCommentData();
        }
      });
      notification.on("member-follow-member", this, function(data) {
        var topic = this.data.topic;
        if (data.memberId === topic.memberId) {
          topic.memberIsFollow = true;
          this.setData({
            topic: topic
          });
        }
      });
      notification.on("member-cancel-follow-member", this, function (data) {
        var topic = this.data.topic;
        if (data.memberId === topic.memberId) {
          topic.memberIsFollow = false;
          this.setData({
            topic: topic
          });
        }
      });
      notification.on("member-like-topic", this, function (data) {
        var topic = this.data.topic;
        if (data.topicId === topic.topicId) {
          topic.memberIsLike = true;
          topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1; 
          this.setData({
            topic: topic
          });
        }
      });
      notification.on("member-cancel-like-topic", this, function (data) {
        var topic = this.data.topic;
        if (data.topicId === topic.topicId) {
          topic.memberIsLike = false;
          topic.topicLikeCount = topic.topicLikeCount && topic.topicLikeCount > 0 ? topic.topicLikeCount - 1 : 0;
        }
        this.setData({
          topic: topic
        });
      });
      notification.on("member-comment-topic", this, function (data) {
        if (data.topicId === this.data.topicId) {
          var topic = this.data.topic;
          topic.topicCommentCount = topic.topicCommentCount && topic.topicCommentCount > 0 ? topic.topicCommentCount + 1 : 1;
          this.setData({
            topicMemberCommentContent: "",
            topicCommentList: [],
            topicCommentPageIndex: 1,
            topicCommentPageSize: 3,
            topicCommentTotal: 0,
            topic: topic
          });
          this.getCommentData();
        }
      });
		}
	},
	getTopicData: function () {
		http.request({
			url: '/topic/mobile/v1/find',
			data: {
				topicId: this.data.topicId
			},
			success: function (data) {
				var topicContent = data.topicContent;
				WxParse.wxParse('topicContent', 'html', topicContent, this, 5);
        var topicImagePath = data.topicGalleryList.length > 0 ? data.topicGalleryList[0].topicImagePath : '';
        data.topicGalleryList = data.topicGalleryList.slice(1);
				this.setData({
          topicImagePath: topicImagePath,
					topicCreateTime: util.timeToDateStr(data.systemCreateTime),
					topic: data
				})
			}.bind(this)
		});
	},
	getCommentData: function () {
		http.request({
			url: '/topic/member/comment/mobile/v1/list',
			data: {
				topicId: this.data.topicId,
				pageIndex: this.data.topicCommentPageIndex,
				pageSize: this.data.topicCommentPageSize,
			},
			success: function (data) {
				var topicCommentList = data.list;
				if (data.list.length > 0) {
					for (var i = 0; i < data.list.length; i++) {
						var comment = data.list[i];
						comment.systemCreateTime = util.timeToDateStr(comment.systemCreateTime);
						topicCommentList[i] = comment;
					}
				}
				this.setData({
					topicCommentList: topicCommentList,
					topicCommentTotal: data.total
				})
			}.bind(this)
		});
	},
	expandReplyComment: function (e) {
		var index = e.currentTarget.dataset.index;
		var topicCommentList = this.data.topicCommentList;
		var topicComment = topicCommentList[index];
		topicComment.isExpand = topicComment.isExpand ? false : true;
		topicCommentList[index] = topicComment;
		this.setData({
			topicCommentList: topicCommentList
		})
	},
	handleFollowMember: function () {
		http.request({
      isToast: true,
			url: '/sns/member/follow/mobile/v1/save',
			data: {
				followMemberId: this.data.topic.memberId
			},
			success: function (data) {
        notification.emit("member-follow-member", { memberId: this.data.topic.memberId});
			}.bind(this)
		});
	},
  handleCancelFollowMember: function () {
    http.request({
      isToast: true,
      url: '/sns/member/follow/mobile/v1/delete',
      data: {
        followMemberId: this.data.topic.memberId
      },
      success: function (data) {
        notification.emit("member-cancel-follow-member", { memberId: this.data.topic.memberId });
      }.bind(this)
    });
  },
	handleLike: function () {
		http.request({
      isToast: true,
			url: '/topic/member/like/mobile/v1/save',
			data: {
				topicId: this.data.topicId
			},
			success: function (data) {
        notification.emit("member-like-topic", { topicId: this.data.topicId });
			}.bind(this)
		});
	},
  handleCancelLike: function () {
    http.request({
      isToast: true,
      url: '/topic/member/like/mobile/v1/delete',
      data: {
        topicId: this.data.topicId
      },
      success: function (data) {
        notification.emit("member-cancel-like-topic", { topicId: this.data.topicId });
      }.bind(this)
    });
  },
	handleBookmark: function () {
		http.request({
      isToast: true,
			url: '/topic/member/bookmark/mobile/v1/save',
			data: {
				topicId: this.data.topicId
			},
			success: function (data) {
				var topic = this.data.topic;
				topic.topicBookmarkCount = topic.topicBookmarkCount ? topic.topicBookmarkCount + 1 : 1;
        topic.memberIsBookmark = true;
				this.setData({
					topic: topic
				});
			}.bind(this)
		});
	},
  handleCancelBookmark: function () {
    http.request({
      isToast: true,
      url: '/topic/member/bookmark/mobile/v1/delete',
      data: {
        topicId: this.data.topicId
      },
      success: function (data) {
        var topic = this.data.topic;
        topic.topicBookmarkCount = topic.topicBookmarkCount && topic.topicBookmarkCount > 0? topic.topicBookmarkCount - 1 : 0;
        topic.memberIsBookmark = false;
        this.setData({
          topic: topic
        })
      }.bind(this)
    });
  },
	handleCommentLike: function (e) {
		var commentIndex = e.currentTarget.dataset.commentIndex;
		var commentId = e.currentTarget.dataset.commentId;

		http.request({
      isToast: true,
			url: '/topic/member/comment/like/mobile/v1/save',
			data: {
				commentId: commentId
			},
			success: function (data) {
				var topicCommentList = this.data.topicCommentList;
				var comment = topicCommentList[commentIndex];
				comment.topicMemberCommentLikeCount = (comment.topicMemberCommentLikeCount ? comment.topicMemberCommentLikeCount + 1 : 1);
        comment.memberIsLike = true;
				this.setData({
					topicCommentList: topicCommentList
				})
			}.bind(this)
		});

	},
  handleCancelCommentLike: function (e) {
    var commentIndex = e.currentTarget.dataset.commentIndex;
    var commentId = e.currentTarget.dataset.commentId;

    http.request({
      isToast: true,
      url: '/topic/member/comment/like/mobile/v1/delete',
      data: {
        commentId: commentId
      },
      success: function (data) {
        var topicCommentList = this.data.topicCommentList;
        var comment = topicCommentList[commentIndex];
        comment.topicMemberCommentLikeCount = comment.topicMemberCommentLikeCount - 1;
        comment.memberIsLike = false;
        this.setData({
          comment: comment,
          topicCommentList: topicCommentList
        });
      }.bind(this)
    });
  },
	openLocation: function () {
		if (this.data.topic.latitude && this.data.topic.longtitude) {
			wx.openLocation({
				latitude: parseFloat(this.data.topic.latitude),
				longitude: parseFloat(this.data.topic.longtitude)
			})
		}
	},
	toTopicDetail: function () {
    var topic = this.data.topic;
    if (topic.shareTopic && topic.shareTopic.topicId) {
      wx.navigateTo({
        url: topic.shareTopic.topicType === "SHORT_TEXT" ? '/view/topic/detail?topicId=' + topic.shareTopic.topicId : '/view/knowledge/detail?topicId=' + topic.shareTopic.topicId,
      })
    }
	},
  handleBlur: function () {
    this.setData({
      commentBottom: false
    });
  },
  handleComment: function () {
    this.setData({
      handleComment: !this.data.handleComment
    });
    if (this.data.topicCommentList.length < 2) {
      this.setData({
        commentBottom: true
      });
    } else {
      this.setData({
        commentBottom: false
      });
    }
  },
  toHomePage: function(e) {
    var memberId = e.currentTarget.dataset.memberId;
    if (memberId === this.data.member.memberId) {
      wx.navigateTo({
        url: '/view/member/homePage',
      });
    } else {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + memberId,
      });
    }
  },
	toTopicComment: function () {
		var topic = this.data.topic;
		if (topic.topicId) {
			wx.navigateTo({
				url: '/view/topic/comment?topicId=' + topic.topicId,
			})
		}
	},
	toShareTopic: function () {
		var topic = this.data.topic;
		if (topic.topicId) {
			wx.navigateTo({
				url: '/view/topic/add?topicId=' + topic.topicId + '&topicTitle=' + topic.topicTitle + '&topicImagePath=' + this.data.topicImagePath
			})
		}
	},
  handleSubmit: function (e) {
    if (this.data.topicMemberCommentContent === '') {
      wx.showToast({
        title: '评论不能为空',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    http.request({
      isToast: true,
      url: '/topic/member/comment/mobile/v1/save',
      data: {
        topicId: this.data.topicId,
        replyCommentId: "",
        replyMemberId: "",
        topicMemberCommentContent: this.data.topicMemberCommentContent,
      },
      success: function (data) {
        notification.emit("member-comment-topic", {topicId: this.data.topicId});
      }.bind(this)
    });
  },
  handleFocus: function (e) {
    wx.pageScrollTo({
      scrollTop: e.target.offsetTop,
    });
    this.setData({
      commentBottom: true
    });
  },
  inputComment: function (e) {
    this.setData({
      topicMemberCommentContent: e.detail.value
    })
  },
  //头像进入
  commentImageTap: function (e) {
    var memberId = e.target.dataset.memberId;
    memberId
    console.log('进入头像' + memberId);
    wx.navigateTo({
      url: '/view/member/otherHomePage?memberId=' + memberId
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.setData({
      topic: {},
      topicCreateTime: '',
      topicCommentList: [],
      topicCommentPageIndex: 1,
      topicCommentPageSize: 3,
      topicCommentTotal: 0,
    }); 
    this.getTopicData();
    this.getCommentData();
    wx.stopPullDownRefresh();
  }
})
