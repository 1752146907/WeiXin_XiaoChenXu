const upload = require("../../common/upload.js");
const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    evaluationImagePath: '/image/0.png',
    cloneImagePath: '/image/clone.jpg',
    deleteImagePath: '/image/delete.jpg',
    topicTitle: '',
    topicGalleryList: [],
    topicTagMapList: [],
    shareTopic: {},
    shareMerchant: {},
    location: {},
    forumList: [],
    topicIsPrivate: false,
    isSubmitActive: false,
    tagFrontendCategoryCategoryCode: "INDEX_TOPIC",
    isFromForum: false,
    imageHost: constant.imageHost
  },
  bindViewTap: function () {

  },
  bindTitleInput: function (e) {
    var topicTitle = e.detail.value;
    var isSubmitActive = false;
    if (topicTitle.trim() !== '') {
      isSubmitActive = true;
    }
    this.setData({
      topicTitle: topicTitle,
      isSubmitActive: isSubmitActive
    });
  },
  onLoad: function (options) {
    notification.on(this.data.tagFrontendCategoryCategoryCode, this, function (data) {
      if (data) {
        var topicTagMapList = this.data.topicTagMapList;
        var isRepeat = false;
        for (var i = 0; i < topicTagMapList.length; i++) {
          if (topicTagMapList[i].tagId === data.tagId) {
            isRepeat = true;
            break;
          }
        }
        if (!isRepeat) {
          topicTagMapList.push(data);
          this.setData({
            topicTagMapList: topicTagMapList
          })
        }
      }
    });

    if (options.forumId) {
      var forumList = [];
      forumList.push({
        forumId: options.forumId
      });
      this.setData({
        isFromForum: true,
        forumList: forumList
      });
    }

    notification.on("topic-add-select-merchant", this, function (data) {
      this.setData({
        shareMerchant: data
      })
    });

    notification.on("topic-add-select-forum", this, function (data) {
      this.setData({
        forumList: data.forumList
      })
    });
    
    notification.on("topic-add-select-pulic", this, function (data) {
      this.setData({
        topicIsPrivate: data.topicIsPrivate
      })
    });
  },
  toPublic: function() {
    wx.navigateTo({
      url: '/view/topic/public?topicIsPrivate=' + this.data.topicIsPrivate
    })
  },
  toShareMerchant: function () {
    wx.navigateTo({
      url: '/view/topic/shareMerchant'
    })
  },
  addForum: function () {
    wx.navigateTo({
      url: '/view/topic/addForum'
    })
  },
  handleSubmit: function (e) {
    if (this.data.topicTitle.trim() === '') {
      wx.showToast({
        title: '分享不能为空',
        mask: true,
        icon: "none",
        duration: 1000
      });
      return;
    }
    var topicGalleryList = this.data.topicGalleryList.map((topicImage, index) => {
      return {
        topicImageId: topicImage.fileId,
        topicImagePath: topicImage.filePath,
        topicImageSort: index
      }
    });
    var topicTagMapList = this.data.topicTagMapList.map((tag, index) => {
      return {
        tagId: tag.tagId,
        tagName: tag.tagName,
        topicTagSort: index
      }
    });

    var forumIdList = this.data.forumList.map(forum => forum.forumId);

    var latitude = this.data.location.latitude ? this.data.location.latitude : '';
    var longitude = this.data.location.longitude ? this.data.location.longitude : '';
    var topicLocation = this.data.location.topicLocation ? this.data.location.topicLocation : '';

    var shareMerchantId = this.data.shareMerchant.merchantId ? this.data.shareMerchant.merchantId : '';
    var shareTopicId = this.data.shareTopic.topicId ? this.data.shareTopic.topicId : '';

    http.request({
      isToast: true,
      url: '/topic/mobile/v1/save',
      data: {
        topicTitle: this.data.topicTitle,
        topicGalleryListStr: JSON.stringify(topicGalleryList),
        topicTagMapListStr: JSON.stringify(topicTagMapList),
        forumIdListStr: JSON.stringify(forumIdList),
        latitude: latitude,
        longtitude: longitude,
        topicLocation: topicLocation,
        shareMerchantId: shareMerchantId,
        shareTopicId: shareTopicId,
        topicIsPrivate: this.data.topicIsPrivate
      },
      success: function (data) {
        this.setData({
          topicTitle: '',
          topicGalleryList: [],
          topicTagMapList: [],
          shareTopic: {},
          shareMerchant: {},
          location: {},
          forumList: [],
          topicIsPrivate: false,
          isSubmitActive: false,
        })
        notification.emit("member-add-topic", {});
        wx.reLaunch({
          url: '/view/sns/index?tap=topic'
        });
       
      }.bind(this)
    });
  },
  handleRemoveShareTopic: function (e) {
    this.setData({
      shareTopic: {}
    });
  },
  handleRemoveShareMerchant: function (e) {
    this.setData({
      shareMerchant: {}
    });
  },
  handleRemoveTag: function (e) {
    var tagId = e.currentTarget.dataset.tagId;
    var topicTagMapList = this.data.topicTagMapList;
    for (var i = 0; i < this.data.topicTagMapList.length; i++) {
      if (this.data.topicTagMapList[i].tagId === tagId) {
        topicTagMapList.splice(i, 1);
        this.setData({
          topicTagMapList: topicTagMapList
        });
        break;
      }
    }
  },
  handleRemoveLocation: function (e) {
    this.setData({
      location: {}
    });
  },
  cloneImage: function (e) {
    var fileId = e.currentTarget.dataset.fileId;
    var topicGalleryList = this.data.topicGalleryList;
    for (var i = 0; i < topicGalleryList.length; i++) {
      if (topicGalleryList[i].fileId === fileId) {
        topicGalleryList.splice(i, 1);
        this.setData({
          topicGalleryList: topicGalleryList
        });
        break;
      }
    }
  },
  uploadImage: function (event) {
    let topicGalleryList = this.data.topicGalleryList;
    if (topicGalleryList.length >= 9) {
      wx.showToast({
        title: '最多上传9张图片',
        mask: true,
        icon: 'none',
        duration: 2000
      });
      return;
    }
    wx.chooseImage({ 
      count: 9 - topicGalleryList.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        upload.uploadImage(res, function (result) {
          topicGalleryList = topicGalleryList.concat(result.imageList);
          this.setData({
            topicGalleryList: topicGalleryList
          });
        }.bind(this));
      }.bind(this)
    })
  },
  chooseLocation: function () {
    wx.chooseLocation({
      success: function (res) {
        var location = {
          topicLocation: res.name,
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({
          location: location
        })
      }.bind(this),
      fail: function (res) {
        wx.showToast({
          title: '用户未授权地理位置',
          icon: 'none',
          duration: 2000
        })
        return;
      }
    });
  },
  noUnload: function () {
    this.setData({
      topicTagMapList: ''
    })
  },
  toAddTag: function () {
    var topicTagMapList = this.data.topicTagMapList;
    if (topicTagMapList.length >= 8) {
      wx.showToast({
        title: '标签不能超过8个',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    wx.navigateTo({
      url: '/view/tag/add?tagFrontendCategoryCategoryCode=' + this.data.tagFrontendCategoryCategoryCode,
    })
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
})
