Page({
	data: {

	},
	onLoad: function () {

	},
	onReady: function () {

	},
})
