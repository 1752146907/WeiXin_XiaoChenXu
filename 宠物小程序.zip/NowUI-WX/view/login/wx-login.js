const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");

Page({
	data: {
	},
  login: function (userinfo) { 
    console.log(userinfo);
    wechat.login(userinfo, {
      success: function () {
        notification.emit("login-callback", {success: true});
      }.bind(this),
      fail: function () {
        notification.emit("login-callback", { success: false });
      }
    });
    wx.navigateBack({
      
    })
  },
  cancel: function() {
    notification.emit("login-callback", { success: false });
    wx.navigateBack({

    })
  },
	onLoad: function () {

	},
	onReady: function () {

	},
})
