const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
Page({
  data: {
    inputVal: "",
    keyword: "",
    activeIndex: 0,
    topicPageIndex: 1,
    topicPageSize: 8,
    topicList: [],
    topicTotal: 0,
    forumPageIndex: 1,
    forumPageSize: 8,
    forumList: [],
    forumTotal: 0,
    memberPageIndex: 1,
    memberPageSize: 8,
    memberList: [],
    memberTotal: 0,
    merchantPageIndex: 1,
    merchantPageSize: 8,
    merchantList: [],
    merchantTotal: 0, 
    imageHost: constant.imageHost
  },
  handleClickTab: function (e) {
    this.setData({
      activeIndex: e.currentTarget.id
    });
    if (e.currentTarget.id == 0 && this.data.topicList.length === 0) {
      this.handleSearchTopic();
    } else if (e.currentTarget.id == 1 && this.data.forumList.length === 0) {
      this.handleSearchForum();
    } else if (e.currentTarget.id == 2 && this.data.memberList.length === 0) {
      this.handleSearchMember();
    } else if (e.currentTarget.id == 3 && this.data.merchantList.length === 0) {
      this.handleSearchMerchant();
    }
  },
  clearInput: function () {
    this.setData({
      inputVal: "",
      keyword: "",
      activeIndex: 0,
      topicPageIndex: 1,
      topicPageSize: 6,
      topicList: [],
      topicTotal: 0,
      forumPageIndex: 1,
      forumPageSize: 6,
      forumList: [],
      forumTotal: 0,
      memberPageIndex: 1,
      memberPageSize: 6,
      memberList: [],
      memberTotal: 0,
      merchantPageIndex: 1,
      merchantPageSize: 6,
      merchantList: [],
      merchantTotal: 0
    });
  },
  inputKeyword: function (e) {
    var inputVal = e.detail.value;
    if (inputVal.trim() === '') {
      this.clearInput();
    } else {
      this.setData({
        inputVal: e.detail.value
      });
    }
    
  },
  onReachBottom: function () {
    var activeIndex = this.data.activeIndex;
    if (activeIndex === 0) {
      var pageIndex = this.data.topicPageIndex;
      var pageSize = this.data.topicPageSize;
      var total = this.data.topicTotal;
      if ((pageIndex * pageSize) > total) {
        return;
      }
      pageIndex++;
      this.setData({
        topicPageIndex: pageIndex
      });
      this.handleSearchTopic();
    } else if (activeIndex === 1) {
      var pageIndex = this.data.forumPageIndex;
      var pageSize = this.data.forumPageSize;
      var total = this.data.forumTotal;
      if ((pageIndex * pageSize) > total) {
        return;
      }
      pageIndex++;
      this.setData({
        forumPageIndex: pageIndex
      });
      this.handleSearchForum();
    } else if (activeIndex === 2) {
      var pageIndex = this.data.memberPageIndex;
      var pageSize = this.data.memberPageSize;
      var total = this.data.memberTotal;
      if ((pageIndex * pageSize) > total) {
        return;
      }
      pageIndex++;
      this.setData({
        memberPageIndex: pageIndex
      });
      this.handleSearchMember();
    } else if (activeIndex === 3) {
      var pageIndex = this.data.merchantPageIndex;
      var pageSize = this.data.merchantPageSize;
      var total = this.data.merchantTotal;
      if ((pageIndex * pageSize) > total) {
        return;
      }
      pageIndex++;
      this.setData({
        merchantPageIndex: pageIndex
      });
      this.handleSearchMerchant();
    }
  },
  handleSearch: function (e) {
    var keyword = e.detail.value;
    if (keyword.trim() === '') {
      wx.showToast({
        title: '搜索内容不能为空',
        mask: true,
        icon: "none",
        duration: 1000
      });
      return;
    }
    this.setData({
      activeIndex: 0,
      topicPageIndex: 1,
      topicPageSize: 6,
      topicList: [],
      topicTotal: 0,
      forumPageIndex: 1,
      forumPageSize: 6,
      forumList: [],
      forumTotal: 0,
      memberPageIndex: 1,
      memberPageSize: 6,
      memberList: [],
      memberTotal: 0,
      merchantPageIndex: 1,
      merchantPageSize: 6,
      merchantList: [],
      merchantTotal: 0,
      keyword: keyword
    });
    var activeIndex = this.data.activeIndex;
    if (activeIndex === 0) {
      this.handleSearchTopic();
    } else if (activeIndex === 1) {
      this.handleSearchForum();
    } else if (activeIndex === 2) {
      this.handleSearchMember();
    } else if (activeIndex === 3) {
      this.handleSearchMerchant();
    }
  },
  handleSearchTopic: function () {
    http.request({
      url: '/topic/mobile/v1/search/list',
      data: {
        topicTitle: this.data.keyword,
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
      },
      success: function (data) {
        this.setData({
          topicList: this.data.topicList.concat(data.list),
          topicTotal: data.total
        })
      }.bind(this)
    });
  },
  handleSearchForum: function () {
    http.request({
      url: '/forum/mobile/v1/search/list',
      data: {
        forumName: this.data.keyword,
        pageIndex: this.data.forumPageIndex,
        pageSize: this.data.forumPageSize
      },
      success: function (data) {
        this.setData({
          forumList: this.data.forumList.concat(data.list),
          forumTotal: data.total
        })
      }.bind(this)
    });
  },
  handleSearchMember: function () {
    http.request({
      url: '/sns/member/mobile/v1/search/list',
      data: {
        memberNickName: this.data.keyword,
        pageIndex: this.data.memberPageIndex,
        pageSize: this.data.memberPageSize
      },
      success: function (data) {
        this.setData({
          memberList: this.data.memberList.concat(data.list),
          memberTotal: data.total
        })
      }.bind(this)
    });
  },
  handleSearchMerchant: function () {
    http.request({
      url: '/merchant/moblie/v1/search/list',
      data: {
        merchantName: this.data.keyword,
        pageIndex: this.data.merchantPageIndex,
        pageSize: this.data.merchantPageSize
      },
      success: function (data) {
        this.setData({
          merchantList: this.data.merchantList.concat(data.list),
          merchantTotal: data.total
        })
      }.bind(this)
    });
  },
  openLocation: function (e) {
    var index = e.currentTarget.dataset.index;
    var merchant = this.data.merchantList[index];

    if (merchant.merchantLongitude && merchant.merchantLatitude) {
      wx.openLocation({
        latitude: parseFloat(merchant.merchantLatitude),
        longitude: parseFloat(merchant.merchantLongitude),
      })
    }
  },
  handleFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: event.currentTarget.dataset.id
          },
          success: function (data) {
            if (data) {
              var index = event.currentTarget.dataset.index
              var memberList = this.data.memberList;
              var member = memberList[index];
              member.memberIsFollow = true;
              memberList[index] = member;
              this.setData({
                memberList: memberList
              });
              // TODO 提示关注成功
              wx.showToast({
                title: '关注成功',
                icon: 'success',
                duration: 2000
              });
            } else {
              // TODO 提示关注失败
            }
          }.bind(this)
        });
      }.bind(this)
    })
  },
  //刷新
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh();
  }
});