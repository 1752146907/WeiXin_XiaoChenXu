const wechat = require("../../common/wechat.js");
const http = require("../../common/http.js");
const constant = require("../../common/constant.js");
const storage = require("../../common/storage.js");
const util = require("../../common/util.js");
const notification = require("../../common/notification.js");
Page({
	data: {
		windowWidth: getApp().globalData.windowWidth,
		windowHeight: getApp().globalData.windowHeight,
    advertisementCategoryCode: "INDEX_BANNER",
    imageHost: constant.imageHost,
		bannerList: [],
    recommendForumList: [],
    recommendForumTotal: 0,
    recommendForumPageIndex: 1,
    recommendForumPageSize: 6,
    recommendMemberList: [],
    recommendMemberTotal: 0,
    recommendMemberPageIndex: 1,
    recommendMemberPageSize: 6,
    tagFrontendCategoryList: [],
    activeIndex: 0,
    tagFrontendCategoryId: '',
    topicList: [],
    shortTopicTotal: 0,
    shortTopicPageIndex: 1,
    shortTopicPageSize: 6,
    longTopicTotal: 0,
    longTopicPageIndex: 1,
    longTopicPageSize: 3
	},
	onLoad: function () {
    wechat.auth({
      checkLogin: true,
      success: function() {
        
      },
      fail: function() {
        
      }
    });
    notification.on("member-follow-member", this, function (data) {
      var topicList = this.data.topicList;
      for (var i = 0; i < topicList.length; i++) {
        var topic = topicList[i];
        if (topic.memberId === data.memberId) {
          topic.memberIsFollow = true;
          topicList[i] = topic;
        }
      }
      this.setData({
        recommendMemberList: [],
        recommendMemberTotal: 0,
        recommendMemberPageIndex: 1,
        recommendMemberPageSize: 6,
        topicList: topicList
      });
      
      this.getRecommendMemberData();
    });
    notification.on("member-cancel-follow-member", this, function (data) {
      var topicList = this.data.topicList;
      for (var i = 0; i < topicList.length; i++) {
        var topic = topicList[i];
        if (topic.memberId === data.memberId) {
          topic.memberIsFollow = false;
          topicList[i] = topic;
        }
      }
      this.setData({
        topicList: topicList
      });
    });
    notification.on("member-like-topic", this, function (data) {
      var topicList = this.data.topicList;
      if (this.data.topicList.length > 0) {
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = this.data.topicList[i];
            topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
            topic.memberIsLike = true;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        })
      }
    });
    notification.on("member-follow-forum", this, function (data) {
      this.setData({
        recommendForumList: [],
        recommendForumTotal: 0,
        recommendForumPageIndex: 1,
        recommendForumPageSize: 6
      });
      this.getRecommendForumData();
    });
    notification.on("member-cancel-follow-forum", this, function (data) {
      this.setData({
        recommendForumList: [],
        recommendForumTotal: 0,
        recommendForumPageIndex: 1,
        recommendForumPageSize: 6
      });
      this.getRecommendForumData();
    });
    notification.on("member-cancel-like-topic", this, function (data) {
      var topicList = this.data.topicList;
      if (this.data.topicList.length > 0) {
        for (var i = 0; i < this.data.topicList.length; i++) {
          if (data.topicId === this.data.topicList[i].topicId) {
            var topic = this.data.topicList[i];
            topic.topicLikeCount = topic.topicLikeCount > 1 ? topic.topicLikeCount - 1 : 0;
            topic.memberIsLike = false;
            topicList[i] = topic;
          }
        }
        this.setData({
          topicList: topicList
        })
      }
    });
    notification.on("member-add-topic", this, function (data) {
      this.setData({
        topicList: [],
        shortTopicTotal: 0,
        shortTopicPageIndex: 1,
        shortTopicPageSize: 6,
        longTopicTotal: 0,
        longTopicPageIndex: 1,
        longTopicPageSize: 3
      });
      this.getTopicData();
    });
    notification.on("member-delete-topic", this, function (data) {
      this.setData({
        topicList: [],
        shortTopicTotal: 0,
        shortTopicPageIndex: 1,
        shortTopicPageSize: 6,
        longTopicTotal: 0,
        longTopicPageIndex: 1,
        longTopicPageSize: 3
      });
      this.getTopicData();
    });
    this.getIndexBannerData();
    this.getTopicTagFrontendCategoryData();
    this.getRecommendForumData();
    this.getRecommendMemberData();
    this.getTopicData();
	},
	onReady: function () {
    
	},
  getIndexBannerData: function () {
    http.request({
      url: '/advertisement/mobile/v1/list/by/category/code',
      data: {
        advertisementCategoryCode: this.data.advertisementCategoryCode
      },
      success: function (data) {
        console.log(data);
        this.setData({
          bannerList: data
        })
      }.bind(this)
    });
  },
  getTopicTagFrontendCategoryData: function () {
    http.request({
      url: '/tag/frontend/category/mobile/v1/list',
      data: {
        tagFrontendCategoryCategoryCode: "INDEX_TOPIC"
      },
      success: function (data) {
       var testList = [];

        for (var i = 0; i < data.length;i++){
          if (data[i].tagFrontendCategoryName == '健康' || data[i].tagFrontendCategoryName == '护理' || data[i].tagFrontendCategoryName == '出行' || data[i].tagFrontendCategoryName == '饮食' || data[i].tagFrontendCategoryName == '家居时尚' || data[i].tagFrontendCategoryName == '训练' || data[i].tagFrontendCategoryName == '领养救助' || data[i].tagFrontendCategoryName == '其它'){
             testList.push(data[i]);
          }
        }

        this.setData({
          tagFrontendCategoryList: testList
        })
      }.bind(this)
    });
  },
  selectCategory: function (e) {
    var index = e.currentTarget.dataset.index;
    var tagFrontendCategoryId = e.currentTarget.dataset.tagFrontendCategoryId;
    if (tagFrontendCategoryId === this.data.tagFrontendCategoryId) {
      return;
    }
    this.setData({
      activeIndex: index,
      topicList: [],
      shortTopicTotal: 0,
      shortTopicPageIndex: 1,
      shortTopicPageSize: 6,
      longTopicTotal: 0,
      longTopicPageIndex: 1,
      longTopicPageSize: 3,
      tagFrontendCategoryId: tagFrontendCategoryId
    });
    this.getTopicData();
  },
  getRecommendForumData: function (e) {
    http.request({
      url: '/forum/mobile/v1/interest/list',
      data: {
        pageIndex: this.data.recommendForumPageIndex,
        pageSize: this.data.recommendForumPageSize
      },
      success: function (data) {
        var recommendForumList = this.data.recommendForumList;
        if (data.list.length > 0) {
          if (this.data.recommendForumPageIndex === 1) {
            recommendForumList = data.list;
          } else {
            recommendForumList = recommendForumList.concat(data.list)
          }
        }
        this.setData({
          recommendForumList: recommendForumList,
          recommendForumTotal: data.total
        })
      }.bind(this)
    });
  },
  loadMoreRecommendForumMore: function (e) {
    var pageIndex = this.data.recommendForumPageIndex;
    var pageSize = this.data.recommendForumPageSize;
    var total = this.data.recommendForumTotal;
    if ((pageIndex * pageSize) > total) {
      return;
    }
    pageIndex++;
    this.setData({
      recommendForumPageIndex: pageIndex
    });
    this.getRecommendForumData();
  },
  getRecommendMemberData: function (e) {
    http.request({
      url: '/sns/member/mobile/v1/interest/list',
      data: {
        pageIndex: this.data.recommendMemberPageIndex,
        pageSize: this.data.recommendMemberPageSize
      },
      success: function (data) {
        var recommendMemberList = this.data.recommendMemberList;
        if (data.list.length > 0) {
          if (this.data.recommendMemberPageIndex === 1) {
            recommendMemberList = data.list;
          } else {
            recommendMemberList = recommendMemberList.concat(data.list)
          }
        }
        this.setData({
          recommendMemberList: recommendMemberList,
          recommendMemberTotal: data.total
        });
      }.bind(this)
    });
  },
  loadRecommendMemberMore: function (e) {
    var pageIndex = this.data.recommendMemberPageIndex;
    var pageSize = this.data.recommendMemberPageSize;
    var total = this.data.recommendMemberTotal;

    if ((pageIndex * pageSize) > total) {
      return;
    }

    pageIndex++;
    this.setData({
      recommendMemberPageIndex: pageIndex
    });
    this.getRecommendMemberData();
  },
  getTopicData: function (e) {
    var p = new Promise(function (resolve, reject) {
      this.getLongTopicData(resolve);
    }.bind(this));
    p.then(function (data) {
      this.getShortTopicData();
    }.bind(this))
  },
  getLongTopicData: function (resolve) {
    http.request({
      url: '/topic/mobile/v1/recommend/list',
      data: {
        tagFrontendCategoryId: this.data.tagFrontendCategoryId,
        topicType: "LONG_TEXT",
        pageIndex: this.data.longTopicPageIndex,
        pageSize: this.data.longTopicPageSize
      },
      success: function (data) {
        var topicList = this.data.topicList;
        if (data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topic = data.list[i];
            topic.systemCreateTime = util.timeToDateStr(topic.systemCreateTime);
            topicList.push(topic);
          }
        }
        this.setData({
          topicList: topicList,
          longtTopicTotal: data.total
        });
        resolve();
      }.bind(this)
    });
  },
  getShortTopicData: function (e) {
    http.request({
      url: '/topic/mobile/v1/recommend/list',
      data: {
        tagFrontendCategoryId: this.data.tagFrontendCategoryId,
        topicType: "SHORT_TEXT",
        pageIndex: this.data.shortTopicPageIndex,
        pageSize: this.data.shortTopicPageSize
      },
      success: function (data) {
        var topicList = this.data.topicList;
        if (data.list.length > 0) {
          for (var i = 0; i < data.list.length; i++) {
            var topic = data.list[i];
            topic.systemCreateTime = util.timeToDateStr(topic.systemCreateTime);
            topicList.push(topic);
          }
        }
        this.setData({
          topicList: topicList,
          shortTopicTotal: data.total
        });
      }.bind(this)
    });
  },
  onReachBottom: function (e) {
    var longTopicPageIndex = this.data.longTopicPageIndex;
    var longTopicPageSize = this.data.longTopicPageSize;
    var longTopicTotal = this.data.longTopicTotal;
    var shortTopicPageIndex = this.data.shortTopicPageIndex;
    var shortTopicPageSize = this.data.shortTopicPageSize;
    var shortTopicTotal = this.data.shortTopicTotal;

    if ((longTopicPageIndex * longTopicPageSize) < longTopicTotal && (shortTopicPageIndex * shortTopicPageSize) >= shortTopicTotal) {
      return 
    }
    longTopicPageIndex++;
    this.setData({
      longTopicPageIndex: longTopicPageIndex
    });
    shortTopicPageIndex++;
    this.setData({
      shortTopicPageIndex: shortTopicPageIndex
    });
    this.getTopicData();
  },
  toForumList: function () {
    wx.navigateTo({
      url: '/view/forum/list',
    });
  },
  toMemberList: function () {
    wx.navigateTo({
      url: '/view/member/list',
    });
  },
  toTopicDetail: function (e) {
    wx.navigateTo({
      url: '/view/topic/detail?topicId=' + e.currentTarget.dataset.topicId,
    });
  },
  toMemberHomePage: function (e) {
    var memberId = e.currentTarget.dataset.memberId;
    var member = storage.getMember();
    if (memberId === member.memberId) {
      wx.navigateTo({
        url: '/view/member/homePage'
      }); 
    } else {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + memberId
      });
    }
  },
  handleFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-follow-member", { memberId: event.currentTarget.dataset.memberId});
              wx.showToast({
                title: '关注成功',
                icon: 'none',
                duration: 1500
              })
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleCancelFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/delete',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-follow-member", { memberId: event.currentTarget.dataset.memberId });
              wx.showToast({
                title: '取消关注成功',
                icon: 'none',
                duration: 1500
              })
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/save',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleCancelLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/delete',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            if (data) {
              notification.emit("member-cancel-like-topic", { topicId: e.currentTarget.dataset.topicId });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  //刷新
  onPullDownRefresh: function () {
    this.setData({
      bannerList: [],
      recommendForumList: [],
      recommendForumTotal: 0,
      recommendForumPageIndex: 1,
      recommendForumPageSize: 6,
      recommendMemberList: [],
      recommendMemberTotal: 0,
      recommendMemberPageIndex: 1,
      recommendMemberPageSize: 6,
      tagFrontendCategoryList: [],
      activeIndex: 0,
      tagFrontendCategoryId: '',
      topicList: [],
      shortTopicTotal: 0,
      shortTopicPageIndex: 1,
      shortTopicPageSize: 6,
      longTopicTotal: 0,
      longTopicPageIndex: 1,
      longTopicPageSize: 3
    });
    this.getIndexBannerData();
    this.getTopicTagFrontendCategoryData();
    this.getRecommendForumData();
    this.getRecommendMemberData();
    this.getTopicData();
    wx.stopPullDownRefresh();
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '哇咿宠物',
      path: 'view/home/index',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})
