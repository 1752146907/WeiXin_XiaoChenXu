const upload = require("../../common/upload.js");
const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const notification = require("../../common/notification.js");

Page({
  data: {
    forumId: '',
    forumName: '',
    forumDescription: '',
    cloneImagePath: '/image/clone.jpg',
    forumGalleryList: [],
    forumTagMapList: [],
    systemVersion: 0,
    imageHost: constant.imageHost,
    tagFrontendCategoryCategoryCode: 'INDEX_FORUM'
  },
  bindViewTap: function () {

  },
  onLoad: function (options) {
    notification.on(this.data.tagFrontendCategoryCategoryCode, this, function (data) {
      if (data) {
        var forumTagMapList = this.data.forumTagMapList;
        var isRepeat = false;
        for (var i = 0; i < forumTagMapList.length; i++) {
          if (forumTagMapList[i].tagId === data.tagId) {
            isRepeat = true;
            break;
          }
        }
        if (!isRepeat) {
          forumTagMapList.push(data);
          this.setData({
            forumTagMapList: forumTagMapList
          })
        }
      }
    });
    this.setData({
      forumId: options.forumId
    })
    wechat.auth({
      checkLogin: true,
      success: function (data) {
        this.loadForum()

      }.bind(this),
      fail: function () {

      }
    });
  },
  bindNameInput: function (e) {
    this.setData({
      forumName: e.detail.value
    });
  },
  bindDescriptionInput: function (e) {
    this.setData({
      forumDescription: e.detail.value
    });
  },
  loadForum: function () {
    http.request({
      url: '/forum/mobile/v1/find',
      data: {
        forumId: this.data.forumId
      },
      success: function (data) {
        this.setData({
          forumName: data.forumName,
          forumDescription: data.forumDescription,
          forumGalleryList: data.forumGalleryList,
          forumTagMapList: data.forumTagMapList,
          systemVersion: data.systemVersion
        })
      }.bind(this)
    });
  },
  handleRemoveTag: function (e) {
    var tagId = e.currentTarget.dataset.tagId;
    var forumTagMapList = this.data.forumTagMapList;
    for (var i = 0; i < this.data.forumTagMapList.length; i++) {
      if (this.data.forumTagMapList[i].tagId === tagId) {
        forumTagMapList.splice(i, 1);
        this.setData({
          forumTagMapList: forumTagMapList
        });
        break;
      }
    }
  },
  handleSubmit: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function (data) {
        if (this.data.forumName.trim().length < 2) {
          wx.showToast({
            title: '圈名称最少2个汉字',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        if (this.data.forumName.trim().length > 10) {
          wx.showToast({
            title: '圈名称最长10个汉字',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        if (this.data.forumName.trim() === '') {
          wx.showToast({
            title: '圈子名称不能为空',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        if (this.data.forumDescription.trim() > 50) {
          wx.showToast({
            title: '圈介绍最长50个汉字',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        if (this.data.forumName.trim() === '') {
          wx.showToast({
            title: '圈子名称不能为空',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        if (this.data.forumGalleryList.length <= 0) {
          wx.showToast({
            title: '圈子图片不能为空',
            mask: true,
            icon: "none",
            duration: 1000
          });
          return;
        }
        var forumGalleryList = this.data.forumGalleryList.map((forumImage, index) => {
          return {
            forumImageId: forumImage.forumImageId,
            forumImagePath: forumImage.forumImagePath,
            forumImageSort: index
          }
        });
        var forumTagMapList = this.data.forumTagMapList.map((tag, index) => {
          return {
            tagId: tag.tagId,
            tagName: tag.tagName,
            forumTagSort: index
          }
        });
        http.request({
          isToast: true,
          url: '/forum/mobile/v1/update',
          data: {
            forumId: this.data.forumId,
            forumName: this.data.forumName,
            forumDescription: this.data.forumDescription,
            forumGalleryListStr: JSON.stringify(forumGalleryList),
            forumTagMapListStr: JSON.stringify(forumTagMapList),
            systemVersion: this.data.systemVersion
          },
          success: function (data) {
            this.setData({
              forumId: '',
              forumName: '',
              forumDescription: '',
              forumGalleryList: [],
              forumTagMapList: [],
              systemVersion: 0,
              forumGalleryList: [],
              forumTagMapList: []
            })
            wx.showToast({
              title: '修改成功',
              mask: true,
              icon: "none",
              duration: 1000
            });
            setTimeout(function () {
              wx.navigateBack();
            }, 1200)
          }.bind(this)
        });
      }.bind(this),
      fail: function () {

      }
    });
    
  },
  uploadImage: function (event) {
    let forumGalleryList = this.data.forumGalleryList;
    if (forumGalleryList.length >= 9) {
      wx.showToast({
        title: '最多上传可以上传9张图片',
        mask: true,
        duration: 2000
      });
      return;
    }
    wx.chooseImage({
      count: 9 - forumGalleryList.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        upload.uploadImage(res, function (result) {
          if (result.imageList && result.imageList.length > 0) {
            var imageList = result.imageList.map((forumImage, index) => {
              return {
                forumImageId: forumImage.fileId,
                forumImagePath: forumImage.filePath
              }
            })
            forumGalleryList = forumGalleryList.concat(imageList);
            this.setData({
              forumGalleryList: forumGalleryList
            });
          }
          
          
        }.bind(this));
      }.bind(this)
    })
  },
  cloneImage: function (e) {
    var fileId = e.currentTarget.dataset.fileId;
    var forumGalleryList = this.data.forumGalleryList;
    for (var i = 0; i < forumGalleryList.length; i++) {
      if (forumGalleryList[i].fileId === fileId) {
        forumGalleryList.splice(i, 1);
        this.setData({
          forumGalleryList: forumGalleryList,
        });
        break;
      }
    }
  },
  toTagFrontendCategoryCategoryCode: function () {
    var forumTagMapList = this.data.forumTagMapList;
    if (forumTagMapList.length >= 6) {
      wx.showToast({
        title: '标签不能超过6个',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    wx.navigateTo({
      url: '/view/tag/add?tagFrontendCategoryCategoryCode=' + this.data.tagFrontendCategoryCategoryCode,
    })
  }
})
