const upload = require("../../common/upload.js");
const constant = require("../../common/constant.js");
const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    memberList: [],
    imageHost: constant.imageHost,
    pageIndex: 1,
    pageSize: 10,
    total: 0,
    forumId: ''
  },
  bindViewTap: function () {

  },
  onLoad: function (options) {
    if (options.forumId) {
      this.setData({
        forumId: options.forumId
      });
      this.getForumMemberFollowList();

      notification.on("member-follow-member", this, function (data) {
        var memberList = this.data.memberList;
        for (var i = 0; i < this.data.memberList.length; i++) {
          if (data.memberId === this.data.memberList[i].memberId) {
            memberList[i].memberIsFollow = true;
          }
        }
        this.setData({
          memberList: memberList
        });
      });

      notification.on("member-cancel-follow-member", this, function (data) {
        var memberList = this.data.memberList;
        for (var i = 0; i < this.data.memberList.length; i++) {
          if (data.memberId === this.data.memberList[i].memberId) {
            memberList[i].memberIsFollow = false;
          }
        }
        this.setData({
          memberList: memberList
        });
      });
    } 
  },
  // 获取会员关注列表
  getForumMemberFollowList: function () {
    http.request({
      url: '/forum/member/follow/mobile/v1/list',
      data: {
        forumId: this.data.forumId,
        pageIndex: this.data.pageIndex,
        pageSize: this.data.pageSize
      },
      success: function (data) {
        var memberList = this.data.memberList;
        if (data.list.length > 0) {
          memberList = memberList.concat(data.list);
        }
        this.setData({
          memberList: memberList,
          total: data.total
        })
      }.bind(this)
    });
  },
  onReachBottom: function () {
    var pageIndex = this.data.pageIndex;
    var pageSize = this.data.pageSize;
    var total = this.data.total;
    if ((pageIndex * pageSize) >= total) {
      return;
    }
    pageIndex++;
    this.setData({
      pageIndex: pageIndex
    });
    this.getForumMemberFollowList();
  },
  // 取消关注
  handleCancelFollow: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/delete',
          data: {
            followMemberId: e.currentTarget.dataset.memberId,
          },
          success: function (data) {
            notification.emit("member-cancel-follow-member", { memberId: e.currentTarget.dataset.memberId});
          }.bind(this)
        })
      }.bind(this)
    });
  },
  // 关注
  handleFollow: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: e.currentTarget.dataset.memberId,
          },
          success: function (data) {
            notification.emit("member-follow-member", { memberId: e.currentTarget.dataset.memberId });
          }.bind(this)
        })
      }.bind(this)
    });
  },
  handleToHomePage: function (e) {
    var memberId = e.target.dataset.memberId;
    var member = storage.getMember();
    if (memberId === member.memberId) {
      wx.navigateTo({
        url: '/view/member/homePage'
      });
    } else {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + memberId
      });
    }
  },
  onPullDownRefresh: function () {
    this.setData({
      memberList: [],
      pageIndex: 1,
      pageSize: 10,
      total: 0,
    });
    this.getForumMemberFollowList();
    wx.stopPullDownRefresh();
  }
})
