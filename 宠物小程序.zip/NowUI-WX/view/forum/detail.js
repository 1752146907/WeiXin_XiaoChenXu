const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
const storage = require("../../common/storage.js");
const notification = require("../../common/notification.js");
Page({
  data: {
    sortArray: ['默认排序', '按最热排序'],
    imageHost: constant.imageHost,
    inputShowed: false,
    topicTitle: "",
    forumId: '',
    forum: {},
    forumCreateTime: '',
    memberFollowTotal: 0,
    memberFollowPageIndex: 1,
    memebrFollowPageSize: 8,
    memberFollowList: [],
    topicTotal: 0,
    topicList: [],
    topicPageIndex: 1,
    topicPageSize: 2,
    isShowEdit: false,
    sort: '0',
    member: storage.getMember(),
    windowWidth: getApp().globalData.windowWidth,
    windowHeight: getApp().globalData.windowHeight,
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      topicTitle: "",
      topicTotal: 0,
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 2,
      inputShowed: false
    });
  },
  clearInput: function () {
    this.setData({
      topicTitle: "",
      topicTotal: 0,
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 2,
    });
  },
  inputTopicTile: function (e) {
    this.setData({
      topicTitle: e.detail.value,
      topicTotal: 0,
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 2,
    });
    this.getTopicData();
  },
  bindPickerChange: function (e) {
    this.setData({
      sort: e.detail.value,
      topicTotal: 0,
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 2
    });
    this.getTopicData();
  },
  showEdit: function (e) {
    this.setData({
      isShowEdit: !this.data.isShowEdit
    })
  },
  onLoad: function (options) {
    if (options.forumId && options.forumId != '') {
      this.setData({
        forumId: options.forumId
      })
      this.getForumData();
      this.getMemberFollowData();
      this.getTopicData();
      notification.on("member-add-topic", this, function (data) {
        if (data.forumIdList && data.forumIdList.length > 0) {
          for (var i = 0; i < data.forumIdList.length; i++) {
            if (data.forumIdList[i] === this.data.forumId) {
              this.setData({
                topicTotal: 0,
                topicList: [],
                topicPageIndex: 1,
                topicPageSize: 4
              });
              this.getTopicData();
            }
          }
        }
      });
    }
  },
  //获取圈子详情信息
  getForumData() {
    var than = this;
    http.request({
      url: '/forum/mobile/v1/find',
      data: {
        forumId: this.data.forumId
      },
      success: function (data) {
        this.setData({
          forumCreateTime: util.timeToDateStr(data.systemCreateTime),
          forum: data
        })
      }.bind(this)
    });
  },
  //获取加入圈子会员信息
  getMemberFollowData() {
    http.request({
      url: '/forum/member/follow/mobile/v1/list',
      data: {
        forumId: this.data.forumId,
        pageIndex: this.data.memberFollowPageIndex,
        pageSize: this.data.memebrFollowPageSize
      },
      success: function (data) {
        this.setData({
          memberFollowList: data.list,
          memberFollowTotal: data.total
        })
      }.bind(this)
    });
  },
  onReachBottom: function () {
    var pageIndex = this.data.topicPageIndex;
    var pageSize = this.data.topicPageSize;
    var total = this.data.topicTotal;
    if ((pageIndex * pageSize)>= total) {
      return;
    }
    this.setData({
      topicPageIndex: pageIndex + 1
    });
    this.getTopicData();
  },
  getTopicData: function () {
    if (this.data.sort === '0') {
      this.getLatestTopicData();                             
    } else if (this.data.sort === '1') {
      this.getHotTopicData();
    }
  },
  //获取最新圈子动态信息
  getLatestTopicData() {
    http.request({
      url: '/topic/mobile/v1/latest/list/by/forum/id',
      data: {
        forumId: this.data.forumId,
        topicTitle: this.data.topicTitle,
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
      },
      success: function (data) {
        var topicList = data.list;
        if (topicList.length > 0) {
          for (var i = 0; i < topicList.length; i++) {
            topicList[i].systemCreateTime = util.timeToDateStr(topicList[i].systemCreateTime);
          }
        }
        topicList = this.data.topicList.concat(topicList);
        this.setData({
          topicList: topicList,
          topicTotal: data.total
        })
      }.bind(this)
    });
  },
  //获取最热圈子动态信息
  getHotTopicData() {
    http.request({
      url: '/topic/mobile/v1/hot/list/by/forum/id',
      data: {
        forumId: this.data.forumId,
        topicTitle: this.data.topicTitle,
        pageIndex: this.data.topicPageIndex,
        pageSize: this.data.topicPageSize
      },
      success: function (data) {
        var topicList = data.list;
        if (topicList.length > 0) {
          for (var i = 0; i < topicList.length; i++) {
            topicList[i].systemCreateTime = util.timeToDateStr(topicList[i].systemCreateTime);
          }
        }
        topicList = this.data.topicList.concat(topicList);
        this.setData({
          topicList: topicList,
          topicTotal: data.total
        })
      }.bind(this)
    });
  },
  toTopicAdd: function () {
    wechat.auth({
      checkLogin: true,
      success: function () {
        wx.navigateTo({
          url: '/view/topic/add?forumId=' + this.data.forumId
        });
      }.bind(this)
    });
  },
  toHomePage: function (e) {
    var memberId = e.currentTarget.dataset.memberId;
    var memberIsSelf = e.currentTarget.dataset.memberIsSelf;
    wx.navigateTo({
      url: memberIsSelf ? '/view/member/homePage' : '/view/member/otherHomePage?memberId=' + memberId
    });
  },
  handleFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/save',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              var topicList = this.data.topicList;
              for (var i = 0; i < topicList.length; i++) {
                var topic = topicList[i];
                if (topic.memberId === event.currentTarget.dataset.memberId) {
                  topic.memberIsFollow = true;
                  topicList[i] = topic;
                }
              }
              this.setData({
                topicList: topicList,
              });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleCancelFollowMember: function (event) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/sns/member/follow/mobile/v1/delete',
          data: {
            followMemberId: event.currentTarget.dataset.memberId
          },
          success: function (data) {
            if (data) {
              var topicList = this.data.topicList;
              for (var i = 0; i < topicList.length; i++) {
                var topic = topicList[i];
                if (topic.memberId === event.currentTarget.dataset.memberId) {
                  topic.memberIsFollow = false;
                  topicList[i] = topic;
                }
              }
              this.setData({
                topicList: topicList
              });
            }
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleFollowForum: function() {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/forum/member/follow/mobile/v1/save',
          data: {
            forumId: this.data.forumId
          },
          success: function (data) {
            if (data) {
              var forum = this.data.forum;
              forum.forumMemberIsFollow = true;
              this.setData({
                forum: forum
              })
              notification.emit("member-follow-forum", {});
            } 
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/save',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            var index = e.currentTarget.dataset.index;
            var topicList = this.data.topicList;
            var topic = topicList[index];
            topic.topicLikeCount = topic.topicLikeCount ? topic.topicLikeCount + 1 : 1;
            topic.memberIsLike = true;
            topicList[index] = topic;

            this.setData({
              topicList: topicList
            })
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleCancelLikeTopic: function (e) {
    wechat.auth({
      checkLogin: true,
      success: function () {
        http.request({
          isToast: true,
          url: '/topic/member/like/mobile/v1/delete',
          data: {
            topicId: e.currentTarget.dataset.topicId
          },
          success: function (data) {
            var index = e.currentTarget.dataset.index;
            var topicList = this.data.topicList;
            var topic = topicList[index];
            topic.topicLikeCount = topic.topicLikeCount - 1;
            topic.memberIsLike = false;
            topicList[index] = topic;

            this.setData({
              topicList: topicList
            })
          }.bind(this)
        });
      }.bind(this)
    });
  },
  handleToMember: function () {
    wx.navigateTo({
      url: '/view/forum/member?forumId=' + this.data.forumId,
    })
  },
  onHide: function () {
    this.setData({
      isShowEdit: false
    });
  },
  onPullDownRefresh: function () {
    this.setData({
      forum: {},
      forumCreateTime: '',
      memberFollowTotal: 0,
      memberFollowPageIndex: 1,
      memebrFollowPageSize: 8,
      memberFollowList: [],
      topicTotal: 0,
      topicList: [],
      topicPageIndex: 1,
      topicPageSize: 2,
    });
    this.getForumData();
    this.getMemberFollowData();
    this.getTopicData();
  }
});