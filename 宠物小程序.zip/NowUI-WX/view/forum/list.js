const http = require("../../common/http.js");
const wechat = require("../../common/wechat.js");
const constant = require("../../common/constant.js");
const util = require("../../common/util.js");
Page({
    data: {
      windowWidth: getApp().globalData.windowWidth,
      windowHeight: getApp().globalData.windowHeight,
      tagFrontendCategoryList: [],
      activeIndex: 0,
      tagFrontendCategoryId: '',
      forumList: [],
      pageIndex: 1,
      pageSize: 5,
      forumTotal: 0,
      isSearchNone: false,
      imageHost: constant.imageHost
    },
    bindViewTap: function () {

    },
    onLoad: function () {
      this.getForumTagFrontendCategoryData();
      this.getForumData();
    },
    getForumTagFrontendCategoryData: function () {
      http.request({
        url: '/tag/frontend/category/mobile/v1/list',
        data: {
          tagFrontendCategoryCategoryCode: "INDEX_FORUM"
        },
        success: function (data) {
          this.setData({
            tagFrontendCategoryList: data
          })
        }.bind(this)
      });
    },
    selectCategory: function (e) {
      var index = e.currentTarget.dataset.index;
      var tagFrontendCategoryId = e.currentTarget.dataset.tagFrontendCategoryId;
      if (tagFrontendCategoryId === this.data.tagFrontendCategoryId) {
        return;
      }
      this.setData({
        activeIndex: index,
        forumList: [],
        pageIndex: 1,
        pageSize: 5,
        forumTotal: 0,
        isSearchNone: false,
        tagFrontendCategoryId: tagFrontendCategoryId
      })
      this.getForumData();
    },
    onReachBottom: function () {
      var pageIndex = this.data.pageIndex;
      var pageSize = this.data.pageSize;
      var total = this.data.forumTotal;
      if ((pageIndex * pageSize) >= total) {
        return;
      }
      this.setData({
        pageIndex: pageIndex + 1
      });
      this.getForumData();
    },
    getForumData: function () {
      http.request({
        url: '/forum/mobile/v1/more/list',
        data: {
          tagFrontendCategoryId: this.data.tagFrontendCategoryId,
          pageIndex: this.data.pageIndex,
          pageSize: this.data.pageSize
        },
        success: function (data) {
          var forumList = this.data.forumList;
          var isSearchNone = true;
          if (data.list.length > 0) {
            forumList = forumList.concat(data.list);
          } else {
            if (this.data.pageIndex === 1) {
              isSearchNone = true;
            }
          }
          this.setData({
            isSearchNone: isSearchNone,
            forumList: forumList,
            forumTotal: data.total
          })
        }.bind(this)
      });
    },
    toOtherHomePage: function (e) {
      wx.navigateTo({
        url: '/view/member/otherHomePage?memberId=' + e.currentTarget.dataset.memberId,
      });
    },
    //刷新
    onPullDownRefresh: function () {
      this.setData({
        activeIndex: 0,
        tagFrontendCategoryId: '',
        forumList: [],
        pageIndex: 1,
        pageSize: 5,
        forumTotal: 0,
        isSearchNone: false,
      });
      this.getForumTagFrontendCategoryData();
      this.getForumData();
      wx.stopPullDownRefresh();
    }
})
