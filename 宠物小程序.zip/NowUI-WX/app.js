//app.js
App({
    onLaunch: function () {
      wx.getSystemInfo({
        success: function (res) {
          this.globalData.windowWidth = res.windowWidth;
          this.globalData.windowHeight = res.windowHeight;
        }.bind(this)
      });
    },
    globalData: {
      windowWidth: 0,
      windowHeight: 0,
    }
})